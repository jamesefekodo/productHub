<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Models\Products\Product;
use App\Models\Products\QuoteRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


class SalesMarketingController extends Controller
{
    public function featuredProducts(Request $request)
    {
        $requestType = '';
        $searchKey = '';
        $pageTitle = '';
        $products = '';
        $totalProducts = 0;


        $searchKey  = trim($request->input('searchKey'));
        $isSearch   = Route::currentRouteName() === 'featuredProductsSearch';

        $query = Product::with(['brand', 'category', 'subCategory', 'colour'])
            ->where('is_featured', true); // compulsory filter

        $productFields = [
            'name',
            'name_zh',
            'name_fr',
            'description',
            'description_zh',
            'description_fr',
            'short_description',
            'meta_title',
            'meta_title_zh',
            'meta_title_fr',
            'meta_keywords',
            'meta_description',
            'meta_description_zh',
            'meta_description_fr'
        ];

        $subCategoryFields = ['sub_category', 'sub_category_zh', 'sub_category_fr'];
        $categoryFields    = ['category', 'category_zh', 'category_fr'];
        $brandFields       = ['brand', 'description'];

        if ($isSearch && $searchKey) {

            $query->where(function ($q) use ($searchKey, $productFields, $subCategoryFields, $categoryFields, $brandFields) {

                // Search in product fields
                foreach ($productFields as $field) {
                    $q->orWhere($field, 'LIKE', "{$searchKey}%");
                }

                // Search in related subCategory
                $q->orWhereRelation('subCategory', function ($rel) use ($searchKey, $subCategoryFields) {
                    foreach ($subCategoryFields as $field) {
                        $rel->orWhere($field, 'LIKE', "{$searchKey}%");
                    }
                });

                // Search in related category
                $q->orWhereRelation('category', function ($rel) use ($searchKey, $categoryFields) {
                    foreach ($categoryFields as $field) {
                        $rel->orWhere($field, 'LIKE', "{$searchKey}%");
                    }
                });

                // Search in related brand
                $q->orWhereRelation('brand', function ($rel) use ($searchKey, $brandFields) {
                    foreach ($brandFields as $field) {
                        $rel->orWhere($field, 'LIKE', "{$searchKey}%");
                    }
                });
            });

            $pageTitle   = t('app.searchResultFor') . ' :: ' . $searchKey;
            $requestType = 'search';
        } else {
            $pageTitle   = t('app.product.featuredProducts');
            $requestType = 'all';
        }

        $products = $query
            ->orderBy('name') // required for cursor pagination
            ->cursorPaginate(20)
            ->appends(['searchKey' => $searchKey]);

        // $totalProducts = $isSearch && $searchKey
        //     ? (clone $query)->count()
        //     : Product::where('is_featured', true)->count();



        $data = [
            'searchKey' => $searchKey,
            'products' => $products,
            // 'totalProducts' => $totalProducts,
            'pageTitle' => $pageTitle,
            'requestType' => $requestType,
        ];

        return view('users.admin.products.featuredProducts.featuredProducts', compact('data'));
    }
    public function toggleFeatured($slug, Request $request)
    {
        $request->validate([
            'is_featured' => 'required|boolean'
        ]);

        $product = Product::where('slug', $slug)->first();
        if (!$product) {
            return redirect()->back()->with('error', t('notifications.noRecordsFound'));
        }

        $product->is_featured = $request->is_featured;
        $product->save();

        return redirect()->back()->with('success', t('notifications.done'));
    }
    public function quoteRequests(Request $request)
    {
        $requestType = '';
        $searchKey = '';
        $pageTitle = '';
        $quotes = '';
        $totalQuotes = 0;


        $searchKey  = trim($request->input('searchKey'));
        $isSearch   = Route::currentRouteName() === 'quotesSearch';

        $query = QuoteRequest::with('customer')
            ->where('status', '!=', 'draft'); // compulsory filter

        $quoteFields = [
            'name',
            'username',
            'session_id',
            'email',
            'phone',
            'status'
        ];

        $customerFields = [
            'username',
            'first_name',
            'middle_name',
            'last_name',
            'email1',
            'email2',
            'phone1',
            'phone2'
        ];

        if ($isSearch && $searchKey) {

            $query->where(function ($q) use ($searchKey, $quoteFields, $customerFields) {

                // Search in QuoteRequest fields
                foreach ($quoteFields as $field) {
                    $q->orWhere($field, 'LIKE', "{$searchKey}%");
                }

                // Search in related customer
                $q->orWhereRelation('customer', function ($custQuery) use ($searchKey, $customerFields) {
                    foreach ($customerFields as $field) {
                        $custQuery->orWhere($field, 'LIKE', "{$searchKey}%");
                    }
                });
            });

            $pageTitle   = t('app.searchResultFor') . ' :: ' . $searchKey;
            $requestType = 'search';
        } else {
            $pageTitle   = t('app.product.quoteRequests');
            $requestType = 'all';
        }

        $quotes = $query
            ->orderBy('created_at', 'desc') // required for cursor pagination
            ->cursorPaginate(20)
            ->appends(['searchKey' => $searchKey]);

        // $totalQuotes = $isSearch && $searchKey
        //     ? (clone $query)->count()
        //     : QuoteRequest::where('status', '!=', 'draft')->count();



        $data = [
            'searchKey' => $searchKey,
            'quotes' => $quotes,
            // 'totalQuotes' => $totalQuotes,
            'pageTitle' => $pageTitle,
            'requestType' => $requestType,
        ];

        return view('users.admin.salesMarketing.quotes.quoteRequests', compact('data'));
    }
    public function viewQuoteRequest($slug)
    {
        $quote = QuoteRequest::where('slug', $slug)->first();
        if (!$quote) {
            return redirect()->back()->with('error', t('notifications.noRecordsFound'));
        }

        $data = [
            'quote' => $quote,
        ];

        return view('users.admin.salesMarketing.quotes.viewQuoteRequest', compact('data'));
    }
}
