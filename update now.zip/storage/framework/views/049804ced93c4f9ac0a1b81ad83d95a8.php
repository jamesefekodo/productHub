<!-- Mobile toggle button -->
<button class="btn btn-outline-primary d-md-none w-100 mb-4" data-bs-toggle="collapse" data-bs-target="#innerNavMenu"
    aria-expanded="false" aria-controls="innerNavMenu">
    <i class="fas fa-bars me-2"></i> <?php echo e(t('app.menu')); ?>

</button>

<!-- Collapsible inner nav -->
<div id="innerNavMenu" class="collapse d-md-block">
    <div class="inner-nav">
        <h6 class="inner-nav-title text-center"><?php echo e(t('app.user.profile')); ?></h6>

        <div class="inner-nav-list">
            <a href="<?php echo e(route('customerMyProfile')); ?>"
                class="inner-nav-item <?php echo e(Str::startsWith(request()->path(), 'customer/profile') ? 'active' : ''); ?>">
                <i class="fas fa-user me-1"></i>
                <?php echo e(t('app.user.myProfile')); ?>

            </a>

            <a href="
            
             "
                class="inner-nav-item <?php echo e(request()->routeIs('productVariations', 'addProductVariant', 'viewProductVariant', 'editProductVariant') ? 'active' : ''); ?>">

                <i data-feather="map"></i>
                <?php echo e(t('app.product.quotes')); ?>

            </a>
        </div>
    </div>
</div>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/customer/profile/include/inner_nav.blade.php ENDPATH**/ ?>