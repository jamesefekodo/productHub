<script>
function removeProductVariantColourFormModal(sizeClass = 'swal-size-md mx-5') {
    Swal.fire({
        // title: "<?php echo e(t('app.buttons.remove')); ?> :: <?php echo e(t('app.product.colour')); ?>",
        showCloseButton: true,
        showConfirmButton: false, // no SweetAlert confirm button
        customClass: {
            popup: sizeClass
        },
        html: `
            <form id="swalForm" method="POST" action="<?php echo e(route('removeProductVariantColourSubmit')); ?>">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="variant" value="<?php echo e($data['variant']->slug); ?>">
                <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.proceed')); ?></button>
            </form>
        `
    });
}

// Auto-open modal if there are validation errors
document.addEventListener('DOMContentLoaded', function() {
    <?php if($errors->any()): ?>
        removeProductVariantColourFormModal();
    <?php endif; ?>
});
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/variants/include/removeProductVariantColourModal.blade.php ENDPATH**/ ?>