<?php $__env->startSection('title', t('app.payment.taxes')); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.payment.taxes')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.payment.payment')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.settings.settings')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.payment.taxes')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <div class="dropdown">
                            <a class="btn btn-icon btn-light-brand" data-bs-toggle="dropdown" data-bs-offset="0, 10"
                                data-bs-auto-close="outside">
                                <i class="feather-filter"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="javascript:void(0);" class="dropdown-item filter-option active fw-bold"
                                    data-filter="all">
                                    <span class="wd-7 ht-7 bg-primary rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.all')); ?></span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="active">
                                    <span class="wd-7 ht-7 bg-success rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.active')); ?></span>
                                </a>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="inactive">
                                    <span class="wd-7 ht-7 bg-danger rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.inactive')); ?></span>
                                </a>
                            </div>
                        </div>
                        <button onclick="addTaxFormModal('swal-size-md')" class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span><?php echo e(t('app.addNew')); ?></span>
                        </button>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">
                
                <div class="col-md-2">
                    <?php echo $__env->make('users.admin.payments.settings.paymentMethods.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                
                <!-- [Latest Leads] start -->
                <div class="col-md-10">
                    <div class="col-xxl-12">
                        <div class="card stretch stretch-full">
                            <div class="card-header">
                                <h5 class="card-title">
                                    <?php echo e(t('app.payment.taxes')); ?>

                                </h5>
                            </div>
                            <div class="card-body custom-card-action p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead>
                                            <tr class="border-b">
                                                <th scope="row">#</th>
                                                <th scope="row"><?php echo e(t('app.payment.taxName')); ?></th>
                                                <th scope="row"><?php echo e(t('app.payment.taxMethod')); ?></th>
                                                <th scope="row"><?php echo e(t('app.payment.taxRate')); ?></th>
                                                <th scope="row"><?php echo e(t('app.default')); ?></th>
                                                <th scope="row">
                                                    <?php echo e(t('app.status.status')); ?>

                                                </th>
                                                <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                            </tr>
                                        </thead>
                                        <?php if($data['taxes']->isEmpty()): ?>
                                            <tbody>
                                                <td colspan="6" class="text-center text-danger fw-bold fs-5">
                                                    <?php echo e(t('app.noRecordsFound')); ?>

                                                </td>
                                            </tbody>
                                        <?php else: ?>
                                            <tbody>
                                                <?php $__currentLoopData = $data['taxes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo e($loop->iteration); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($tax->tax_name); ?>

                                                        </td>
                                                        <td>
                                                            <?php switch($tax->tax_method):
                                                                case ('percentage'): ?>
                                                                    <?php echo e(t('app.payment.percentage')); ?>

                                                                <?php break; ?>

                                                                <?php case ('fixed_amount'): ?>
                                                                    <?php echo e(t('app.payment.fixedAmount')); ?>

                                                                <?php break; ?>

                                                                <?php default: ?>
                                                            <?php endswitch; ?>
                                                        </td>
                                                        <td>
                                                            <?php switch($tax->tax_method):
                                                                case ('percentage'): ?>
                                                                    <?php echo e($tax->tax_rate); ?>%
                                                                <?php break; ?>

                                                                <?php case ('fixed_amount'): ?>
                                                                    ₦<?php echo e(number_format($tax->tax_rate, 2)); ?>

                                                                <?php break; ?>

                                                                <?php default: ?>
                                                            <?php endswitch; ?>
                                                        </td>
                                                        <td>
                                                            <?php switch($tax->is_default):
                                                                case (true): ?>
                                                                    <span
                                                                        class="badge bg-soft-success text-success"><?php echo e(t('app.status.true')); ?></span>
                                                                <?php break; ?>

                                                                <?php case (false): ?>
                                                                    <span
                                                                        class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.false')); ?></span>
                                                                <?php break; ?>

                                                                <?php default: ?>
                                                            <?php endswitch; ?>
                                                        </td>
                                                        <td>
                                                            <?php switch($tax->is_active):
                                                                case (true): ?>
                                                                    <span
                                                                        class="badge bg-soft-success text-success"><?php echo e(t('app.status.active')); ?></span>
                                                                <?php break; ?>

                                                                <?php case (false): ?>
                                                                    <span
                                                                        class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.inactive')); ?></span>
                                                                <?php break; ?>

                                                                <?php default: ?>
                                                            <?php endswitch; ?>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-primary text-white cursor-pointer"
                                                                onclick="editTaxFormModal<?php echo e($tax->id); ?>()"
                                                                id="edit-<?php echo e($tax->id); ?>">
                                                                <i class="feather-edit"></i> <?php echo e(t('app.buttons.edit')); ?>

                                                            </span>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>


                <!-- [Latest Leads] end -->

                


                
                <?php echo $__env->make('users.admin.payments.settings.taxes.include.addTaxModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                <?php if(!$data['taxes']->isEmpty()): ?>
                    <?php $__currentLoopData = $data['taxes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('users.admin.payments.settings.taxes.include.editTaxModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                <?php if(session('editTaxId')): ?>
                                    const el = document.querySelector('[data-id="<?php echo e(session('editTaxId')); ?>"]');
                                    if (el) editTaxFormModal(el);
                                <?php endif; ?>
                            });
                        </script>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>




    


    
    
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/payments/settings/taxes/taxes.blade.php ENDPATH**/ ?>