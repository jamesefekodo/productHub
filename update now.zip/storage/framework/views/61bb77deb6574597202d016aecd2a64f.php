<?php
    $currentLocale = app()->getLocale();
    $currentLanguage = collect(activeLanguages())->firstWhere('language_code', $currentLocale);
?>

<div class="lang-card-container">
    <div class="language-switcher">
        <button class="lang-toggle" type="button">
            <img src="<?php echo e(asset('system/images/lang/' . $currentLanguage->flag)); ?>" alt="" width="25px">
            <span class="lang-code">
                <?php echo e($currentLanguage->language ?? strtoupper($currentLocale)); ?>

            </span>

            <svg class="chevron" viewBox="0 0 24 24">
                <path d="M6 9l6 6 6-6" />
            </svg>
        </button>

        <ul class="lang-menu">
            <?php $__currentLoopData = activeLanguages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="?lang=<?php echo e($language->language_code); ?>"
                        class="<?php echo e($currentLocale === $language->language_code ? 'active' : ''); ?>">
                        <img src="<?php echo e(asset('system/images/lang/' . $language->flag)); ?>" alt="" width="25px">
                        <?php echo e($language->language); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

</div>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/utilities/pages/others/changeLanguage.blade.php ENDPATH**/ ?>