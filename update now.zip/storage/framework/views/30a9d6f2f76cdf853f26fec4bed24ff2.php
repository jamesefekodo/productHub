<div class="slider">
    <div class="slides">
        <?php if(homepageSliders()->isNotEmpty()): ?>
            <?php $__currentLoopData = homepageSliders(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slide <?php echo e($key === 0 ? 'active' : ''); ?>">
                    <div class="overlay"></div>

                    <img src="<?php echo e(asset('assets/uploads/homepageSlider/' . $slider->background_image)); ?>"
                        alt="<?php echo e($slider->header); ?>" />

                    <div class="caption">
                        <p class="caption-header"><?php echo e($slider->header); ?></p>
                        <p class="caption-description"><?php echo e($slider->description); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
    </div>


    <!-- Navigation Arrows and Dots -->
    <div class="nav-arrows">
        <span class="arrow prev">&#10094;</span>
        <span class="arrow next">&#10095;</span>
    </div>


    <div class="nav-dots">
        <?php if(homepageSliders()->isNotEmpty()): ?>
            <?php $__currentLoopData = homepageSliders(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="dot <?php echo e($key === 0 ? 'active' : ''); ?>"></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/utilities/pages/auth/include/slider.blade.php ENDPATH**/ ?>