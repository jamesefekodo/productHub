<script>
    function editDiscountFormModal<?php echo e($discount->id); ?>(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.buttons.edit')); ?> :: <?php echo e(t('app.payment.discount')); ?>",
            showCloseButton: true,
            showConfirmButton: false,
            customClass: {
                popup: sizeClass
            },
            html: `
                <form id="swalForm" method="POST" action="<?php echo e(route('updateDiscountSubmit', ['id' => $discount->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row col-md-12">
                        <div class="mb-3 col-md-12">
                            <label class="form-label"><?php echo e(t('app.payment.discountName')); ?><span class="text-danger">*</span></label>
                            <input type="text" name="discount_name" class="form-control text-center" value="<?php echo e($discount->discount_name); ?>" required>
                            <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('discount_name')); ?></p>
                        </div>
                        <div class="mb-3 col-md-12">
                            <label class="form-label"><?php echo e(t('app.payment.discountMethod')); ?><span class="text-danger">*</span></label>
                        <select class="form-select text-center" name="discount_method" required>
                            <option disabled selected>
                                - <?php echo e(t('app.select')); ?> -
                            </option>
                            <option value="fixed_amount" <?php echo e($discount->discount_method == "fixed_amount" ? 'selected' : ''); ?>><?php echo e(t('app.payment.fixedAmount')); ?></option>
                            <option value="percentage" <?php echo e($discount->discount_method == "percentage" ? 'selected' : ''); ?>><?php echo e(t('app.payment.percentage')); ?></option>
                        </select>

                            <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('discount_method')); ?></p>
                        </div>
                        <div class="mb-3 col-md-12">
                            <label class="form-label"><?php echo e(t('app.payment.discountRate')); ?><span class="text-danger">*</span></label>
                            <input type="text" name="discount_rate" class="form-control text-center" value="<?php echo e($discount->discount_rate); ?>" required>
                            <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('discount_rate')); ?></p>
                        </div>
                        <div class="mb-3 col-md-6">
                            <label class="form-label">
                                <?php echo e(t('app.default')); ?>

                                <span class="text-danger">*</span>
                            </label>

                            <select name="is_default" class="form-select text-center" required>
                                <option value="1" <?php echo e($discount->is_default == 1 ? 'selected' : ''); ?>>
                                    <?php echo e(t('app.status.true')); ?>

                                </option>
                                <option value="0" <?php echo e($discount->is_default == 0 ? 'selected' : ''); ?>>
                                    <?php echo e(t('app.status.false')); ?>

                                </option>
                            </select>

                            <p style="color: red; font-size: 12px; margin-top: 5px;">
                                <?php echo e($errors->first('is_default')); ?>

                            </p>
                        </div>
                        <div class="mb-3 col-md-6">
                            <label class="form-label"><?php echo e(t('app.status.status')); ?><span class="text-danger">*</span></label>
                            <select class="form-select text-center" name="is_active" required>
                                <option selected disabled>
                                    -<?php echo e(t('app.select')); ?>-
                                </option>

                                <option value="1" <?php echo e($discount->is_active == 1 ? 'selected' : ''); ?>>
                                    <?php echo e(t('app.status.active')); ?>

                                </option>

                                <option value="0" <?php echo e($discount->is_active == 0 ? 'selected' : ''); ?>>
                                    <?php echo e(t('app.status.inactive')); ?>

                                </option>
                            </select>
                            <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('is_active')); ?></p>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
                </form>
            `
        });
    }
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/payments/settings/discounts/include/editDiscountModal.blade.php ENDPATH**/ ?>