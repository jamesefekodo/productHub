<?php $__env->startSection('title', t('auth.authenticateLogin')); ?>
<?php $__env->startSection('content'); ?>
    <div class="outer-container">
        <?php echo $__env->make('utilities.pages.auth.include.slider', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="login-form">
            <div class="form-container">
                <?php echo $__env->make('utilities.pages.auth.include.headerLogo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                <h2 class="m-2 text-center auth_header"><?php echo e(t('auth.authenticateLogin')); ?></h2>
                <p class="m-2 text-center"><?php echo e(t('auth.enterOtp')); ?></p>
                <form class="" action="<?php echo e(route('verifyLoginOtpSubmit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="number" name="login_otp" placeholder="123456"
                        min="100000" max="999999" required />
                    <p style="color: red"><?php echo e($errors->first('login_otp')); ?></p>

                    <button type="submit"><?php echo e(t('app.buttons.submit')); ?></button>
                </form>

                <div class="form-options my-4">
                    <div
                        class="d-flex flex-column flex-md-row justify-content-center justify-content-md-between gap-2 my-4">
                        <a href="<?php echo e(route('resendLoginOtp')); ?>"

                            class="btn btn-primary text-white w-100 w-md-auto">
                            <?php echo e(t('auth.resendCode')); ?>

                        </a>

                        <a href="<?php echo e(route('logoutRequest')); ?>" class="btn btn-danger text-white w-100 w-md-auto">
                            <?php echo e(t('auth.logout')); ?>

                        </a>
                    </div>
                    <div class="d-flex justify-content-end">
                        <div class="text-center">
                            <?php echo $__env->make('utilities.pages.others.changeLanguage', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/utilities/pages/auth/loginOtpAuthentication.blade.php ENDPATH**/ ?>