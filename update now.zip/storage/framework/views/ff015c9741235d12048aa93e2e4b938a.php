<?php $__env->startSection('title', t('app.product.category') . ' :: ' . $data['category']->category); ?>
<?php $__env->startSection('content'); ?>

    <div class="desktop-nav-bg"></div>
    <div class="main-content-wrapper">

        <section class="section">
            <?php
                $locale = currentLocale();
                $field = 'category_' . $locale;

                $catName =
                    isset($data['category']->$field) && $data['category']->$field
                        ? $data['category']->$field
                        : $data['category']->category;
            ?>


            <div class="my-page-header"><?php echo e($catName); ?></div>

            
            <?php
                $featuredProduct = featuredProducts()->where('category_id', $data['category']->id);
            ?>
            <?php if($featuredProduct->isNotEmpty()): ?>

                <h2 class="section-title text-center mt-5 mb-3"><?php echo e(t('app.product.featuredProducts')); ?></h2>

                <div class="cat-carousel owl-carousel owl-theme">
                    <?php $__currentLoopData = $featuredProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="cat-card">
                            <?php
                                $thumbnailImage = asset('system/images/icon_placeholder.png');

                                if (!$product->mediaFiles->isEmpty()) {
                                    $primaryImage = $product->mediaFiles->where('is_primary', true)->first();

                                    if ($primaryImage) {
                                        $thumbnailImage = asset(
                                            'assets/uploads/products/products/media/images/' . $primaryImage->file_name,
                                        );
                                    }
                                }
                            ?>
                            <img src="<?php echo e($thumbnailImage); ?>" alt="<?php echo e($product->name); ?>">
                            <div class="cat-overlay">
                                <?php
                                    $locale = currentLocale();
                                    $field = 'name_' . $locale;
                                    $prodName = !empty($product->$field) ? $product->$field : $product->name;
                                ?>


                                <h3><?php echo e($prodName); ?></h3>
                                <?php if(displayPrice() == true): ?>
                                    <?php if(!is_null($product->price) && $product->price != 0): ?>
                                        <span class="price">₦<?php echo e(number_format($product->price, 2)); ?></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            

            

            
            <div class="my-4">
                <h2 class="section-title text-center mt-5 mb-3"><?php echo e(t('app.product.subCategories')); ?></h2>

                <div class="cat-grid">
                    <?php if(allCategories()->isNotEmpty()): ?>
                        <?php $__currentLoopData = allCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="cat-card">
                                <?php
                                    $imagePath = public_path(
                                        'assets/uploads/products/categories/icons/' . $category->image,
                                    );
                                    $imageUrl = file_exists($imagePath)
                                        ? asset('assets/uploads/products/categories/icons/' . $category->image)
                                        : asset('system/images/icon_placeholder.png');

                                    $locale = currentLocale();
                                    $field = 'category_' . $locale;
                                    $name = !empty($category->$field) ? $category->$field : $category->category;
                                ?>
                                <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($name); ?>">
                                <div class="cat-overlay">
                                    <h3><?php echo e($name); ?></h3>
                                    <p><?php
                                        $locale = currentLocale();
                                        $field = 'meta_description_' . $locale;
                                        $metaDesc = !empty($category->$field)
                                            ? $category->$field
                                            : $category->meta_description;

                                        $words = explode(' ', $metaDesc);
                                        $metaDescShort = implode(' ', array_slice($words, 0, 10));
                                        if (count($words) > 10) {
                                            $metaDescShort .= '...';
                                        }
                                    ?>
                                        <?php echo e($metaDescShort); ?>

                                    </p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="my-4">
                <h2 class="section-title text-center mt-5 mb-3"><?php echo e(t('app.product.allProducts')); ?></h2>
            </div>

        </section>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/customer/categories/categories.blade.php ENDPATH**/ ?>