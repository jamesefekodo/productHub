<script>
    function addSubCategoryFormModal(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.addNew')); ?> :: <?php echo e(t('app.product.subCategory')); ?>",
            showCloseButton: true,
            showConfirmButton: false, // no SweetAlert confirm button
            customClass: {
                popup: sizeClass
            },
            html: `
            <form id="swalForm" method="POST" action="<?php echo e(route('createNewSubCategorySubmit', ['slug' => $data['category']->slug])); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php
                    $image = asset('system/images/icon_placeholder.png');
                ?>
                <div class="mb-3 form-group upload-container">
                    <div class="row d-flex justify-content-center">
                        <div class="col-md-6"><label for="passport-upload" class="preview-frame">
                                <img id="passport-preview"
                                    src="<?php echo e($image); ?>" alt="">
                                <div class="overlay"><i class="fas fa-upload"></i></div>
                            </label>
                        </div>
                        <div class="col-md-6"><input type="file" id="passport-upload"
                                accept=".jpg, .jpeg, .png, .webp" onchange="previewPassport2()"
                                name="image">
                        </div>
                        <p class="text-red"><?php echo e($errors->first('image')); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="mb-3 col-md-6">
                        <label class="form-label"><?php echo e(t('app.product.category')); ?> <span class="text-red">*</span></label>
                        <input type="text" name="category" class="form-control text-center" value="<?php echo e($data['category']->category); ?>" disabled>
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('category')); ?></p>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label"><?php echo e(t('app.product.subCategory')); ?> <span class="text-red">*</span></label>
                        <input type="text" name="name" class="form-control text-center" value="<?php echo e(old('name')); ?>" required>
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('name')); ?></p>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.settings.seo.metaTitle')); ?></label>
                        <input type="text" name="meta_title" class="form-control text-center" value="<?php echo e(old('meta_title')); ?>">
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('meta_title')); ?></p>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.settings.seo.metaDescription')); ?></label>
                        <textarea name="meta_description" class="form-control" rows="3" style="min-height: 120px;" placeholder="">
                            <?php echo e(old('meta_description')); ?>

                        </textarea>

                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('meta_description')); ?></p>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
            </form>
        `
        });
    }

    // Auto-open modal if there are validation errors
    document.addEventListener('DOMContentLoaded', function() {
        <?php if($errors->any()): ?>
            addSubCategoryFormModal();
        <?php endif; ?>
    });
</script>



<script>
    function previewPassport2() {
        const preview = document.getElementById('passport-preview');
        const fileInput = document.getElementById('passport-upload');
        const file = fileInput.files[0];
        const reader = new FileReader();

        reader.onload = function() {
            preview.src = reader.result;
        }

        if (file) {
            reader.readAsDataURL(file);
        } else {
            preview.src = 'placeholder.jpg';
        }
    }
</script>



<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/categories/include/addSubCategoryModal.blade.php ENDPATH**/ ?>