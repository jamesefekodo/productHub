<script>
    function editCountryFormModal<?php echo e($country->id); ?>(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.buttons.edit')); ?> :: <?php echo e(t('app.settings.address.country')); ?>",
            showCloseButton: true,
            showConfirmButton: false,
            customClass: { popup: sizeClass },
            html: `
                <form id="swalForm" method="POST" action="<?php echo e(route('updateCountrySubmit', ['id' => $country->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.settings.address.country')); ?></label>
                        <input type="text" name="country" class="form-control text-center" value="<?php echo e($country->name); ?>" required>
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('country')); ?></p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.settings.address.phoneCode')); ?></label>
                        <input type="text" name="phone_code" class="form-control text-center" value="<?php echo e($country->phone_code); ?>" required>
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('phone_code')); ?></p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.status.status')); ?></label>
                        <select class="form-select text-center" name="status" required>
                                        <option selected disabled>
                                            -<?php echo e(t('app.select')); ?>-</option>
                                        <option value="active" <?php echo e($country->status == 'active' ? 'selected' : ''); ?>>
                                            <?php echo e(t('app.status.active')); ?></option>
                                        <option value="inactive" <?php echo e($country->status == 'inactive' ? 'selected' : ''); ?>>
                                            <?php echo e(t('app.status.inactive')); ?></option>
                        </select>
                        <p id="phone-error" style="color: red; font-size: 12px; margin-top: 5px;"></p>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
                </form>
            `
        });
    }
    </script>

<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/settings/address/country/include/editCountryModal.blade.php ENDPATH**/ ?>