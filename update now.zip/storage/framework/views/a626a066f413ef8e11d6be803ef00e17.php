<script>
    function editPaymentMethodFormModal<?php echo e($method->id); ?>(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.buttons.edit')); ?> :: <?php echo e(t('app.payment.paymentMethod')); ?>",
            showCloseButton: true,
            showConfirmButton: false,
            customClass: {
                popup: sizeClass
            },
            html: `
                <form id="swalForm" method="POST" action="<?php echo e(route('updatePaymentMethodSubmit', ['slug' => $method->slug])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.status.status')); ?></label>
                        <select class="form-select text-center" name="status" required>
                                        <option selected disabled>
                                            -<?php echo e(t('app.select')); ?>-</option>
                                        <option value="active" <?php echo e($method->status == 'active' ? 'selected' : ''); ?>>
                                            <?php echo e(t('app.status.active')); ?></option>
                                        <option value="inactive" <?php echo e($method->status == 'inactive' ? 'selected' : ''); ?>>
                                            <?php echo e(t('app.status.inactive')); ?></option>
                        </select>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('status')); ?></p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.version')); ?></label>
                        <input type="text" name="version" class="form-control text-center" value="<?php echo e($method->version); ?>">
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('version')); ?></p>
                    </div>

                    <?php switch($method->slug):
                        case ('paystack'): ?>
                        <hr>
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(t('app.payment.secretKey')); ?></label>
                            <input type="text" name="secret_key" class="form-control text-center" value="<?php echo e($method->PaystackApi->secret_key); ?>" required>
                             <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('secret_key')); ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(t('app.payment.publicKey')); ?></label>
                            <input type="text" name="public_key" class="form-control text-center" value="<?php echo e($method->PaystackApi->public_key); ?>" required>
                             <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('public_key')); ?></p>
                        </div>
                            <?php break; ?>
                            <?php case ('flutterwave'): ?>
                            <hr>
                            <div class="mb-3">
                                <label class="form-label"><?php echo e(t('app.payment.secretKey')); ?></label>
                                <input type="text" name="secret_key" class="form-control text-center" value="<?php echo e($method->flutterwaveApi->secret_key); ?>" required>
                                <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('secret_key')); ?></p>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e(t('app.payment.publicKey')); ?></label>
                                <input type="text" name="public_key" class="form-control text-center" value="<?php echo e($method->flutterwaveApi->public_key); ?>" required>
                                <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('public_key')); ?></p>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e(t('app.payment.encryptionKey')); ?></label>
                                <input type="text" name="encryption_key" class="form-control text-center" value="<?php echo e($method->flutterwaveApi->encryption_key); ?>" required>
                                <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('encryption_key')); ?></p>
                            </div>
                            <?php break; ?>

                        <?php default: ?>

                    <?php endswitch; ?>



                    <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
                </form>
            `
        });
    }
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/payments/settings/paymentMethods/include/editPaymentMethodModal.blade.php ENDPATH**/ ?>