<section class="main-search-section">
    <div class="main-search-container">
        <div class="main-search-glass-wrapper">
            <form action="<?php echo e(route(routePrefix() . 'SearchProduct')); ?>" method="GET">
                <div class="main-search-input-group">
                    <i class="fas fa-search main-search-icon"></i>

                    <input type="text" id="mainSearchInput" class="main-search-input-field"
                        placeholder="<?php echo e(t('app.product.productSearchPlaceholder')); ?>" value="<?php echo e($data['searchKey']); ?>"
                        name="searchKey" autocomplete="off">

                    <div class="main-search-actions">
                        <button type="button" id="mainSearchClearBtn" class="main-search-action-btn main-search-hide"
                            title="Clear">
                            <i class="fas fa-times"></i>
                        </button>

                        <div class="main-search-divider"></div>

                        <button type="submit" id="mainSearchSubmitBtn" class="main-search-action-btn" title="Search">
                            <i class="fas fa-magnifying-glass"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Suggestions -->
        <div id="mainSearchSuggestions" class="main-search-suggestions-box main-search-hide">
            <div class="main-search-suggestion-header">
                <?php echo e(t('app.suggestions')); ?>

            </div>
            <div id="mainSearchSuggestionList"></div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {

        const input = document.getElementById('mainSearchInput');
        const suggestionBox = document.getElementById('mainSearchSuggestions');
        const suggestionList = document.getElementById('mainSearchSuggestionList');
        const clearBtn = document.getElementById('mainSearchClearBtn');

        input.addEventListener('input', function() {

            let query = this.value.trim();

            if (query.length < 2) {
                suggestionBox.classList.add('main-search-hide');
                suggestionList.innerHTML = '';
                clearBtn.classList.add('main-search-hide');
                return;
            }

            clearBtn.classList.remove('main-search-hide');

            fetch(`<?php echo e(route('products.search')); ?>?q=${encodeURIComponent(query)}`)
                .then(res => res.json())
                .then(data => {

                    suggestionList.innerHTML = '';

                    if (!data.length) {
                        suggestionBox.classList.add('main-search-hide');
                        return;
                    }

                    data.forEach(product => {

                        let name = product.name ||
                            product.name_zh ||
                            product.name_fr ||
                            'Unnamed Product';

                        suggestionList.innerHTML += `
                        <div class="main-search-suggestion-item"
                             data-name="${name}">
                            ${name}
                        </div>
                    `;
                    });

                    suggestionBox.classList.remove('main-search-hide');
                })
                .catch(error => {
                    console.error('Search error:', error);
                });
        });

        // Autocomplete behavior (NO redirect)
        suggestionList.addEventListener('click', function(e) {
            if (e.target.classList.contains('main-search-suggestion-item')) {
                input.value = e.target.dataset.name;
                suggestionBox.classList.add('main-search-hide');
            }
        });

        clearBtn.addEventListener('click', function() {
            input.value = '';
            suggestionList.innerHTML = '';
            suggestionBox.classList.add('main-search-hide');
            clearBtn.classList.add('main-search-hide');
        });

    });
</script>




<?php if($data['requestType'] == 'search'): ?>
    <?php if($data['requestType']): ?>
        <h2 class="section-title mt-5"><?php echo e(t('app.searchResultFor') . ' :: ' . $data['searchKey']); ?> </h2>
        <?php if($data['products']->isNotEmpty()): ?>
            <div class="prod-grid">
                <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route(routePrefix() . 'ViewProduct', ['slug' => $product->slug])); ?>">
                        <div class="prod-card">
                            <?php if($product->is_featured == true): ?>
                                <span class="prod-tag"><?php echo e(t('app.product.featured')); ?></span>
                            <?php endif; ?>
                            <div class="prod-img">
                                <?php
                                    $thumbnailImage = asset('system/images/icon_placeholder.png');

                                    if (!$product->mediaFiles->isEmpty()) {
                                        $primaryImage = $product->mediaFiles->where('is_primary', true)->first();

                                        if ($primaryImage) {
                                            $thumbnailImage = asset(
                                                'assets/uploads/products/products/media/images/' .
                                                    $primaryImage->file_name,
                                            );
                                        }
                                    }
                                ?>

                                <img src="<?php echo e($thumbnailImage); ?>" alt="<?php echo e($product->name); ?>">
                            </div>
                            <div class="prod-info">
                                <h4>
                                    <?php
                                        $locale = currentLocale();
                                        $field = 'name_' . $locale;
                                        $value = !empty($product->$field) ? $product->$field : $product->name;
                                    ?>

                                    <?php echo e($value); ?>

                                </h4>

                                <?php if(displayPrice() == true): ?>
                                    <?php if(!is_null($product->price) && $product->price != 0): ?>
                                        <span class="price">₦<?php echo e(number_format($product->price, 2)); ?></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <h3 class="text-danger">
                    <?php echo e(t('notifications.noRecordsFound')); ?>

                </h3>
            </div>
        <?php endif; ?>

    <?php endif; ?>

    
    <?php
        $paginatedArray = $data['products'];
    ?>
    <?php echo $__env->make('utilities.pages.others.frontendPagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="w-100 justify-content-center text-center mb-4">
        <a class="btn btn-success text-white" href="<?php echo e(url('/')); ?>">
            <i class="fas fa-chevron-left ms-2"></i> <?php echo e(t('app.buttons.backHome')); ?>

        </a>
    </div>

<?php endif; ?>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/frontend/include/searchBar.blade.php ENDPATH**/ ?>