<?php $__env->startSection('title', $data['pageTitle']); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.product.colours')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.product.colours')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <button onclick="addColourFormModal('swal-size-md')" class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span><?php echo e(t('app.addNew')); ?></span>
                        </button>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">

                <!-- [Latest Leads] start -->
                <div class="col-xxl-12">
                    <div class="card stretch stretch-full">
                        <div class="card-header">
                            <h5 class="card-title">
                                <?php echo e($data['pageTitle']); ?>

                                
                            </h5>

                            

                            <div class="table-search">
                                <!-- Search form -->
                                <form method="GET" class="search-form" action="<?php echo e(route('coloursSearch')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="searchKey" class="form-control form-control-sm"
                                        placeholder="<?php echo e(t('app.search')); ?>..." value="<?php echo e($data['searchKey']); ?>">
                                </form>
                                <!-- Toggle button (visible only on mobile) -->
                                <button type="button" class="btn btn-sm btn-light search-toggle">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>


                            
                        </div>
                        <div class="card-body custom-card-action p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr class="border-b">
                                            <th scope="row">#</th>
                                            <th scope="row"><?php echo e(t('app.name')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.colour')); ?></th>
                                            <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                        </tr>
                                    </thead>
                                    <?php if($data['colours']->isEmpty()): ?>
                                        <tbody>
                                            <td colspan="4" class="text-center text-danger fw-bold fs-5">
                                                <?php echo e(t('app.noRecordsFound')); ?>

                                            </td>
                                        </tbody>
                                    <?php else: ?>
                                        <tbody>
                                            <?php $__currentLoopData = $data['colours']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($loop->iteration); ?>

                                                    </td>
                                                    <td>
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $value = !empty($colour->$field)
                                                                ? $colour->$field
                                                                : $colour->name;
                                                        ?>
                                                        <?php echo e($value); ?>

                                                    </td>
                                                    <td>
                                                        <?php
                                                            $hex = preg_match('/^#[0-9A-Fa-f]{6}$/', $colour->hex_code)
                                                                ? $colour->hex_code
                                                                : '#000000';
                                                        ?>

                                                        <div style="display:flex; align-items:center; gap:8px;">

                                                            <span
                                                                style="width:60px; height:25px; background-color: <?php echo e($hex); ?>; border:1px solid #ccc; display:inline-block;">
                                                            </span>
                                                            <?php echo e($hex); ?>

                                                        </div>
                                                    </td>


                                                    <td>
                                                        <a href="<?php echo e(route('editColour', ['id' => $colour->id])); ?>?language=en"
                                                            class="badge bg-primary text-white cursor-pointer me-3">
                                                            <i class="feather-edit"></i> <?php echo e(t('app.buttons.edit')); ?>

                                                        </a>
                                                        <form action="<?php echo e(route('deleteColour', ['id' => $colour->id])); ?>"
                                                            method="POST" id="delete-form-<?php echo e($colour->id); ?>"
                                                            style="display: inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                        </form>

                                                        <a href="javascript:void(0)" class="badge bg-danger text-white me-3"
                                                            onclick="event.preventDefault(); confirmDelete<?php echo e($colour->id); ?>(); return false;">
                                                            <i class="feather-trash me-1"></i>
                                                            <?php echo e(t('app.buttons.delete')); ?>

                                                        </a>

                                                        <script>
                                                            function confirmDelete<?php echo e($colour->id); ?>() {
                                                                Swal.fire({
                                                                    title: "<?php echo e(t('app.confirm')); ?>",
                                                                    text: "<?php echo e(t('app.deleteConfirmText') ?? 'Are you sure you want to delete this item?'); ?>",
                                                                    icon: 'warning',
                                                                    showCancelButton: true,
                                                                    confirmButtonColor: '#d33',
                                                                    cancelButtonColor: '#6c757d',
                                                                    confirmButtonText: "<?php echo e(t('app.buttons.yesProceed') ?? 'Yes, delete'); ?>",
                                                                    cancelButtonText: "<?php echo e(t('app.buttons.cancel') ?? 'Cancel'); ?>"
                                                                }).then(function(result) {
                                                                    // Check for result.value instead of result.isConfirmed
                                                                    if (result.value === true) {
                                                                        document.getElementById('delete-form-<?php echo e($colour->id); ?>').submit();
                                                                    }
                                                                });
                                                            }
                                                        </script>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>

                        
                        <?php
                            $paginatedArray = $data['colours'];
                        ?>
                        <?php echo $__env->make('utilities.pages.others.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                    </div>

                </div>
                
                <div class="row mb-4 justify-content-center">
                    <div class="col-auto">
                        <?php switch($data['requestType']):
                            case ('search'): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('colours')); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            <?php break; ?>

                            <?php default: ?>
                        <?php endswitch; ?>
                    </div>
                </div>


                <!-- [Latest Leads] end -->


                
                <?php echo $__env->make('users.admin.products.colours.include.addColourModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/colours/colours.blade.php ENDPATH**/ ?>