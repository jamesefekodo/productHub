<?php $__env->startSection('title', t('app.product.category') . ' :: ' . $data['category']->category); ?>
<?php $__env->startSection('content'); ?>

    <div class="desktop-nav-bg"></div>
    <div class="main-content-wrapper">

        <section class="section">
            <?php
                $locale = currentLocale();
                $field = 'category_' . $locale;

                $catName =
                    isset($data['category']->$field) && $data['category']->$field
                        ? $data['category']->$field
                        : $data['category']->category;
            ?>


            <div class="my-page-header"><?php echo e($catName); ?></div>

            
            <?php
                $featuredProduct = featuredProducts()->where('category_id', $data['category']->id);
            ?>
            <?php if($featuredProduct->isNotEmpty()): ?>

                <h2 class="section-title text-center mt-5 mb-3"><?php echo e(t('app.product.featuredProducts')); ?></h2>

                <div class="cat-carousel owl-carousel owl-theme">
                    <?php $__currentLoopData = $featuredProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route(routePrefix() . 'ViewProduct', ['slug' => $product->slug])); ?>">
                            <div class="cat-card">
                                <?php
                                    $thumbnailImage = asset('system/images/icon_placeholder.png');

                                    if (!$product->mediaFiles->isEmpty()) {
                                        $primaryImage = $product->mediaFiles->where('is_primary', true)->first();

                                        if ($primaryImage) {
                                            $thumbnailImage = asset(
                                                'assets/uploads/products/products/media/images/' .
                                                    $primaryImage->file_name,
                                            );
                                        }
                                    }
                                ?>
                                <img src="<?php echo e($thumbnailImage); ?>" alt="<?php echo e($product->name); ?>">
                                <div class="cat-overlay">
                                    <?php
                                        $locale = currentLocale();
                                        $field = 'name_' . $locale;
                                        $prodName = !empty($product->$field) ? $product->$field : $product->name;
                                    ?>


                                    <h3><?php echo e($prodName); ?></h3>
                                    <?php if(displayPrice() == true): ?>
                                        <?php if(!is_null($product->price) && $product->price != 0): ?>
                                            <span class="price">₦<?php echo e(number_format($product->price, 2)); ?></span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            

            

            
            <?php if($data['category']->activeSubCategories->isNotEmpty()): ?>
                <div class="my-4">
                    <h2 class="section-title text-center mt-5 mb-3"><?php echo e(t('app.product.subCategories')); ?></h2>

                    <div class="cat-grid">
                        <?php $__currentLoopData = $data['category']->activeSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route(routePrefix() . 'ViewSubCategory', ['slug' => $subCat->slug])); ?>">
                                <div class="cat-card">
                                    <?php
                                        $imagePath = public_path(
                                            'assets/uploads/products/categories/subCategories/icons/' . $subCat->image,
                                        );
                                        $imageUrl = file_exists($imagePath)
                                            ? asset(
                                                'assets/uploads/products/categories/subCategories/icons/' .
                                                    $subCat->image,
                                            )
                                            : asset('system/images/icon_placeholder.png');

                                        $locale = currentLocale();
                                        $field = 'sub_category_' . $locale;
                                        $name = !empty($subCat->$field) ? $subCat->$field : $subCat->sub_category;
                                    ?>
                                    <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($name); ?>">
                                    <div class="cat-overlay">
                                        <h3><?php echo e($name); ?></h3>
                                        <p><?php
                                            $locale = currentLocale();
                                            $field = 'meta_description_' . $locale;
                                            $metaDesc = !empty($subCat->$field)
                                                ? $subCat->$field
                                                : $subCat->meta_description;

                                            $words = explode(' ', $metaDesc);
                                            $metaDescShort = implode(' ', array_slice($words, 0, 10));
                                            if (count($words) > 10) {
                                                $metaDescShort .= '...';
                                            }
                                        ?>
                                            <?php echo e($metaDescShort); ?>

                                        </p>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="my-4">
                <h2 class="section-title text-center mt-5 mb-3"><?php echo e(t('app.product.allProducts')); ?></h2>
                <?php if($data['category']->activeProducts->count() > 0): ?>
                    <div class="prod-grid">
                        <?php $__currentLoopData = $data['category']->activeProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route(routePrefix() . 'ViewProduct', ['slug' => $product->slug])); ?>">
                                <div class="prod-card">
                                    <?php if($product->is_featured == true): ?>
                                        <span class="prod-tag"><?php echo e(t('app.product.featured')); ?></span>
                                    <?php endif; ?>
                                    <div class="prod-img">
                                        <?php
                                            $thumbnailImage = asset('system/images/icon_placeholder.png');

                                            if (!$product->mediaFiles->isEmpty()) {
                                                $primaryImage = $product->mediaFiles
                                                    ->where('is_primary', true)
                                                    ->first();

                                                if ($primaryImage) {
                                                    $thumbnailImage = asset(
                                                        'assets/uploads/products/products/media/images/' .
                                                            $primaryImage->file_name,
                                                    );
                                                }
                                            }
                                        ?>

                                        <img src="<?php echo e($thumbnailImage); ?>" alt="<?php echo e($product->name); ?>">
                                    </div>
                                    <div class="prod-info">
                                        <h4>
                                            <?php
                                                $locale = currentLocale();
                                                $field = 'name_' . $locale;
                                                $value = !empty($product->$field) ? $product->$field : $product->name;
                                            ?>

                                            <?php echo e($value); ?>

                                        </h4>

                                        <?php if(displayPrice() == true): ?>
                                            <?php if(!is_null($product->price) && $product->price != 0): ?>
                                                <span class="price">₦<?php echo e(number_format($product->price, 2)); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <h3 class="text-danger">
                            <?php echo e(t('notifications.noRecordsFound')); ?>

                        </h3>
                    </div>
                <?php endif; ?>
            </div>

        </section>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/customer/products/viewCategory.blade.php ENDPATH**/ ?>