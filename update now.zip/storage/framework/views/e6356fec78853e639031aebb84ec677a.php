<script>
    function editBankAccountFormModal<?php echo e($account->id); ?>(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.buttons.edit')); ?> :: <?php echo e(t('app.payment.bankAccount')); ?>",
            showCloseButton: true,
            showConfirmButton: false,
            customClass: {
                popup: sizeClass
            },
            html: `
                <form id="swalForm" method="POST" action="<?php echo e(route('updateBankAccountSubmit', ['id' => $account->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.payment.bankName')); ?><span class="text-danger">*</span></label>
                        <input type="text" name="bank_name" class="form-control text-center" value="<?php echo e($account->bank_name); ?>" required>
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('bank_name')); ?></p>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.payment.accountNumber')); ?><span class="text-danger">*</span></label>
                        <input type="text" name="account_number" class="form-control text-center" value="<?php echo e($account->account_number); ?>" required>
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('account_number')); ?></p>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.payment.accountName')); ?><span class="text-danger">*</span></label>
                        <input type="text" name="account_name" class="form-control text-center" value="<?php echo e($account->account_name); ?>" required>
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('account_name')); ?></p>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <?php echo e(t('app.payment.currency')); ?>

                            <span class="text-danger">*</span>
                        </label>

                        <select name="currency" class="form-select text-center" required>
                            <option value="NGN" <?php echo e($account->currency == 'ngn' ? 'selected' : ''); ?>>NGN - Nigerian Naira</option>
                            <option value="USD" <?php echo e($account->currency == 'usd' ? 'selected' : ''); ?>>USD - US Dollar</option>
                            <option value="EUR" <?php echo e($account->currency == 'eur' ? 'selected' : ''); ?>>EUR - Euro</option>
                        </select>

                        <p style="color: red; font-size: 12px; margin-top: 5px;">
                            <?php echo e($errors->first('currency')); ?>

                        </p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.status.status')); ?><span class="text-danger">*</span></label>
                        <select class="form-select text-center" name="is_active" required>
                            <option selected disabled>
                                -<?php echo e(t('app.select')); ?>-
                            </option>

                            <option value="1" <?php echo e($account->is_active == 1 ? 'selected' : ''); ?>>
                                <?php echo e(t('app.status.active')); ?>

                            </option>

                            <option value="0" <?php echo e($account->is_active == 0 ? 'selected' : ''); ?>>
                                <?php echo e(t('app.status.inactive')); ?>

                            </option>
                        </select>
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('is_active')); ?></p>
                    </div>




                    <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
                </form>
            `
        });
    }
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/payments/settings/bankAccounts/include/editBankAccountModal.blade.php ENDPATH**/ ?>