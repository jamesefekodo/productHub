<nav id="navbar">
    <div class="logo">
        <a href="<?php echo e(config('app.url')); ?>">
            <img src="<?php echo e(systemWideLogo()); ?>" alt="logo" class="responsive-logo" />
            
        </a>
    </div>

    <ul class="nav-links" id="navLinks">
        <i class="fas fa-times mobile-close" onclick="toggleMobileMenu()"></i>

        <li class="nav-item"><a href="<?php echo e(config('app.url')); ?>"
                class="<?php echo e(request()->routeIs('homepage') ? 'active-link' : ''); ?>"><?php echo e(t('app.home')); ?></a></li>

        <li class="nav-item" onclick="this.classList.toggle('active')">
            <a href="javascript:void(0)"
                class="<?php echo e(Str::startsWith(request()->path(), ['category', 'categories', 'products', 'product']) ? 'active-link' : ''); ?>"><?php echo e(t('app.product.categories')); ?>

                <i class="fas fa-chevron-down" style="font-size: 10px; margin-left: 5px; transition: 0.3s;"></i>
            </a>
            <div class="mega-menu">
                <?php if(activeCategories()->isNotEmpty()): ?>
                    <?php $__currentLoopData = activeCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route(routePrefix() . 'ViewCategory', ['slug' => $category->slug])); ?>"
                            class="mega-option">
                            
                            <div class="row colmd-12">
                                <div class="col-md-4">
                                    <?php
                                        $imagePath = 'assets/uploads/products/categories/icons/' . $category->image;
                                    ?>

                                    <img src="<?php echo e($category->image && file_exists(public_path($imagePath))
                                        ? asset($imagePath)
                                        : asset('system/images/icon_placeholder.png')); ?>"
                                        class="img-fluid" alt="<?php echo e($category->name); ?>">
                                </div>
                                <div class="col-md-8">
                                    <strong>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'category_' . $locale;
                                            $catName = !empty($category->$field)
                                                ? $category->$field
                                                : $category->category;
                                        ?>
                                        <?php echo e($catName); ?>

                                    </strong>
                                    <p>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'meta_description_' . $locale;
                                            $catDesc = !empty($category->$field)
                                                ? $category->$field
                                                : $category->meta_description;

                                            $catDesc = strip_tags($catDesc);
                                        ?>

                                        <?php echo e(\Illuminate\Support\Str::limit($catDesc, 25, '...')); ?>

                                    </p>

                                </div>
                            </div>


                            <div>

                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </div>
        </li>

        <li class="nav-item" onclick="this.classList.toggle('active')">
            <a href="javascript:void(0)"
                class="<?php echo e(Str::startsWith(request()->path(), ['quote']) ? 'active-link' : ''); ?>"><?php echo e(t('app.product.quotes')); ?>

                <i class="fas fa-chevron-down" style="font-size: 10px; margin-left: 5px; transition: 0.3s;"></i>
            </a>
            <div class="mega-menu" style="width: 300px; grid-template-columns: 1fr;">
                <a href="<?php echo e(route(routePrefix() . 'NewQuoteList')); ?>"
                    class="mega-option <?php echo e(Str::startsWith(request()->path(), ['quote']) ? 'active-sub-menu' : ''); ?>">
                    <div><strong><?php echo e(t('app.draft')); ?>

                            <?php if(draftedQuote()): ?>
                                <?php if(draftedQuote()): ?>
                                    <span
                                        class="badge bg-danger text-white"><?php echo e(draftedQuote()->items->count()); ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </strong>
                    </div>
                </a>
                <a href="#" class="mega-option">
                    <div><strong><?php echo e(t('app.others')); ?></strong>
                    </div>
                </a>
            </div>
        </li>
        <li class="nav-item"><a href="#">About</a></li>

        <li class="nav-item"><a href="#">Blog</a></li>

        <li class="nav-item"><a href="#">Contact</a></li>


        <li class="nav-item ms-3" onclick="this.classList.toggle('active')">
            <?php
                $currentLocale = app()->getLocale();
                $currentLanguage = collect(activeLanguages())->firstWhere('language_code', $currentLocale);
            ?>
            <a href="javascript:void(0)"><img src="<?php echo e(asset('system/images/lang/' . $currentLanguage->flag)); ?>"
                    alt="" width="25px" class="me-2">
                <?php echo e($currentLanguage->language ?? strtoupper($currentLocale)); ?>

                <i class="fas fa-chevron-down" style="font-size: 10px; margin-left: 5px; transition: 0.3s;"></i>
            </a>
            <div class="mega-menu" style="width: 300px; grid-template-columns: 1fr;">
                <?php $__currentLoopData = activeLanguages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="?lang=<?php echo e($language->language_code); ?>"
                        class="mega-option <?php echo e($currentLocale === $language->language_code ? 'active' : ''); ?> text-center">
                        <img src="<?php echo e(asset('system/images/lang/' . $language->flag)); ?>" alt="" width="25px"
                            class="me-2">
                        <?php echo e($language->language); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </li>
    </ul>



    <div class="nav-right">
        <div class="nav-search">
            <form action="<?php echo e(route(routePrefix() . 'SearchProduct')); ?>">
                <input type="text" name="searchKey" placeholder="<?php echo e(t('app.product.productSearchPlaceholder')); ?>"
                    value="<?php echo e($data['searchKey'] ?? ''); ?>">
                <i class="fas fa-search"
                    style="position: absolute; right: 10px; top: 10px; font-size: 12px; opacity: 0.5;"></i>
                <button type="submit"></button>
            </form>
        </div>
        <div class="cart-trigger" onclick="toggleCart()">
            <i class="fas fa-shopping-bag"></i>
            <?php if(draftedQuote()): ?>
                <span class="cart-badge"><?php echo e(draftedQuote()->items->count()); ?></span>
            <?php endif; ?>
        </div>

        
        <?php if(auth()->check()): ?>
            <?php
                $user = auth()->user();
                $initials = '';

                if ($user->first_name && $user->last_name) {
                    $initials = strtoupper(substr($user->first_name, 0, 1) . substr($user->last_name, 0, 1));
                } elseif ($user->username) {
                    $initials = strtoupper(substr($user->username, 0, 1));
                } else {
                    $initials = 'U';
                }
            ?>
            <div class="nav-item dropdown stable-hover">
                <a class="nav-link d-flex align-items-center gap-2 py-2" href="#" id="userDropdown" role="button"
                    data-bs-toggle="dropdown">
                    <div class="avatar-box">
                        <?php if($user->photo): ?>
                            <img src="<?php echo e(asset('assets/uploads/users/photos/' . $user->photo)); ?>" class="rounded-circle border"
                                width="38" height="38" style="object-fit: cover;">
                        <?php else: ?>
                            <div class="avatar-initials">
                                <?php echo e($initials); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="d-none d-lg-block">
                        <span
                            class="d-block fw-bold text-black small line-height-1"><?php echo e($user->first_name ?? $user->username); ?></span>
                        
                    </div>
                </a>

                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 m-0" aria-labelledby="userDropdown">
                    <li class="px-3 py-3 bg-light">
                        <div class="fw-bold text-dark truncate"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></div>
                        <div class="text-muted smallest truncate"><?php echo e($user->email); ?></div>
                    </li>
                    <li>
                        <hr class="dropdown-divider m-0">
                    </li>
                    <li><a class="dropdown-item py-2 mt-1 text-center" href="<?php echo e(route('customerMyProfile')); ?>"><i class="bi bi-person me-2"></i><?php echo e(t('app.user.profile')); ?></a></li>
                    <li><a class="dropdown-item py-2 text-center" href="/settings"><i class="bi bi-gear me-2"></i> Settings</a>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li>
                        <form action="<?php echo e(route('logoutRequest')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item py-2 bg-danger text-white text-center fw-medium">
                                <i class="bi bi-box-arrow-right me-2"></i> <?php echo e(t('auth.logout')); ?>

                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        <?php else: ?>
            <div class="login-menu"><a href="<?php echo e(route($loginRoute)); ?>">
                    <?php echo e(t('auth.login')); ?>

                </a>
            </div>
        <?php endif; ?>
        

        <div class="menu-toggle" onclick="toggleMobileMenu()">
            <i class="fas fa-bars"></i>
        </div>
    </div>

</nav>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/layouts/include/userNavBar.blade.php ENDPATH**/ ?>