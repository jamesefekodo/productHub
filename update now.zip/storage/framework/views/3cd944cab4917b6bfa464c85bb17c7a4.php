<?php $__env->startSection('title', t('app.payment.paymentMethods')); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.payment.paymentMethods')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.payment.payment')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.settings.settings')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.payment.paymentMethods')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">

                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">
                
                <div class="col-md-2">
                    <?php echo $__env->make('users.admin.payments.settings.paymentMethods.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                
                <!-- [Latest Leads] start -->
                <div class="col-md-10">
                    <div class="col-xxl-12">
                        <div class="card stretch stretch-full">
                            <div class="card-header">
                                <h5 class="card-title">
                                    <?php echo e(t('app.payment.paymentMethods')); ?>

                                </h5>
                            </div>
                            <div class="card-body custom-card-action p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead>
                                            <tr class="border-b">
                                                <th scope="row">#</th>
                                                <th scope="row"><?php echo e(t('app.payment.paymentMethod')); ?></th>
                                                <th scope="row"><?php echo e(t('app.logo')); ?></th>
                                                <th scope="row"><?php echo e(t('app.version')); ?></th>
                                                <th scope="row">
                                                    <?php echo e(t('app.status.status')); ?>

                                                </th>
                                                <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                            </tr>
                                        </thead>
                                        <?php if($data['paymentMethods']->isEmpty()): ?>
                                            <tbody>
                                                <td colspan="6" class="text-center text-danger fw-bold fs-5">
                                                    <?php echo e(t('app.noRecordsFound')); ?>

                                                </td>
                                            </tbody>
                                        <?php else: ?>
                                            <tbody>
                                                <?php $__currentLoopData = $data['paymentMethods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo e($loop->iteration); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($method->name); ?>

                                                        </td>
                                                        <td>
                                                            <?php if($method->logo): ?>
                                                                <img src="<?php echo e(asset('system/images/paymentMethods/logo/' . $method->logo)); ?>"
                                                                    alt="" width="50px">
                                                            <?php else: ?>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($method->version): ?>
                                                            <span class="badge bg-soft-warning text-warning">
                                                                <?php echo e($method->version); ?>

                                                            </span>
                                                            <?php else: ?>
                                                            -
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php switch($method->status):
                                                                case ('active'): ?>
                                                                    <span
                                                                        class="badge bg-soft-success text-success"><?php echo e(t('app.status.active')); ?></span>
                                                                <?php break; ?>

                                                                <?php case ('inactive'): ?>
                                                                    <span
                                                                        class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.inactive')); ?></span>
                                                                <?php break; ?>

                                                                <?php default: ?>
                                                            <?php endswitch; ?>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-primary text-white cursor-pointer"
                                                                onclick="editPaymentMethodFormModal<?php echo e($method->id); ?>()"
                                                                id="edit-<?php echo e($method->id); ?>">
                                                                <i class="feather-edit"></i> <?php echo e(t('app.buttons.edit')); ?>

                                                            </span>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>


                <!-- [Latest Leads] end -->

                


                

                <?php if(!$data['paymentMethods']->isEmpty()): ?>
                    <?php $__currentLoopData = $data['paymentMethods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('users.admin.payments.settings.paymentMethods.include.editPaymentMethodModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                <?php if(session('editMethodId')): ?>
                                    const el = document.querySelector('[data-id="<?php echo e(session('editMethodId')); ?>"]');
                                    if (el) editPaymentMethodFormModal(el);
                                <?php endif; ?>
                            });
                        </script>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>




    


    
    
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/payments/settings/paymentMethods/paymentMethods.blade.php ENDPATH**/ ?>