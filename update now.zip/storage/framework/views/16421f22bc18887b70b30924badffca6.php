<?php $__env->startSection('title', t('app.buttons.edit') . '::' . $data['attribute']->name); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><a href="#"><?php echo e(t('app.product.attributes')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.attributes')); ?></a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e(t('app.buttons.view')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    

                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <div class="bg-white py-3 border-bottom rounded-0 p-md-0 mb-0">
            <div class="d-md-none d-flex">
                <a href="javascript:void(0)" class="page-content-left-open-toggle">
                    <i class="feather-align-left fs-20"></i>
                </a>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="tab-content">
                <div class="row col-md-12">
                    <div class="card stretch stretch-full">
                        <div class="card-body lead-status">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="fw-bold mb-0 me-4">
                                    <span class="d-block mb-2"><?php echo e(t('app.buttons.edit')); ?> ::
                                        <?php echo e(t('app.product.attribute')); ?>

                                        <?php
                                            $lang = $data['language'];
                                            $field = 'name_' . $lang;
                                            $value = !empty($data['attribute']->$field)
                                                ? $data['attribute']->$field
                                                : $data['attribute']->name;
                                        ?>
                                        (<?php echo e($value); ?>)
                                    </span>
                                    
                                </h5>
                                
                                <div class="d-flex flex-wrap justify-content-end gap-2">
                                    <?php $__currentLoopData = activeLanguages()->where('status', 'active'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('editAttribute', ['id' => $data['attribute']->id])); ?>?language=<?php echo e($language->language_code); ?>"
                                            class="btn btn-sm edit-by-lang <?php echo e($data['language'] == $language->language_code ? 'edit-by-lang-active' : ''); ?> d-flex align-items-center gap-1">
                                            <img src="<?php echo e(asset('system/images/lang/' . $language->flag)); ?>" alt=""
                                                width="22">
                                            <?php echo e($language->language); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                

                            </div>

                        </div>

                        <div class="card-body general-info">
                            <div class="card-body">
                                
                                <?php if($data['attribute']->attributeValues->count() > 0): ?>
                                    <?php $__currentLoopData = $data['attribute']->attributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attrValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <form action="<?php echo e(route('deleteAttributeValue', ['id' => $attrValue->id])); ?>"
                                            method="POST" id="delete-value-form-<?php echo e($attrValue->id); ?>"
                                            style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                
                                <form id="swalForm" method="POST"
                                    action="<?php echo e(route('updateAttributeSubmit', ['id' => $data['attribute']->id])); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <input type="hidden" name="language" value="<?php echo e($data['language']); ?>">

                                    <div class="row col-md-12">
                                        <div class="mb-4 col-md-8">
                                            <label class="form-label"><?php echo e(t('app.name')); ?> <span
                                                    class="text-danger">*</span></label>
                                            <?php
                                                $lang = $data['language'];
                                                $field = 'name_' . $lang;
                                                $value = !empty($data['attribute']->$field)
                                                    ? $data['attribute']->$field
                                                    : $data['attribute']->name;
                                            ?>
                                            <input type="text" class="form-control" value="<?php echo e($value); ?>"
                                                name="name" required>
                                            <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                                        </div>
                                        <div class="mb-4 col-md-4">
                                                <label class="form-label"><?php echo e(t('app.status.status')); ?> <span
                                                        class="text-danger">*</span></label>
                                                <select class="form-select text-center" name="is_active" required>
                                                    <option value="" disabled>- Select -</option>
                                                    <option value=1
                                                        <?php echo e($data['attribute']->is_active == 1 ? 'selected' : ''); ?>>
                                                        <?php echo e(t('app.status.active')); ?>

                                                    </option>
                                                    <option value=0
                                                        <?php echo e($data['attribute']->is_active == 0 ? 'selected' : ''); ?>>
                                                        <?php echo e(t('app.status.inactive')); ?>

                                                    </option>
                                                </select>
                                                <p id="status-error" class="text-danger"><?php echo e($errors->first('status')); ?>

                                                </p>
                                            </div>

                                        <p class="m-2 text-bold text-decoration-underline">
                                            <?php echo e(t('app.product.attributeValues')); ?>

                                        </p>

                                        
                                        <?php if($data['attribute']->attributeValues->count() > 0): ?>
                                            <?php $__currentLoopData = $data['attribute']->attributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attrValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mb-4 col-md-6 attribute-value-item">
                                                    <?php
                                                        $lang = $data['language'];
                                                        $field = 'value_' . $lang;
                                                        $toDisplay = !empty($attrValue->$field)
                                                            ? $attrValue->$field
                                                            : $attrValue->value;
                                                    ?>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control"
                                                            value="<?php echo e($toDisplay); ?>"
                                                            name="value[<?php echo e($attrValue->id); ?>]">

                                                        
                                                        <button type="button" class="btn btn-outline-danger"
                                                            onclick="event.preventDefault(); confirmDeleteValue<?php echo e($attrValue->id); ?>(); return false;">
                                                            &times;
                                                        </button>
                                                    </div>
                                                </div>

                                                <script>
                                                    function confirmDeleteValue<?php echo e($attrValue->id); ?>() {
                                                        Swal.fire({
                                                            title: "<?php echo e(t('app.confirm')); ?>",
                                                            text: "<?php echo e(t('app.deleteConfirmText') ?? 'Are you sure you want to delete this value?'); ?>",
                                                            icon: 'warning',
                                                            showCancelButton: true,
                                                            confirmButtonColor: '#d33',
                                                            cancelButtonColor: '#6c757d',
                                                            confirmButtonText: "<?php echo e(t('app.buttons.yesProceed') ?? 'Yes, delete'); ?>",
                                                            cancelButtonText: "<?php echo e(t('app.buttons.cancel') ?? 'Cancel'); ?>"
                                                        }).then(function(result) {
                                                            if (result.value === true) {
                                                                document.getElementById('delete-value-form-<?php echo e($attrValue->id); ?>').submit();
                                                            }
                                                        });
                                                    }
                                                </script>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        
                                        <div id="new-values-container"></div>

                                        
                                        <div class="mb-3">
                                            <button type="button" class="btn btn-sm btn-outline-primary"
                                                id="add-new-value-btn">
                                                <i class="feather-plus me-1"></i>
                                                <?php echo e(t('app.product.addAnotherValue') ?? 'Add New Value'); ?>

                                            </button>
                                        </div>

                                        <script>
                                            document.addEventListener('DOMContentLoaded', function() {
                                                const newContainer = document.getElementById('new-values-container');
                                                const addButton = document.getElementById('add-new-value-btn');

                                                if (addButton && newContainer) {
                                                    addButton.addEventListener('click', function() {
                                                        const newValueDiv = document.createElement('div');
                                                        newValueDiv.className = 'mb-4 col-md-12 attribute-value-item';
                                                        newValueDiv.innerHTML = `
                                                                    <div class="input-group">
                                                                        <input type="text" class="form-control"
                                                                            name="new_value[]"
                                                                            placeholder="<?php echo e(t('app.value') ?? 'Enter value'); ?>">
                                                                        <button type="button"
                                                                                class="btn btn-outline-danger remove-new-value"
                                                                                onclick="this.closest('.attribute-value-item').remove();">
                                                                            &times;
                                                                        </button>
                                                                    </div>
                                                                `;
                                                        newContainer.appendChild(newValueDiv);
                                                    });
                                                }
                                            });
                                        </script>
                                    </div>

                                    <button type="submit"
                                        class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.update')); ?></button>
                                </form>

                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-4 justify-content-center">
                        <div class="col-auto">
                            <a class="btn btn-primary" href="<?php echo e(route('attributes')); ?>">
                                <i class="fas fa-chevron-left"></i> &nbsp;
                                <?php echo e(t('app.buttons.back')); ?>

                            </a>
                        </div>
                    </div>


                </div>


            </div>
        </div>
        <!-- [ Main Content ] end -->


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/attributes/editAttribute.blade.php ENDPATH**/ ?>