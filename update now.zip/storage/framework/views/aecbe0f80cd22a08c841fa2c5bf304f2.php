<?php $__env->startSection('title', $data['pageTitle']); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.product.attributes')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.product.attributes')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <div class="dropdown">
                            <a class="btn btn-icon btn-light-brand" data-bs-toggle="dropdown" data-bs-offset="0, 10"
                                data-bs-auto-close="outside">
                                <i class="feather-filter"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="javascript:void(0);" class="dropdown-item filter-option active fw-bold"
                                    data-filter="all">
                                    <span class="wd-7 ht-7 bg-primary rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.all')); ?></span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="active">
                                    <span class="wd-7 ht-7 bg-success rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.active')); ?></span>
                                </a>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="inactive">
                                    <span class="wd-7 ht-7 bg-danger rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.inactive')); ?></span>
                                </a>
                            </div>
                        </div>
                        <button onclick="addAttributeFormModal('swal-size-md')" class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span><?php echo e(t('app.addNew')); ?></span>
                        </button>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">

                <!-- [Latest Leads] start -->
                <div class="col-xxl-12">
                    <div class="card stretch stretch-full">
                        <div class="card-header">
                            <h5 class="card-title">
                                <?php echo e($data['pageTitle']); ?>

                                
                            </h5>

                            

                            <div class="table-search">
                                <!-- Search form -->
                                <form method="GET" class="search-form" action="<?php echo e(route('attributesSearch')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="searchKey" class="form-control form-control-sm"
                                        placeholder="<?php echo e(t('app.search')); ?>..." value="<?php echo e($data['searchKey']); ?>">
                                </form>
                                <!-- Toggle button (visible only on mobile) -->
                                <button type="button" class="btn btn-sm btn-light search-toggle">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>


                            
                        </div>
                        <div class="card-body custom-card-action p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr class="border-b">
                                            <th scope="row">#</th>
                                            <th scope="row"><?php echo e(t('app.name')); ?></th>
                                            <th scope="row"><?php echo e(t('app.values')); ?></th>
                                            <th scope="row"><?php echo e(t('app.status.status')); ?></th>
                                            <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                        </tr>
                                    </thead>
                                    <?php if($data['attributes']->isEmpty()): ?>
                                        <tbody>
                                            <td colspan="5" class="text-center text-danger fw-bold fs-5">
                                                <?php echo e(t('app.noRecordsFound')); ?>

                                            </td>
                                        </tbody>
                                    <?php else: ?>
                                        <tbody>
                                            <?php $__currentLoopData = $data['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($loop->iteration); ?>

                                                    </td>
                                                    <td>
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $value = !empty($attr->$field)
                                                                ? $attr->$field
                                                                : $attr->name;
                                                        ?>
                                                        <?php echo e($value); ?>

                                                    </td>
                                                    <td>
                                                        <?php if($attr->attributeValues->count() > 0): ?>
                                                            <?php $__currentLoopData = $attr->attributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="badge text-black" style="background:#c9c9c9">
                                                                    <?php
                                                                        $locale = currentLocale();
                                                                        $field = 'value_' . $locale;
                                                                        $attributeValue = !empty($value->$field)
                                                                            ? $value->$field
                                                                            : $value->value;
                                                                    ?>

                                                                    <?php echo e($attributeValue); ?>

                                                                </span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            -
                                                        <?php endif; ?>

                                                    </td>
                                                    <td>
                                                        <?php switch($attr->is_active):
                                                            case (true): ?>
                                                                <span
                                                                    class="badge bg-soft-success text-success"><?php echo e(t('app.status.active')); ?></span>
                                                            <?php break; ?>

                                                            <?php case (false): ?>
                                                                <span
                                                                    class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.inactive')); ?></span>
                                                            <?php break; ?>

                                                            <?php default: ?>
                                                        <?php endswitch; ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('editAttribute', ['id' => $attr->id])); ?>?language=en"
                                                            class="badge bg-primary text-white cursor-pointer me-3">
                                                            <i class="feather-edit"></i> <?php echo e(t('app.buttons.edit')); ?>

                                                        </a>
                                                        <form action="<?php echo e(route('deleteAttribute', ['id' => $attr->id])); ?>"
                                                            method="POST" id="delete-form-<?php echo e($attr->id); ?>"
                                                            style="display: inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                        </form>

                                                        <a href="javascript:void(0)" class="badge bg-danger text-white me-3"
                                                            onclick="event.preventDefault(); confirmDelete<?php echo e($attr->id); ?>(); return false;">
                                                            <i class="feather-trash me-1"></i>
                                                            <?php echo e(t('app.buttons.delete')); ?>

                                                        </a>

                                                        <script>
                                                            function confirmDelete<?php echo e($attr->id); ?>() {
                                                                Swal.fire({
                                                                    title: "<?php echo e(t('app.confirm')); ?>",
                                                                    text: "<?php echo e(t('app.deleteConfirmText') ?? 'Are you sure you want to delete this item?'); ?>",
                                                                    icon: 'warning',
                                                                    showCancelButton: true,
                                                                    confirmButtonColor: '#d33',
                                                                    cancelButtonColor: '#6c757d',
                                                                    confirmButtonText: "<?php echo e(t('app.buttons.yesProceed') ?? 'Yes, delete'); ?>",
                                                                    cancelButtonText: "<?php echo e(t('app.buttons.cancel') ?? 'Cancel'); ?>"
                                                                }).then(function(result) {
                                                                    // Check for result.value instead of result.isConfirmed
                                                                    if (result.value === true) {
                                                                        document.getElementById('delete-form-<?php echo e($attr->id); ?>').submit();
                                                                    }
                                                                });
                                                            }
                                                        </script>


                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>

                        
                        <?php
                            $paginatedArray = $data['attributes'];
                        ?>
                        <?php echo $__env->make('utilities.pages.others.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                    </div>

                </div>
                
                <div class="row mb-4 justify-content-center">
                    <div class="col-auto">
                        <?php switch($data['requestType']):
                            case ('search'): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('attributes')); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            <?php break; ?>

                            <?php default: ?>
                        <?php endswitch; ?>
                    </div>
                </div>


                <!-- [Latest Leads] end -->


                
                <?php echo $__env->make('users.admin.products.attributes.include.addAttributeModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
            </div>
        </div>
        <!-- [ Main Content ] end -->

        
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                console.log('Filter script loaded');

                // Get all filter buttons
                const filterButtons = document.querySelectorAll('.filter-option');
                const tableRows = document.querySelectorAll('table tbody tr');

                console.log('Found filter buttons:', filterButtons.length);
                console.log('Found table rows:', tableRows.length);

                // Filter function
                function filterTable(status) {
                    console.log('Filtering by:', status);

                    let visibleCount = 0;

                    tableRows.forEach(row => {
                        // Skip "no records" row
                        if (row.querySelector('td[colspan]')) {
                            return;
                        }

                        // Get status badge
                        const statusBadge = row.querySelector('.badge');

                        if (!statusBadge) {
                            row.style.display = '';
                            return;
                        }

                        // Determine row status
                        let rowStatus = 'inactive';
                        if (statusBadge.classList.contains('bg-soft-success') ||
                            statusBadge.classList.contains('text-success')) {
                            rowStatus = 'active';
                        }

                        // Show/hide row
                        if (status === 'all' || rowStatus === status) {
                            row.style.display = '';
                            visibleCount++;
                        } else {
                            row.style.display = 'none';
                        }
                    });

                    console.log('Visible rows:', visibleCount);

                    // Update button states
                    filterButtons.forEach(btn => {
                        if (btn.getAttribute('data-filter') === status) {
                            btn.classList.add('active', 'fw-bold');
                            btn.style.backgroundColor = '#f0f4ff';
                        } else {
                            btn.classList.remove('active', 'fw-bold');
                            btn.style.backgroundColor = '';
                        }
                    });
                }

                // Add click event to each filter button
                filterButtons.forEach(button => {
                    button.addEventListener('click', function(e) {
                        e.preventDefault();
                        console.log('Filter clicked');

                        const filterValue = this.getAttribute('data-filter');
                        console.log('Filter value:', filterValue);

                        filterTable(filterValue);
                    });
                });

                // Set "All" as default
                console.log('Setting default filter to: all');
                filterTable('all');
            });
        </script>

        
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/attributes/attributes.blade.php ENDPATH**/ ?>