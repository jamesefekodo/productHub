<script>
    function editWhatsAppSupportFormModal<?php echo e($line->id); ?>(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.buttons.edit')); ?> :: <?php echo e(t('app.settings.address.whatsappNumber')); ?>",
            showCloseButton: true,
            showConfirmButton: false,
            customClass: {
                popup: sizeClass
            },
            html: `
                <form id="swalForm" method="POST" action="<?php echo e(route('updateWhatsAppNumberSubmit', ['id' => $line->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.name')); ?></label>
                        <input type="text" name="name" class="form-control text-center" value="<?php echo e(old('name', $line->name)); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.settings.address.whatsappNumber')); ?></label>
                        <input type="tel" name="number" class="form-control text-center"
                               value="<?php echo e(old('number', $line->number)); ?>"
                               placeholder="e.g. +2348012345678"
                               pattern="^\+?[0-9]{7,15}$" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.status.status')); ?></label>
                        <select class="form-select text-center" name="status" required>
                            <option value="" disabled>-<?php echo e(t('app.select')); ?>-</option>
                            <option value="active" <?php echo e(old('status', $line->status) == 'active' ? 'selected' : ''); ?>>
                                <?php echo e(t('app.status.active')); ?>

                            </option>
                            <option value="inactive" <?php echo e(old('status', $line->status) == 'inactive' ? 'selected' : ''); ?>>
                                <?php echo e(t('app.status.inactive')); ?>

                            </option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
                </form>
            `
        });
    }
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/config/homepage/include/editWhatsAppSupportModal.blade.php ENDPATH**/ ?>