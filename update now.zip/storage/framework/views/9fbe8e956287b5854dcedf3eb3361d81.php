<div class="card-footer">
    <ul class="list-unstyled d-flex align-items-center gap-2 mb-0 pagination-common-style">

        
        <li class="<?php echo e($paginatedArray->previousPageUrl() ? '' : 'disabled'); ?>">
            <a href="<?php echo e($paginatedArray->previousPageUrl() ?: 'javascript:void(0)'); ?>">
                <i class="bi bi-arrow-left"></i>
            </a>
        </li>

        
        <li class="px-2">
            <span>
                Showing <?php echo e($paginatedArray->count()); ?> results
            </span>
        </li>

        
        <li class="<?php echo e($paginatedArray->hasMorePages() ? '' : 'disabled'); ?>">
            <a href="<?php echo e($paginatedArray->nextPageUrl() ?: 'javascript:void(0)'); ?>">
                <i class="bi bi-arrow-right"></i>
            </a>
        </li>

    </ul>
</div>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/utilities/pages/others/pagination.blade.php ENDPATH**/ ?>