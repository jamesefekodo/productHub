<?php $__env->startSection('title', t('app.buttons.view') . '::' . $data['variant']->name); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><a href="#"><?php echo e($data['variant']->name); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.variant')); ?></a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e(t('app.buttons.view')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="<?php echo e(route('productVariations', ['slug' => $data['product']->slug])); ?>"
                            class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <div class="bg-white py-3 border-bottom rounded-0 p-md-0 mb-0">
            <div class="d-md-none d-flex">
                <a href="javascript:void(0)" class="page-content-left-open-toggle">
                    <i class="feather-align-left fs-20"></i>
                </a>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="tab-content">
                <div class="row col-md-12">
                    
                    <div class="col-md-2">
                        <?php echo $__env->make('users.admin.products.products.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    
                    <div class="tab-pane fade show active col-md-10" id="profileTab" role="tabpanel">
                        <div class="card card-body lead-info">
                            <div class="mb-4 d-flex align-items-center justify-content-between ps-5">
                                <h5 class="fw-bold mb-0">
                                    <span class="d-block mb-2"><?php echo e(t('app.product.product')); ?> ::

                                        <?php
                                            $locale = currentLocale();
                                            $field = 'name_' . $locale;
                                            $value = !empty($data['variant']->$field)
                                                ? $data['variant']->$field
                                                : $data['variant']->name;
                                        ?>

                                        <?php echo e($value); ?>

                                    </span>
                                    
                                </h5>
                            </div>
                            <div class="row col-md-12">
                                <?php echo $__env->make('users.admin.products.products.include.productMediaDisplay', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                                <div class="col-md-8 ps-5">
                                    <h4 class="fw-bold"><?php echo e(t('app.product.parentProduct')); ?></h4>
                                    <p><span class="fw-bold"><?php echo e(t('app.product.productName')); ?>:
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'name_' . $locale;
                                            $value = !empty($data['product']->$field)
                                                ? $data['product']->$field
                                                : $data['product']->name;
                                        ?>

                                        <?php echo e($value); ?>

                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.product.category')); ?>/<?php echo e(t('app.product.subCategory')); ?>:
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'category_' . $locale;
                                            $cat = !empty($data['product']->category->$field)
                                                ? $data['product']->category->$field
                                                : $data['product']->category->category;
                                        ?>

                                        <?php echo e($cat); ?>/<?php
                                            $locale = currentLocale();
                                            $field = 'sub_category_' . $locale;
                                            $subCat = !empty($data['product']->subCategory->$field)
                                                ? $data['product']->subCategory->$field
                                                : $data['product']->subCategory->sub_category;
                                        ?>

                                        <?php echo e($subCat); ?>

                                    </p>
                                    <div class="row col-md-12">
                                        <div class="col-md-6">
                                            <p><span class="fw-bold"><?php echo e(t('app.product.brand')); ?>:
                                                </span>
                                                <?php if($data['product']->brand): ?>
                                                    <?php
                                                        $logoPath = public_path(
                                                            'assets/uploads/products/brands/logo/' .
                                                                $data['product']->brand->logo,
                                                        );
                                                    ?>
                                                    <?php if($data['product']->brand->logo && file_exists($logoPath)): ?>
                                                        <img src="<?php echo e(asset('assets/uploads/products/brands/logo/' . $data['product']->brand->logo)); ?>"
                                                            width="30px">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('system/images/logo_placeholder.jpg')); ?>"
                                                            width="30px">
                                                    <?php endif; ?>
                                                    <?php echo e($data['product']->brand->brand); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </p>
                                            <p><span class="fw-bold"><?php echo e(t('app.product.sku')); ?>:
                                                </span>
                                                <?php echo e($data['product']->sku); ?>

                                            </p>
                                            <p><span class="fw-bold"><?php echo e(t('app.product.price')); ?>:
                                                </span>
                                                <?php if(!is_null($data['product']->price) && $data['product']->price != 0): ?>
                                                    ₦<?php echo e(number_format($data['product']->price, 2)); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                        <div class="col-md-6">
                                            <p> <span class="fw-bold"><?php echo e(t('app.product.availability')); ?>:
                                                </span>
                                                <?php switch($data['product']->is_available):
                                                    case (true): ?>
                                                        <span
                                                            class="badge bg-soft-success text-success"><?php echo e(t('app.status.available')); ?></span>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                        <span
                                                            class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.notAvailable')); ?></span>
                                                <?php endswitch; ?>
                                            </p>
                                            <p><span class="fw-bold"><?php echo e(t('app.published')); ?>:
                                                </span>
                                                <?php switch($data['product']->is_active):
                                                    case (true): ?>
                                                        <span
                                                            class="badge bg-soft-success text-success"><?php echo e(t('app.status.true')); ?></span>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                        <span
                                                            class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.false')); ?></span>
                                                <?php endswitch; ?>
                                            </p>
                                            <p> <span class="fw-bold"><?php echo e(t('app.product.featured')); ?>:
                                                </span>
                                                <?php switch($data['product']->is_featured):
                                                    case (true): ?>
                                                        <span
                                                            class="badge bg-soft-success text-success"><?php echo e(t('app.status.true')); ?></span>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                        <span
                                                            class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.false')); ?></span>
                                                <?php endswitch; ?>
                                            </p>
                                        </div>
                                        <p><span class="fw-bold"><?php echo e(t('app.shortDescription')); ?>: <br>
                                            </span>
                                            <?php
                                                $locale = currentLocale();
                                                $field = 'short_description_' . $locale;
                                                $shortDesc = !empty($data['product']->$field)
                                                    ? $data['product']->$field
                                                    : $data['product']->short_description;
                                            ?>

                                            <?php echo e($shortDesc); ?>

                                        </p>
                                    </div>
                                    <hr>
                                    

                                    <section class="product-variation">
                                        <h4 class="fw-bold"><?php echo e(t('app.product.variant')); ?></h4>
                                        <div class="row col-md-12">
                                            <div class="col-md-5">
                                                <div class="position-relative">

                                                    <img src="<?php echo e(optional($data['variant']->mediaFile)->file_name
                                                        ? asset('assets/uploads/products/products/media/images/' . $data['variant']->mediaFile->file_name)
                                                        : asset('system/images/icon_placeholder.png')); ?>"
                                                        alt="<?php echo e($data['variant']->name); ?>"
                                                        class="img-fluid w-100 rounded border"
                                                        style="object-fit:contain; max-height:400px;">

                                                    <button type="button" class="btn btn-sm btn-primary position-absolute"
                                                        style="bottom: 10px; right: 10px;"
                                                        onclick="openVariantImageModal(
                                                            '<?php echo e($data['variant']->mediaFile->id ?? ''); ?>',
                                                            '<?php echo e(optional($data['variant']->mediaFile)->file_name
                                                                ? asset('assets/uploads/products/products/media/images/' . $data['variant']->mediaFile->file_name)
                                                                : asset('system/images/icon_placeholder.png')); ?>'
                                                        )">
                                                        <i class="feather-edit me-2"></i>
                                                    </button>
                                                </div>
                                                
                                                <?php echo $__env->make('users.admin.products.products.variants.include.updateMediaFile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                
                                            </div>


                                            <div class="col-md-7">
                                                <p><span class="fw-bold"><?php echo e(t('app.name')); ?>:
                                                    </span>
                                                    <?php
                                                        $locale = currentLocale();
                                                        $field = 'name_' . $locale;
                                                        $value = !empty($data['variant']->$field)
                                                            ? $data['variant']->$field
                                                            : $data['variant']->name;
                                                    ?>

                                                    <?php echo e($value); ?>

                                                </p>
                                                <p><span class="fw-bold"><?php echo e(t('app.product.sku')); ?>:
                                                    </span>
                                                    <span class="text-uppercase"><?php echo e($data['variant']->sku); ?></span>
                                                </p>
                                                <p><span class="fw-bold"><?php echo e(t('app.product.price')); ?>:
                                                    </span>
                                                    <?php if(!is_null($data['variant']->price)): ?>
                                                        ₦<?php echo e(number_format($data['variant']->price, 2)); ?>

                                                    <?php endif; ?>
                                                </p>
                                                <p><span class="fw-bold"><?php echo e(t('app.published')); ?>:
                                                    </span>
                                                    <span
                                                        class="badge <?php echo e($data['variant']->is_active ? 'bg-soft-success text-success' : 'bg-soft-danger text-danger'); ?>"
                                                        data-type="active"
                                                        data-value="<?php echo e($data['variant']->is_active ? 1 : 0); ?>">
                                                        <?php echo e($data['variant']->is_active ? t('app.status.true') : t('app.status.false')); ?>

                                                    </span>
                                                </p>
                                                <p><span class="fw-bold"><?php echo e(t('app.product.availability')); ?>:
                                                    </span>
                                                    <span
                                                        class="badge <?php echo e($data['variant']->is_available ? 'bg-soft-success text-success' : 'bg-soft-danger text-danger'); ?>"
                                                        data-type="available"
                                                        data-value="<?php echo e($data['variant']->is_available ? 1 : 0); ?>">
                                                        <?php echo e($data['variant']->is_available ? t('app.status.available') : t('app.status.notAvailable')); ?>

                                                    </span>
                                                </p>
                                                <div class="my-1" style="display:flex; align-items:center; gap:8px;">

                                                    <span class="fw-bold"><?php echo e(t('app.product.colour')); ?>:</span>
                                                    <?php if($data['variant']->colour): ?>
                                                        <?php
                                                            $hex = preg_match(
                                                                '/^#[0-9A-Fa-f]{6}$/',
                                                                $data['variant']->colour->hex_code,
                                                            )
                                                                ? $data['variant']->colour->hex_code
                                                                : '#000000';
                                                        ?>


                                                        <span
                                                            style="width:60px; height:25px; background-color: <?php echo e($hex); ?>; border:1px solid #ccc; display:inline-block;">
                                                        </span>
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $value = !empty($data['variant']->colour->$field)
                                                                ? $data['variant']->colour->$field
                                                                : $data['variant']->colour->name;
                                                        ?>
                                                        <?php echo e($value); ?>

                                                        <span class="badge bg-soft-primary text-primary cursor-pointer me-2"
                                                            onclick="addProductVariantColourFormModal('swal-size-md')">
                                                            <i class="feather-edit"></i>
                                                        </span>
                                                        <span class="badge bg-soft-danger text-danger cursor-pointer"
                                                            onclick="removeProductVariantColourFormModal('swal-size-md')">
                                                            <i class="feather-trash"></i>
                                                        </span>
                                                    <?php else: ?>
                                                        <span
                                                            class="badge bg-soft-primary text-primary cursor-pointer me-2"
                                                            onclick="addProductVariantColourFormModal('swal-size-md')">
                                                            <i class="feather-plus"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                
                                                <div class="my-1 d-flex align-items-center flex-wrap" style="gap:8px;">
                                                    <span class="fw-bold"><?php echo e(t('app.product.otherAttributes')); ?>:</span>

                                                    <?php if($data['variant']->attributes->isNotEmpty()): ?>
                                                        <div style="display: flex; gap: 4px; flex-wrap: wrap;">
                                                            <?php $__currentLoopData = $data['variant']->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $locale = currentLocale();
                                                                    $nameField = 'name_' . $locale;
                                                                    $valueField = 'value_' . $locale;

                                                                    $attName = !empty($attribute->attribute->$nameField)
                                                                        ? $attribute->attribute->$nameField
                                                                        : $attribute->attribute->name;

                                                                    $attValue = !empty($attribute->value->$valueField)
                                                                        ? $attribute->value->$valueField
                                                                        : $attribute->value->value;

                                                                    // Add comma unless it's the last item
$separator =
    $index ==
    $data['variant']->attributes->count() - 1
        ? '.'
        : ',';
                                                                ?>

                                                                <span class="attribute-badge">
                                                                    <strong><?php echo e($attName); ?></strong>:
                                                                    <?php echo e($attValue); ?><?php echo e($separator); ?>

                                                                </span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>

                                                        
                                                        <span class="badge bg-soft-danger text-danger cursor-pointer"
                                                            onclick="removeProductAttributeFormModal('swal-size-md')">
                                                            <i class="feather-trash"></i>
                                                        </span>
                                                    <?php else: ?>
                                                        <span>-</span>
                                                    <?php endif; ?>

                                                    <span class="badge bg-soft-primary text-primary cursor-pointer"
                                                        onclick="addProductVariantAttributeFormModal('swal-size-md')">
                                                        <i class="feather-plus"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                                <div class="d-flex justify-content-end mt-3">
                                    <a href="<?php echo e(route('editProductVariant', ['slug' => $data['variant']->slug])); ?>?language=en"
                                        class="btn btn-primary">
                                        <i class="feather-edit me-2"></i> <?php echo e(t('app.buttons.edit')); ?>

                                    </a>
                                </div>
                            </div>

                        </div>
                        
                        <div class="row mb-4 justify-content-center">
                            <div class="col-auto">
                                <a class="btn btn-primary"
                                    href="<?php echo e(route('productVariations', ['slug' => $data['product']->slug])); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>


    
    <?php echo $__env->make('users.admin.products.products.variants.include.addProductVariantColourModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('users.admin.products.products.variants.include.removeProductVariantColourModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <?php echo $__env->make('users.admin.products.products.variants.include.addProductVariantAttributeModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('users.admin.products.products.variants.include.removeProductVarianceAttributeModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/variants/viewProductVariant.blade.php ENDPATH**/ ?>