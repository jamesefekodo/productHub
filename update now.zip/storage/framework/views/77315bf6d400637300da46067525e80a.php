<script>
    function editContactFormModal(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.buttons.edit')); ?> :: <?php echo e(t('app.settings.address.contactDetails')); ?>",
            showCloseButton: true,
            showConfirmButton: false, // no SweetAlert confirm button
            customClass: {
                popup: sizeClass
            },
            html: `
            <form id="swalForm" method="POST" action="<?php echo e(route('updateContactDetailsSubmit')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('auth.phone')); ?></label>
                    <input type="text" name="phone" class="form-control text-center" value="<?php echo e($data['systemSettings']->phone ?? ''); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('phone')); ?></p>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('auth.email')); ?></label>
                    <input type="email" name="email" class="form-control text-center" value="<?php echo e($data['systemSettings']->email ?? ''); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('email')); ?></p>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.settings.address.address')); ?></label>
                    <input type="text" name="address" class="form-control text-center" value="<?php echo e($data['systemSettings']->address ?? ''); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('address')); ?></p>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
            </form>
        `
        });
    }

    // Auto-open modal if there are validation errors
    document.addEventListener('DOMContentLoaded', function() {
        <?php if($errors->any()): ?>
            editContactFormModal();
        <?php endif; ?>
    });
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/config/homepage/include/editContactModal.blade.php ENDPATH**/ ?>