<div class="d-flex justify-content-center align-items-center w-100 mb-3 mt-3">
    <a href="<?php echo e(route('homepage')); ?>"><img src="<?php echo e(systemLogo()); ?>" class="logo img-fluid"
            style="width: 90px;" alt="<?php echo e(config('app.name')); ?>"></a>

</div>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/utilities/pages/auth/include/headerLogo.blade.php ENDPATH**/ ?>