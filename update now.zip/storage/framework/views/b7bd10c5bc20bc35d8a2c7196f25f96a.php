<?php $__env->startSection('title', t('auth.forgotPassword')); ?>
<?php $__env->startSection('content'); ?>
    <div class="outer-container">
        <?php echo $__env->make('utilities.pages.auth.include.slider', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="login-form">
            <div class="form-container">
                <?php echo $__env->make('utilities.pages.auth.include.headerLogo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                <h2 class="m-2 text-center auth_header"><?php echo e(t('auth.forgotPassword')); ?></h2>
                
                <form class="" action="<?php echo e(route('requestPasswordResetLink')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="email" placeholder="<?php echo e(t('auth.email')); ?>" name="email" required />
                    <p style="color: red"><?php echo e($errors->first('email')); ?></p>

                    <button type="submit"><?php echo e(t('auth.sendPassResetLink')); ?></button>
                </form>
                <?php echo $__env->make('utilities.pages.auth.include.socialiteAuth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="form-options my-4">
                    <p class=""><?php echo e(t('auth.haveAnAccount')); ?> <a
                            href="<?php echo e(route('loginPage')); ?>"><?php echo e(t('auth.login')); ?></a></p>
                    <p class=""><a
                            href="
                        <?php echo e(route('homepage')); ?>

                         "><?php echo e(t('app.homePage')); ?></a>
                    </p>

                    <div class="d-flex justify-content-end">
                        <div class="text-center">
                            <?php echo $__env->make('utilities.pages.others.changeLanguage', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/utilities/pages/auth/fogortPassword.blade.php ENDPATH**/ ?>