<script>
function addBankAccountFormModal(sizeClass = 'swal-size-md mx-5') {
    Swal.fire({
        title: "<?php echo e(t('app.addNew')); ?> :: <?php echo e(t('app.payment.bankAccount')); ?>",
        showCloseButton: true,
        showConfirmButton: false, // no SweetAlert confirm button
        customClass: {
            popup: sizeClass
        },
        html: `
            <form id="swalForm" method="POST" action="<?php echo e(route('createNewBankAccount')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.payment.bankName')); ?><span class="text-danger">*</span></label>
                    <input type="text" name="bank_name" class="form-control text-center" value="<?php echo e(old('bank_name')); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('bank_name')); ?></p>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.payment.accountNumber')); ?><span class="text-danger">*</span></label>
                    <input type="text" name="account_number" class="form-control text-center" value="<?php echo e(old('account_number')); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('account_number')); ?></p>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.payment.accountName')); ?><span class="text-danger">*</span></label>
                    <input type="text" name="account_name" class="form-control text-center" value="<?php echo e(old('account_name')); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('account_name')); ?></p>
                </div>
                <div class="mb-3">
                    <label class="form-label">
                        <?php echo e(t('app.payment.currency')); ?>

                        <span class="text-danger">*</span>
                    </label>

                    <select name="currency" class="form-select text-center" required>
                        <option value="NGN" <?php echo e(old('currency') == 'ngn' ? 'selected' : ''); ?>>NGN - Nigerian Naira</option>
                        <option value="USD" <?php echo e(old('currency') == 'usd' ? 'selected' : ''); ?>>USD - US Dollar</option>
                        <option value="EUR" <?php echo e(old('currency') == 'eur' ? 'selected' : ''); ?>>EUR - Euro</option>
                    </select>

                    <p style="color: red; font-size: 12px; margin-top: 5px;">
                        <?php echo e($errors->first('currency')); ?>

                    </p>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
            </form>
        `
    });
}

// Auto-open modal if there are validation errors
document.addEventListener('DOMContentLoaded', function() {
    <?php if($errors->any()): ?>
        addBankAccountFormModal();
    <?php endif; ?>
});
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/payments/settings/bankAccounts/include/addBankAccountModal.blade.php ENDPATH**/ ?>