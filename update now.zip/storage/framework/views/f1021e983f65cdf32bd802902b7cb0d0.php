<!-- Mobile toggle button -->
<button class="btn btn-outline-primary d-md-none w-100 mb-2" data-bs-toggle="collapse" data-bs-target="#innerNavMenu"
    aria-expanded="false" aria-controls="innerNavMenu">
    <i class="feather-menu me-1"></i> <?php echo e(t('app.menu')); ?>

</button>

<!-- Collapsible inner nav -->
<div id="innerNavMenu" class="collapse d-md-block">
    <div class="inner-nav">
        <h6 class="inner-nav-title text-center"><?php echo e(t('app.product.product')); ?></h6>

        <div class="inner-nav-list">
            <a href="<?php echo e(route('viewProduct', ['slug' => $data['product']->slug])); ?>"
                class="inner-nav-item <?php echo e(request()->routeIs('products', 'productsSearch', 'viewProduct', 'editProduct') ? 'active' : ''); ?>">
                <i data-feather="globe"></i>
                <?php echo e(t('app.product.product')); ?>

            </a>

            <a href="<?php echo e(route('productVariations', ['slug' => $data['product']->slug])); ?>"
                class="inner-nav-item <?php echo e(request()->routeIs('productVariations', 'addProductVariant','viewProductVariant', 'editProductVariant') ? 'active' : ''); ?>">

                <i data-feather="map"></i>
                <?php echo e(t('app.product.variations')); ?>

            </a>
        </div>
    </div>
</div>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/include/inner_nav.blade.php ENDPATH**/ ?>