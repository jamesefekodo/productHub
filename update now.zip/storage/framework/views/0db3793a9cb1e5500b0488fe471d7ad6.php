<!-- Button to open the modal manually -->


<script>
function addCountryFormModal(sizeClass = 'swal-size-md mx-5') {
    Swal.fire({
        title: "<?php echo e(t('app.addNew')); ?> :: <?php echo e(t('app.settings.address.country')); ?>",
        showCloseButton: true,
        showConfirmButton: false, // no SweetAlert confirm button
        customClass: {
            popup: sizeClass
        },
        html: `
            <form id="swalForm" method="POST" action="<?php echo e(route('createNewCountrySubmit')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.settings.address.country')); ?></label>
                    <input type="text" name="country" class="form-control text-center" value="<?php echo e(old('country')); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('country')); ?></p>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.settings.address.phoneCode')); ?></label>
                    <input type="text" name="phone_code" class="form-control text-center" value="<?php echo e(old('phone_code')); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('phone_code')); ?></p>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
            </form>
        `
    });
}

// Auto-open modal if there are validation errors
document.addEventListener('DOMContentLoaded', function() {
    <?php if($errors->any()): ?>
        addCountryFormModal();
    <?php endif; ?>
});
</script>

<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/settings/address/country/include/addCountryModal.blade.php ENDPATH**/ ?>