<?php $__env->startSection('title', t('app.buttons.view') . '::' . $data['quote']->slug); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><a href="#"><?php echo e(t('app.product.quotes')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><a
                                href="#"><?php echo e(t('app.sales.sales')); ?>/<?php echo e(t('app.sales.marketing')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.quotes')); ?></a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e(t('app.buttons.view')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <button onclick="addSubCategoryFormModal('swal-size-md')" class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span><?php echo e(t('app.product.addSubCategory')); ?></span>
                        </button>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <div class="bg-white py-3 border-bottom rounded-0 p-md-0 mb-0">
            <div class="d-md-none d-flex">
                <a href="javascript:void(0)" class="page-content-left-open-toggle">
                    <i class="feather-align-left fs-20"></i>
                </a>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="tab-content">
                <div class="row col-md-12">
                    <div class="tab-pane fade show active" id="profileTab" role="tabpanel">
                        <div class="card card-body lead-info">
                            <div class="mb-4 d-flex align-items-center justify-content-between ps-5">
                                <h5 class="fw-bold mb-0">
                                    <span class="d-block mb-2"><?php echo e(t('app.product.quote')); ?> ::
                                        <span class="text-uppercase"><?php echo e($data['quote']->slug); ?></span>
                                    </span>
                                    
                                </h5>
                            </div>
                            <div class="row col-md-12">
                                <div class="col-md-4 ps-5">
                                    <?php

                                        $image = asset('system/images/default_profile_pic.jpg');
                                        if (
                                            $data['quote']->customer &&
                                            $data['quote']->customer->photo &&
                                            file_exists(
                                                public_path(
                                                    'assets/uploads/users/photos/' . $data['quote']->customer->photo,
                                                ),
                                            )
                                        ) {
                                            $image = asset(
                                                'assets/uploads/users/photos/' . $data['quote']->customer->photo,
                                            );
                                        }
                                    ?>

                                    <img src="<?php echo e($image); ?>" class="img-fluid">
                                </div>
                                <div class="col-md-8 ps-5">
                                    <h5 class="text-decoration-underline"><?php echo e(t('app.sales.quoteRequestFrom')); ?></h5>
                                    <p><span class="fw-bold"><?php echo e(t('app.name')); ?>:
                                        </span>
                                        <?php
                                            $data['quote']->customer = $data['quote']->customer;

                                            $firstName =
                                                $data['quote']->customer->first_name ?? ($data['quote']->name ?? '');
                                            $middleName = $data['quote']->customer->middle_name ?? '';
                                            $lastName = $data['quote']->customer->last_name ?? '';
                                            $email = $data['quote']->customer->email1 ?? ($data['quote']->email ?? '');
                                            $phone = $data['quote']->customer->phone1 ?? ($data['quote']->phone ?? '');
                                        ?>

                                        <?php echo e(trim($firstName . ' ' . $middleName . ' ' . $lastName)); ?>

                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('auth.email')); ?>:
                                        </span>
                                        <?php if($data['quote']->customer): ?>
                                            <?php echo e($data['quote']->customer->email); ?>

                                        <?php else: ?>
                                            <?php echo e($data['quote']->email); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('auth.phone')); ?>:
                                        </span>
                                        <?php if($data['quote']->customer): ?>
                                            <?php echo e($data['quote']->customer->phone); ?>

                                        <?php else: ?>
                                            <?php echo e($data['quote']->phone); ?>

                                        <?php endif; ?>
                                    </p>
                                    
                                    <h5 class="text-decoration-underline"><?php echo e(t('app.sales.requestDetails')); ?></h5>
                                    <p><span class="fw-bold"><?php echo e(t('app.sales.ref')); ?>:
                                        </span>
                                        <span class="text-uppercase"><?php echo e($data['quote']->slug); ?>


                                        </span>
                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.dateSubmitted')); ?>:
                                        </span>
                                        <?php echo e(\Carbon\Carbon::parse($data['quote']->submitted_at)->isoFormat('MMMM Do, YYYY [at] h:mm A')); ?>

                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.status.status')); ?>:
                                        </span>
                                        <?php switch($data['quote']->status):
                                            case ('draft'): ?>
                                                <span class="badge bg-soft-warning text-warning"><?php echo e(t('app.status.draft')); ?></span>
                                            <?php break; ?>

                                            <?php case ('submitted'): ?>
                                                <span
                                                    class="badge bg-soft-warning text-warning"><?php echo e(t('app.status.submitted')); ?></span>
                                            <?php break; ?>

                                            <?php case ('quoted'): ?>
                                                <span
                                                    class="badge bg-soft-primary text-primary"><?php echo e(t('app.status.quoted')); ?></span>
                                            <?php break; ?>

                                            <?php case ('approved'): ?>
                                                <span
                                                    class="badge bg-soft-primary text-primary"><?php echo e(t('app.status.approved')); ?></span>
                                            <?php break; ?>

                                            <?php case ('rejected'): ?>
                                                <span
                                                    class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.rejected')); ?></span>
                                            <?php break; ?>

                                            <?php case ('expired'): ?>
                                                <span class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.expired')); ?></span>
                                            <?php break; ?>

                                            <?php case ('converted'): ?>
                                                <span
                                                    class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.converted')); ?></span>
                                            <?php break; ?>

                                            <?php default: ?>
                                                <?php echo e($data['quote']->status); ?>

                                        <?php endswitch; ?>
                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.address.address')); ?>:
                                        </span>
                                        <?php echo e($data['quote']->address); ?>

                                    </p>

                                    <div class="section-divider">
                                        <span><?php echo e(t('app.product.products')); ?></span>
                                    </div>
                                    <section class="product-variation">
                                        <div class="container-fluid">
                                            <?php if($data['quote']->items->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $data['quote']->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->variant): ?>
                                                        
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $variantName = !empty($item->variant->$field)
                                                                ? $item->variant->$field
                                                                : $item->variant->name;
                                                        ?>
                                                        <a href="<?php echo e(route('viewProductVariant', ['slug' => $item->variant->slug])); ?>"
                                                            class="variant-card-link text-decoration-none text-dark"
                                                            target="_blank">
                                                            <div class="card variant-card mb-4 border-0 shadow-sm">

                                                                <div class="card-body">
                                                                    <div class="row align-items-center">

                                                                        
                                                                        <div class="col-md-4 text-center mb-3 mb-md-0">
                                                                            <img src="<?php echo e(optional($item->variant->mediaFile)->file_name
                                                                                ? asset('assets/uploads/products/products/media/images/' . $item->variant->mediaFile->file_name)
                                                                                : asset('system/images/icon_placeholder.png')); ?>"
                                                                                alt="<?php echo e($variantName); ?>"
                                                                                class="img-fluid rounded border variant-image">
                                                                        </div>

                                                                        
                                                                        <div class="col-md-8">


                                                                            <h4 class="fw-bold mb-3">
                                                                                <span
                                                                                    class="badge bg-warning text-white fs-6 me-2"><?php echo e($loop->iteration); ?></span>
                                                                                <?php echo e($variantName); ?>

                                                                                <span class="fs-6 fw-normal text-muted">
                                                                                    :: <?php echo e(t('app.product.quantity')); ?> ->
                                                                                    <?php echo e($item->quantity); ?>

                                                                                </span>
                                                                            </h4>
                                                                            <div class="row">

                                                                                
                                                                                <div class="col-md-6">

                                                                                    <p class="mb-2">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.product.sku')); ?>:</span>
                                                                                        <span
                                                                                            class="text-uppercase"><?php echo e($item->variant->sku); ?></span>
                                                                                    </p>

                                                                                    <p class="mb-2">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.product.price')); ?>:</span>
                                                                                        <?php if(!is_null($item->variant->price)): ?>
                                                                                            <span
                                                                                                class="text-success fw-bold">
                                                                                                ₦<?php echo e(number_format($item->variant->price, 2)); ?>

                                                                                            </span>
                                                                                        <?php endif; ?>
                                                                                    </p>

                                                                                    <p class="mb-2">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.published')); ?>:</span>
                                                                                        <span
                                                                                            class="badge <?php echo e($item->variant->is_active ? 'bg-success' : 'bg-danger'); ?>">
                                                                                            <?php echo e($item->variant->is_active ? t('app.status.true') : t('app.status.false')); ?>

                                                                                        </span>
                                                                                    </p>

                                                                                    <p class="mb-0">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.product.availability')); ?>:</span>
                                                                                        <span
                                                                                            class="badge <?php echo e($item->variant->is_available ? 'bg-success' : 'bg-danger'); ?>">
                                                                                            <?php echo e($item->variant->is_available ? t('app.status.available') : t('app.status.notAvailable')); ?>

                                                                                        </span>
                                                                                    </p>

                                                                                </div>

                                                                                
                                                                                <div class="col-md-6">

                                                                                    
                                                                                    <p class="mb-3">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.product.colour')); ?>:</span>

                                                                                        <?php if($item->variant->colour): ?>
                                                                                            <?php
                                                                                                $hex = preg_match(
                                                                                                    '/^#[0-9A-Fa-f]{6}$/',
                                                                                                    $item->variant
                                                                                                        ->colour
                                                                                                        ->hex_code,
                                                                                                )
                                                                                                    ? $item->variant
                                                                                                        ->colour
                                                                                                        ->hex_code
                                                                                                    : '#000000';

                                                                                                $colourField =
                                                                                                    'name_' . $locale;
                                                                                                $colourName = !empty(
                                                                                                    $item->variant
                                                                                                        ->colour
                                                                                                        ->$colourField
                                                                                                )
                                                                                                    ? $item->variant
                                                                                                        ->colour
                                                                                                        ->$colourField
                                                                                                    : $item->variant
                                                                                                        ->colour->name;
                                                                                            ?>

                                                                                            <span
                                                                                                style="width:60px; height:25px; background-color: <?php echo e($hex); ?>; border:1px solid #ccc; display:inline-block;">
                                                                                            </span>
                                                                                            <?php echo e($colourName); ?>

                                                                                        <?php else: ?>
                                                                                            -
                                                                                        <?php endif; ?>
                                                                                    </p>

                                                                                    
                                                                                    <div>
                                                                                        <span
                                                                                            class="fw-semibold d-block mb-2">
                                                                                            <?php echo e(t('app.product.otherAttributes')); ?>:
                                                                                        </span>

                                                                                        <?php if($item->variant->attributes->isNotEmpty()): ?>
                                                                                            <div
                                                                                                class="d-flex flex-wrap gap-2">
                                                                                                <?php $__currentLoopData = $item->variant->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <?php
                                                                                                        $nameField =
                                                                                                            'name_' .
                                                                                                            $locale;
                                                                                                        $valueField =
                                                                                                            'value_' .
                                                                                                            $locale;

                                                                                                        $attName = !empty(
                                                                                                            $attribute
                                                                                                                ->attribute
                                                                                                                ->$nameField
                                                                                                        )
                                                                                                            ? $attribute
                                                                                                                ->attribute
                                                                                                                ->$nameField
                                                                                                            : $attribute
                                                                                                                ->attribute
                                                                                                                ->name;

                                                                                                        $attValue = !empty(
                                                                                                            $attribute
                                                                                                                ->value
                                                                                                                ->$valueField
                                                                                                        )
                                                                                                            ? $attribute
                                                                                                                ->value
                                                                                                                ->$valueField
                                                                                                            : $attribute
                                                                                                                ->value
                                                                                                                ->value;
                                                                                                    ?>

                                                                                                    <span
                                                                                                        class="attribute-badge">
                                                                                                        <?php echo e($attName); ?>:
                                                                                                        <?php echo e($attValue); ?>

                                                                                                    </span>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            </div>
                                                                                        <?php else: ?>
                                                                                            <span>-</span>
                                                                                        <?php endif; ?>
                                                                                    </div>

                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                <div class="d-flex justify-content-end m-2 ms-4">
                                                                    <a href="<?php echo e(route('viewProductVariant', ['slug' => $item->variant->slug])); ?>"
                                                                        class="btn btn-primary"
                                                                        target="_blank"><?php echo e(t('app.buttons.view')); ?></a>
                                                                </div>
                                                            </div>
                                                        </a>
                                                        
                                                    <?php else: ?>
                                                        
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $productName = !empty($item->product->$field)
                                                                ? $item->product->$field
                                                                : $item->product->name;
                                                        ?>
                                                        <a href="<?php echo e(route('viewProduct', ['slug' => $item->product->slug])); ?>"
                                                            class="variant-card-link text-decoration-none text-dark"
                                                            target="_blank">
                                                            <div class="card variant-card mb-4 border-0 shadow-sm">

                                                                <div class="card-body">
                                                                    <div class="row align-items-center">

                                                                        
                                                                        <?php
                                                                            $thumbnailImage = asset(
                                                                                'system/images/icon_placeholder.png',
                                                                            );

                                                                            if (
                                                                                !$item->product->mediaFiles->isEmpty()
                                                                            ) {
                                                                                $primaryImage = $item->product->mediaFiles
                                                                                    ->where('is_primary', true)
                                                                                    ->first();

                                                                                if ($primaryImage) {
                                                                                    $thumbnailImage = asset(
                                                                                        'assets/uploads/products/products/media/images/' .
                                                                                            $primaryImage->file_name,
                                                                                    );
                                                                                }
                                                                            }
                                                                        ?>

                                                                        
                                                                        
                                                                        <div class="col-md-4 text-center mb-3 mb-md-0">
                                                                            <img src="<?php echo e($thumbnailImage); ?>"
                                                                                alt="<?php echo e($productName); ?>"
                                                                                class="img-fluid rounded border variant-image">
                                                                        </div>

                                                                        
                                                                        <div class="col-md-8">

                                                                            <h4 class="fw-bold mb-3">
                                                                                <span
                                                                                    class="badge bg-warning text-white fs-6 me-2"><?php echo e($loop->iteration); ?></span>
                                                                                <?php echo e($productName); ?>

                                                                                <span class="fs-6 fw-normal text-muted">
                                                                                    :: <?php echo e(t('app.product.quantity')); ?> ->
                                                                                    <?php echo e($item->quantity); ?>

                                                                                </span>
                                                                            </h4>


                                                                            <div class="row">

                                                                                
                                                                                <div class="col-md-6">

                                                                                    <p class="mb-2">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.product.sku')); ?>:</span>
                                                                                        <span
                                                                                            class="text-uppercase"><?php echo e($item->product->sku); ?></span>
                                                                                    </p>

                                                                                    <p class="mb-2">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.product.price')); ?>:</span>
                                                                                        <?php if(!is_null($item->product->price)): ?>
                                                                                            <span
                                                                                                class="text-success fw-bold">
                                                                                                ₦<?php echo e(number_format($item->product->price, 2)); ?>

                                                                                            </span>
                                                                                        <?php endif; ?>
                                                                                    </p>

                                                                                    <p class="mb-2">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.published')); ?>:</span>
                                                                                        <span
                                                                                            class="badge <?php echo e($item->product->is_active ? 'bg-success' : 'bg-danger'); ?>">
                                                                                            <?php echo e($item->product->is_active ? t('app.status.true') : t('app.status.false')); ?>

                                                                                        </span>
                                                                                    </p>

                                                                                    <p class="mb-0">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.product.availability')); ?>:</span>
                                                                                        <span
                                                                                            class="badge <?php echo e($item->product->is_available ? 'bg-success' : 'bg-danger'); ?>">
                                                                                            <?php echo e($item->product->is_available ? t('app.status.available') : t('app.status.notAvailable')); ?>

                                                                                        </span>
                                                                                    </p>

                                                                                </div>

                                                                                
                                                                                <div class="col-md-6">

                                                                                    
                                                                                    <p class="mb-3">
                                                                                        <span
                                                                                            class="fw-semibold"><?php echo e(t('app.product.colour')); ?>:</span>

                                                                                        <?php if($item->product->colour): ?>
                                                                                            <?php
                                                                                                $hex = preg_match(
                                                                                                    '/^#[0-9A-Fa-f]{6}$/',
                                                                                                    $item->product
                                                                                                        ->colour
                                                                                                        ->hex_code,
                                                                                                )
                                                                                                    ? $item->product
                                                                                                        ->colour
                                                                                                        ->hex_code
                                                                                                    : '#000000';

                                                                                                $colourField =
                                                                                                    'name_' . $locale;
                                                                                                $colourName = !empty(
                                                                                                    $item->product
                                                                                                        ->colour
                                                                                                        ->$colourField
                                                                                                )
                                                                                                    ? $item->product
                                                                                                        ->colour
                                                                                                        ->$colourField
                                                                                                    : $item->product
                                                                                                        ->colour->name;
                                                                                            ?>

                                                                                            <span
                                                                                                style="width:60px; height:25px; background-color: <?php echo e($hex); ?>; border:1px solid #ccc; display:inline-block;">
                                                                                            </span>
                                                                                            <?php echo e($colourName); ?>

                                                                                        <?php else: ?>
                                                                                            -
                                                                                        <?php endif; ?>
                                                                                    </p>

                                                                                    
                                                                                    <div>
                                                                                        <span
                                                                                            class="fw-semibold d-block mb-2">
                                                                                            <?php echo e(t('app.product.otherAttributes')); ?>:
                                                                                        </span>

                                                                                        <?php if($item->product->attributes->isNotEmpty()): ?>
                                                                                            <div
                                                                                                class="d-flex flex-wrap gap-2">
                                                                                                <?php $__currentLoopData = $item->product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <?php
                                                                                                        $nameField =
                                                                                                            'name_' .
                                                                                                            $locale;
                                                                                                        $valueField =
                                                                                                            'value_' .
                                                                                                            $locale;

                                                                                                        $attName = !empty(
                                                                                                            $attribute
                                                                                                                ->attribute
                                                                                                                ->$nameField
                                                                                                        )
                                                                                                            ? $attribute
                                                                                                                ->attribute
                                                                                                                ->$nameField
                                                                                                            : $attribute
                                                                                                                ->attribute
                                                                                                                ->name;

                                                                                                        $attValue = !empty(
                                                                                                            $attribute
                                                                                                                ->value
                                                                                                                ->$valueField
                                                                                                        )
                                                                                                            ? $attribute
                                                                                                                ->value
                                                                                                                ->$valueField
                                                                                                            : $attribute
                                                                                                                ->value
                                                                                                                ->value;
                                                                                                    ?>

                                                                                                    <span
                                                                                                        class="attribute-badge">
                                                                                                        <?php echo e($attName); ?>:
                                                                                                        <?php echo e($attValue); ?>

                                                                                                    </span>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            </div>
                                                                                        <?php else: ?>
                                                                                            <span>-</span>
                                                                                        <?php endif; ?>
                                                                                    </div>

                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                <div class="d-flex justify-content-end m-2 ms-4">
                                                                    <a href="<?php echo e(route('viewProduct', ['slug' => $item->product->slug])); ?>"
                                                                        class="btn btn-primary"
                                                                        target="_blank"><?php echo e(t('app.buttons.view')); ?></a>
                                                                </div>
                                                            </div>
                                                        </a>
                                                        
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                        </div>
                                    </section>
                                </div>


                            </div>

                        </div>

                        <h3 class="inline-block bg-primary text-white px-3 py-1 text-center rounded">
                            GENERATE QUOTE
                        </h3>
                        <div class="card card-body lead-info">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit nemo, iste suscipit numquam
                            cumque voluptates neque maxime consectetur quas vero consequatur magni in? Doloribus non
                            repudiandae, temporibus tempora magni earum!
                        </div>
                        
                        <div class="row mb-4 justify-content-center">
                            <div class="col-auto">
                                <a class="btn btn-primary" href="<?php echo e(route('quoteRequests')); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            </div>
                        </div>
                    </div>

                </div>


            </div>


        </div>
        <!-- [ Main Content ] end -->
    </div>


    
    
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/salesMarketing/quotes/viewQuoteRequest.blade.php ENDPATH**/ ?>