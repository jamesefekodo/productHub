<?php $__env->startSection('title', $data['pageTitle']); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.product.brands')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.product.brands')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <button onclick="addBandFormModal('swal-size-md')" class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span><?php echo e(t('app.addNew')); ?></span>
                        </button>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">

                <!-- [Latest Leads] start -->
                <div class="col-xxl-12">
                    <div class="card stretch stretch-full">
                        <div class="card-header">
                            <h5 class="card-title">
                                <?php echo e($data['pageTitle']); ?>

                                
                            </h5>

                            

                            <div class="table-search">
                                <!-- Search form -->
                                <form method="GET" class="search-form" action="<?php echo e(route('brandsSearch')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="searchKey" class="form-control form-control-sm"
                                        placeholder="<?php echo e(t('app.search')); ?>..." value="<?php echo e($data['searchKey']); ?>">
                                </form>
                                <!-- Toggle button (visible only on mobile) -->
                                <button type="button" class="btn btn-sm btn-light search-toggle">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>


                            
                        </div>
                        <div class="card-body custom-card-action p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr class="border-b">
                                            <th scope="row">#</th>
                                            <th scope="row"><?php echo e(t('app.logo')); ?></th>
                                            <th scope="row"><?php echo e(t('app.name')); ?></th>
                                            <th scope="row">
                                                <?php echo e(t('app.description')); ?>

                                            </th>
                                            <th scope="row">
                                                <?php echo e(t('app.product.products')); ?>

                                            </th>
                                            <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                        </tr>
                                    </thead>
                                    <?php if($data['brands']->isEmpty()): ?>
                                        <tbody>
                                            <td colspan="6" class="text-center text-danger fw-bold fs-5">
                                                <?php echo e(t('app.noRecordsFound')); ?>

                                            </td>
                                        </tbody>
                                    <?php else: ?>
                                        <tbody>
                                            <?php $__currentLoopData = $data['brands']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($loop->iteration); ?>

                                                    </td>

                                                    <td>
                                                        <?php
                                                            $logoPath = public_path(
                                                                'assets/uploads/products/brands/logo/' . $brand->logo,
                                                            );
                                                        ?>

                                                        <?php if($brand->logo && file_exists($logoPath)): ?>
                                                            <img src="<?php echo e(asset('assets/uploads/products/brands/logo/' . $brand->logo)); ?>"
                                                                width="100">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('system/images/logo_placeholder.jpg')); ?>"
                                                                width="100">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo e($brand->brand); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e(\Illuminate\Support\Str::limit($brand->description, 50, '...')); ?>

                                                    </td>
                                                    <td>
                                                        0
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('viewBrand', ['slug' => $brand->slug])); ?>"
                                                            class="btn btn-primary d-inline-flex align-items-center gap-1">
                                                            <i class="feather-eye"></i>
                                                            <?php echo e(t('app.buttons.view')); ?>

                                                        </a>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>

                        
                        <?php
                            $paginatedArray = $data['brands'];
                        ?>
                        <?php echo $__env->make('utilities.pages.others.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                    </div>

                </div>
                
                <div class="row mb-4 justify-content-center">
                    <div class="col-auto">
                        <?php switch($data['requestType']):
                            case ('search'): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('brands')); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            <?php break; ?>

                            <?php default: ?>
                        <?php endswitch; ?>
                    </div>
                </div>


                <!-- [Latest Leads] end -->


                
                <?php echo $__env->make('users.admin.products.brands.include.addBrandModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/brands/brands.blade.php ENDPATH**/ ?>