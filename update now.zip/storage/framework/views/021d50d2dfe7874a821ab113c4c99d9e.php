<?php $__env->startSection('title', t('app.buttons.edit') . '::' . $data['product']->name); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><a href="#"><?php echo e($data['product']->name); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.products')); ?></a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e(t('app.buttons.edit')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <div class="bg-white py-3 border-bottom rounded-0 p-md-0 mb-0">
            <div class="d-md-none d-flex">
                <a href="javascript:void(0)" class="page-content-left-open-toggle">
                    <i class="feather-align-left fs-20"></i>
                </a>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="tab-content">
                <div class="row col-md-12">
                    <div class="card stretch stretch-full">
                        <div class="card-body lead-status">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="fw-bold mb-0 me-4">
                                    <span class="d-block mb-2"><?php echo e(t('app.buttons.edit')); ?> ::
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'name_' . $locale;
                                            $value = !empty($data['product']->$field)
                                                ? $data['product']->$field
                                                : $data['product']->name;
                                        ?>

                                        <?php echo e($value); ?>

                                    </span>
                                    
                                </h5>
                                
                                <div class="d-flex flex-wrap justify-content-end gap-2">
                                    <?php $__currentLoopData = activeLanguages()->where('status', 'active'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('editProduct', ['slug' => $data['product']->slug])); ?>?language=<?php echo e($language->language_code); ?>"
                                            class="btn btn-sm edit-by-lang <?php echo e($data['language'] == $language->language_code ? 'edit-by-lang-active' : ''); ?> d-flex align-items-center gap-1">
                                            <img src="<?php echo e(asset('system/images/lang/' . $language->flag)); ?>" alt=""
                                                width="22">
                                            <?php echo e($language->language); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                
                            </div>

                        </div>

                        <div class="card-body general-info">
                            <div class="card-body">
                                <form id="swalForm" method="POST"
                                    action="<?php echo e(route('updateProductSubmit', ['slug' => $data['product']->slug])); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <input type="hidden" name="language" value="<?php echo e($data['language']); ?>">

                                    <div class="row col-md-12">
                                        <div class="mb-4 col-md-6">
                                            <label class="form-label"><?php echo e(t('app.product.productName')); ?> <span
                                                    class="text-danger">*</span></label>
                                            <?php
                                                $lang = $data['language'];
                                                $field = 'name_' . $lang;
                                                $value = !empty($data['product']->$field)
                                                    ? $data['product']->$field
                                                    : $data['product']->name;
                                            ?>

                                            <?php echo e($value); ?>

                                            <input type="text" class="form-control" name="name"
                                                value="<?php echo e($value); ?>">
                                            <p class="text-danger"><?php echo e($errors->first('name')); ?>

                                            </p>
                                        </div>

                                        <div class="mb-4 col-md-6">
                                            <label class="form-label">
                                                <?php echo e(t('app.product.category')); ?>

                                                <span class="text-danger">*</span>
                                            </label>

                                            <select class="form-select text-center" name="category" id="categorySelect"
                                                required>
                                                <option value="" disabled selected>
                                                    - <?php echo e(t('app.select')); ?> -
                                                </option>

                                                <?php if(($data['allCategories'] ?? collect())->isNotEmpty()): ?>
                                                    <?php $__currentLoopData = $data['allCategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($category->slug); ?>"
                                                            <?php echo e($data['product']->category->slug == $category->slug ? 'selected' : ''); ?>>

                                                            <?php
                                                                $lang = $data['language'];
                                                                $field = 'category_' . $lang;
                                                                $value = !empty($category->$field)
                                                                    ? $category->$field
                                                                    : $category->category;
                                                            ?>

                                                            <?php echo e($value); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>

                                            <p class="text-danger"><?php echo e($errors->first('category')); ?></p>
                                        </div>


                                        <div class="mb-4 col-md-6">
                                            <label class="form-label">
                                                <?php echo e(t('app.product.subCategory')); ?>

                                                <span class="text-danger">*</span>
                                            </label>

                                            <select class="form-select text-center" name="sub_category"
                                                id="subCategorySelect" required>
                                                <option value="" disabled selected>
                                                    - <?php echo e(t('app.select')); ?> -
                                                </option>
                                            </select>

                                            <p class="text-danger"><?php echo e($errors->first('sub_category')); ?></p>
                                        </div>

                                        <div class="mb-4 col-md-6">
                                            <label class="form-label">
                                                <?php echo e(t('app.product.brand')); ?>

                                                <span class="text-danger">*</span>
                                            </label>

                                            <select class="form-select text-center" name="brand" required>
                                                <option value="" disabled selected>
                                                    - <?php echo e(t('app.select')); ?> -
                                                </option>

                                                <?php if(($data['brands'] ?? collect())->isNotEmpty()): ?>
                                                    <?php $__currentLoopData = $data['brands']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($brand->slug); ?>"
                                                            <?php echo e($data['product']->brand_id == $brand->id ? 'selected' : ''); ?>>
                                                            <?php echo e($brand->brand); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>

                                            <p class="text-danger"><?php echo e($errors->first('brand')); ?></p>
                                        </div>

                                        <div class="mb-4 col-md-12">
                                            <label class="form-label"><?php echo e(t('app.shortDescription')); ?></label>
                                            <?php
                                                $lang = $data['language'];
                                                $field = 'short_description_' . $lang;
                                                $shortDesc = !empty($data['product']->$field)
                                                    ? $data['product']->$field
                                                    : $data['product']->short_description;
                                            ?>
                                            <textarea class="form-control" name="short_description" style="min-height: 200px;"><?php echo e($shortDesc); ?></textarea>
                                            <p class="text-danger"><?php echo e($errors->first('short_description')); ?>

                                            </p>
                                        </div>
                                        <div class="mb-4 col-md-12">
                                            <label class="form-label"><?php echo e(t('app.shortDescription')); ?></label>
                                            <?php
                                                $lang = $data['language'];
                                                $field = 'description_' . $lang;
                                                $shortDesc = !empty($data['product']->$field)
                                                    ? $data['product']->$field
                                                    : $data['product']->description;
                                            ?>
                                            <textarea class="form-control" id="shortDescription" name="description" style="min-height: 400px;"><?php echo e($shortDesc); ?></textarea>
                                            <p class="text-danger"><?php echo e($errors->first('description')); ?></p>
                                        </div>
                                        <div class="mb-4 col-md-6">
                                            <label class="form-label"><?php echo e(t('app.product.sku')); ?></label>
                                            <input type="text" class="form-control" name="sku"
                                                value="<?php echo e($data['product']->sku); ?>">
                                            <p class="text-danger"><?php echo e($errors->first('sku')); ?>

                                            </p>
                                        </div>
                                        <div class="mb-4 col-md-6">
                                            <label class="form-label"><?php echo e(t('app.product.price')); ?> (₦)</label>
                                            <input type="text" class="form-control" name="price"
                                                value="<?php echo e($data['product']->price); ?>">
                                            <p class="text-danger"><?php echo e($errors->first('price')); ?>

                                            </p>
                                        </div>

                                        <div class="section-divider">
                                            <span><?php echo e(t('app.settings.seo.seo')); ?></span>
                                        </div>
                                        <div class="mb-4 col-md-12">
                                            <label class="form-label"><?php echo e(t('app.settings.seo.metaTitle')); ?></label>
                                            <?php
                                                $lang = $data['language'];
                                                $field = 'meta_title_' . $lang;
                                                $metaTitle = !empty($data['product']->$field)
                                                    ? $data['product']->$field
                                                    : $data['product']->meta_title;
                                            ?>
                                            <input type="text" class="form-control" name="meta_title"
                                                value="<?php echo e($metaTitle); ?>">
                                            <p id="status-error" class="text-danger"><?php echo e($errors->first('meta_title')); ?>

                                            </p>
                                        </div>
                                        <div class="mb-4 col-md-12">
                                            <label class="form-label"><?php echo e(t('app.settings.seo.metaKeywords')); ?></label>
                                            <?php
                                                $lang = $data['language'];
                                                $field = 'meta_keywords_' . $lang;
                                                $metaKeywords = !empty($data['product']->$field)
                                                    ? $data['product']->$field
                                                    : $data['product']->meta_keywords;
                                            ?>
                                            <input type="text" class="form-control" value="<?php echo e($metaKeywords); ?>"
                                                name="meta_keywords">
                                            <p id="status-error" class="text-danger">
                                                <?php echo e($errors->first('meta_keywords')); ?>

                                            </p>
                                        </div>
                                        <div class="mb-4 col-md-12">
                                            <label class="form-label"><?php echo e(t('app.settings.seo.metaDescription')); ?></label>
                                            <?php
                                                $lang = $data['language'];
                                                $field = 'meta_description_' . $lang;
                                                $metaDescription = !empty($data['product']->$field)
                                                    ? $data['product']->$field
                                                    : $data['product']->meta_description;
                                            ?>
                                            <textarea class="form-control" name="meta_description" style="min-height: 150px;"><?php echo e($metaDescription); ?></textarea>
                                            <p id="status-error" class="text-danger">
                                                <?php echo e($errors->first('meta_description')); ?>

                                            </p>
                                        </div>
                                        <div class="mb-4 col-md-4">
                                            <label class="form-label">
                                                <?php echo e(t('app.published')); ?>

                                                <span class="text-danger">*</span>
                                            </label>
                                            <select class="form-select text-center" name="is_active" required>

                                                <option value="" disabled>
                                                    - <?php echo e(t('app.select')); ?> -
                                                </option>

                                                <option value="1"
                                                    <?php echo e($data['product']->is_active ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.status.true')); ?>

                                                </option>

                                                <option value="0"
                                                    <?php echo e(!$data['product']->is_active ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.status.false')); ?>

                                                </option>

                                            </select>

                                            <p class="text-danger"><?php echo e($errors->first('is_active')); ?></p>
                                        </div>
                                        <div class="mb-4 col-md-4">
                                            <label class="form-label">
                                                <?php echo e(t('app.product.featured')); ?>

                                                <span class="text-danger">*</span>
                                            </label>
                                            <select class="form-select text-center" name="is_featured" required>

                                                <option value="" disabled>
                                                    - <?php echo e(t('app.select')); ?> -
                                                </option>

                                                <option value="1"
                                                    <?php echo e($data['product']->is_featured ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.status.true')); ?>

                                                </option>

                                                <option value="0"
                                                    <?php echo e(!$data['product']->is_featured ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.status.false')); ?>

                                                </option>

                                            </select>

                                            <p class="text-danger"><?php echo e($errors->first('is_featured')); ?></p>
                                        </div>
                                        <div class="mb-4 col-md-4">
                                            <label class="form-label">
                                                <?php echo e(t('app.product.availability')); ?>

                                                <span class="text-danger">*</span>
                                            </label>
                                            <select class="form-select text-center" name="is_available" required>

                                                <option value="" disabled>
                                                    - <?php echo e(t('app.select')); ?> -
                                                </option>

                                                <option value="1"
                                                    <?php echo e($data['product']->is_available ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.status.true')); ?>

                                                </option>

                                                <option value="0"
                                                    <?php echo e(!$data['product']->is_available ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.status.false')); ?>

                                                </option>

                                            </select>

                                            <p class="text-danger"><?php echo e($errors->first('is_available')); ?></p>
                                        </div>
                                    </div>

                                    <button type="submit"
                                        class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.update')); ?></button>


                                </form>

                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-4 justify-content-center">
                        <div class="col-auto">
                            <a class="btn btn-primary" href="<?php echo e(route('viewProduct', ['slug' => $data['product']->slug])); ?>">
                                <i class="fas fa-chevron-left"></i> &nbsp;
                                <?php echo e(t('app.buttons.back')); ?>

                            </a>
                        </div>
                    </div>


                </div>


            </div>
        </div>
        <!-- [ Main Content ] end -->

        <script>
            function previewPassport() {
                const preview = document.getElementById('passport-preview');
                const fileInput = document.getElementById('passport-upload');
                const file = fileInput.files[0];
                const reader = new FileReader();

                reader.onload = function() {
                    preview.src = reader.result;
                }

                if (file) {
                    reader.readAsDataURL(file);
                } else {
                    preview.src = 'placeholder.jpg';
                }
            }
        </script>

        
        <script>
            document.addEventListener("DOMContentLoaded", function() {

                let categorySelect = document.getElementById('categorySelect');
                let subCategorySelect = document.getElementById('subCategorySelect');

                const currentCategorySlug = "<?php echo e($data['product']->category->slug ?? ''); ?>";
                const currentSubCategorySlug = "<?php echo e($data['product']->subCategory->slug ?? ''); ?>";

                function loadSubCategories(categorySlug, selectSlug = null) {
                    subCategorySelect.innerHTML = '<option disabled selected>- <?php echo e(t('app.select')); ?> -</option>';

                    if (!categorySlug) return;

                    fetch('/get-subcategories/' + categorySlug)
                        .then(response => {
                            if (!response.ok) throw new Error("Network response not ok");
                            return response.json();
                        })
                        .then(data => {
                            let lang = "<?php echo e($data['language']); ?>";
                            let field = "sub_category_" + lang;

                            data.forEach(sub => {
                                let name = (sub[field] && sub[field] !== "") ? sub[field] : sub
                                    .sub_category;

                                let option = document.createElement('option');
                                option.value = sub.slug;
                                option.textContent = name;

                                if (selectSlug && sub.slug === selectSlug) {
                                    option.selected = true;
                                }

                                subCategorySelect.appendChild(option);
                            });
                        })
                        .catch(error => console.error("Error loading subcategories:", error));
                }

                // On page load
                if (currentCategorySlug) {
                    loadSubCategories(currentCategorySlug, currentSubCategorySlug);
                }

                // On category change
                categorySelect.addEventListener('change', function() {
                    loadSubCategories(this.value);
                });

            });
        </script>


        <script>
            tinymce.init({
                selector: '#shortDescription',
                height: 500,
                menubar: true,
                license_key: 'gpl',

                // Plugins: remove image, media
                plugins: [
                    'advlist', 'autolink', 'lists', 'link', 'charmap',
                    'preview', 'anchor', 'searchreplace', 'visualblocks', 'code',
                    'fullscreen', 'insertdatetime', 'table', 'codesample',
                    'help', 'wordcount', 'emoticons'
                ],

                // Toolbar: remove image/media buttons
                toolbar: [
                    'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough |',
                    'alignleft aligncenter alignright alignjustify |',
                    'bullist numlist outdent indent | forecolor backcolor |',
                    'link table | charmap emoticons codesample |',
                    'removeformat fullscreen preview code help'
                ].join(''),

                font_size_formats: '8pt 10pt 12pt 14pt 16pt 18pt 24pt 36pt 48pt',
                font_family_formats: 'Arial=arial,helvetica,sans-serif;' +
                    'Courier New=courier new,courier,monospace;' +
                    'Georgia=georgia,palatino;' +
                    'Tahoma=tahoma,arial,helvetica,sans-serif;' +
                    'Times New Roman=times new roman,times;' +
                    'Verdana=verdana,geneva;',

                content_style: `
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
            padding: 10px;
        }
    `,

                setup: function(editor) {
                    // Ensure content is synced to textarea for Laravel
                    editor.on('change', function() {
                        editor.save();
                    });
                }
            });

            // Ensure content is saved before form submit
            document.querySelector('form').addEventListener('submit', function() {
                tinymce.triggerSave();
            });
        </script>






    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/editProduct.blade.php ENDPATH**/ ?>