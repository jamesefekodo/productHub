<?php $__env->startSection('title', t('app.user.myProfile')); ?>
<?php $__env->startSection('content'); ?>

    <div class="desktop-nav-bg"></div>
    <div class="main-content-wrapper">

        <section class="section row col-md-12">
            
            <div class="col-md-2 mt-md-2">
                <?php echo $__env->make('users.customer.profile.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            
            <div class="col-md-10">
                <div class="my-page-header"><?php echo e(t('app.user.myProfile')); ?></div>

                <div class="my-4">
                    <div class="card shadow-sm border-0">
                        <div class="card-body p-0 row col-md-12">
                            <div class="col-md-4 justify-content-center text-center p-2" style="overflow: hidden;">
                                <?php if($data['user'] && $data['user']->photo): ?>
                                    <img src="<?php echo e(asset('assets/uploads/users/photos/' . $data['user']->photo)); ?>"
                                        alt="<?php echo e($data['user']->username); ?>"
                                        style="max-width: 100%; height: auto; object-fit: contain;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('system/images/default_profile_pic.jpg')); ?>" alt="Default Picture"
                                        style="max-width: 100%; height: auto; object-fit: contain;">
                                <?php endif; ?>
                            </div>
                            <div class="col-md-8 align-content-start">
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('app.user.username')); ?>:</span>
                                    <?php echo e($data['user']->username); ?>

                                </p>
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('app.user.fullName')); ?>:</span>
                                    <?php echo e($data['user']->first_name ?? ''); ?> <?php echo e($data['user']->middle_name ?? ''); ?>

                                    <?php echo e($data['user']->last_name ?? ''); ?></p>
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('app.user.username')); ?>:</span>
                                    <?php switch($data['user']->account_status):
                                        case ('1'): ?>
                                            <span class="badge bg-success-subtle text-success"><?php echo e(t('app.status.active')); ?></span>
                                        <?php break; ?>

                                        <?php default: ?>
                                            <span class="badge bg-danger-subtle text-danger"><?php echo e(t('app.status.inactive')); ?></span>
                                    <?php endswitch; ?>
                                </p>
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('auth.email')); ?>1:</span>
                                    <?php echo e($data['user']->email1); ?>

                                    <?php switch($data['user']->email1_verification):
                                        case ('verified'): ?>
                                            <span class="badge bg-success-subtle text-success d-inline-block text-wrap"
                                                style="white-space: normal; word-break: break-word; max-width: 100%;">
                                                <?php echo e(t('app.status.verified')); ?> →
                                                <?php echo e(\Carbon\Carbon::parse($data['user']->email1_verified_at)->format('l, d F, Y h:i:s A')); ?>

                                            </span>
                                        <?php break; ?>

                                        <?php default: ?>
                                            <span class="badge bg-danger-subtle text-danger"><?php echo e(t('app.status.unverified')); ?>

                                            </span>
                                    <?php endswitch; ?>
                                </p>
                                <?php if($data['user']->email2): ?>
                                    <p class="m-0"><span class="fw-bold"><?php echo e(t('auth.email')); ?>2:</span>
                                        <?php echo e($data['user']->email2); ?>

                                        <?php switch($data['user']->email2_verification):
                                            case ('verified'): ?>
                                                <span class="badge bg-success-subtle text-success d-inline-block text-wrap"
                                                    style="white-space: normal; word-break: break-word; max-width: 100%;">
                                                    <?php echo e(t('app.status.verified')); ?> →
                                                    <?php echo e(\Carbon\Carbon::parse($data['user']->email2_verified_at)->format('l, d F, Y h:i:s A')); ?>

                                                </span>
                                            <?php break; ?>

                                            <?php default: ?>
                                                <span class="badge bg-danger-subtle text-danger"><?php echo e(t('app.status.unverified')); ?>

                                                </span>
                                        <?php endswitch; ?>
                                    </p>
                                <?php endif; ?>
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('auth.phone')); ?>:</span>
                                    <?php echo e($data['user']->phone1); ?>

                                    <?php if($data['user']->phone2): ?>
                                        /<?php echo e($data['user']->phone2); ?>

                                    <?php endif; ?>
                                </p>
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('app.user.gender')); ?>:</span>
                                    <?php switch($data['user']->gender):
                                        case ('male'): ?>
                                            <?php echo e(t('app.user.male')); ?>

                                        <?php break; ?>

                                        <?php case ('female'): ?>
                                            <?php echo e(t('app.user.female')); ?>

                                        <?php break; ?>

                                        <?php default: ?>
                                    <?php endswitch; ?>

                                </p>
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('app.user.dateOfBirth')); ?>:</span>
                                    <?php if($data['user']->date_of_birth): ?>
                                        <?php echo e(\Carbon\Carbon::parse($data['user']->date_of_birth)->format('l, d F, Y')); ?>

                                    <?php endif; ?>
                                </p>
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('app.user.nationality')); ?>:</span>
                                    <?php echo e($data['user']->nationality); ?>

                                </p>
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('app.language.language')); ?>:</span>
                                    <?php echo e($data['user']->language->language); ?>

                                </p>
                                <p class="m-0"><span class="fw-bold"><?php echo e(t('app.user.requireMfa')); ?>:</span>
                                    <?php switch($data['user']->require_login_mfa):
                                        case (true): ?>
                                            <span class="badge bg-success-subtle text-success"><?php echo e(t('app.status.true')); ?>

                                            </span>
                                        <?php break; ?>

                                        <?php default: ?>
                                            <span class="badge bg-danger-subtle text-danger"><?php echo e(t('app.status.false')); ?>

                                            </span>
                                    <?php endswitch; ?>
                                </p>
                                
                                <div class="">
                                    <p class="m-0"><span
                                            class="fw-bold"><?php echo e(t('app.settings.address.addresses')); ?>:</span>
                                        <?php if(!$data['user']->addresses->count() > 0): ?>
                                            <span class="text-danger">
                                                <?php echo e(t('app.settings.address.noAddressFound')); ?>

                                            </span>

                                            <span onclick="addNewAddressFormModal('swal-size-md')"
                                                class="bagde bg-primary text-white">
                                                <i class="fas fa-plus p-1"></i></span>
                                            </span>
                                        <?php else: ?>
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <?php $__currentLoopData = $data['user']->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-6 mb-3">
                                                            <div class="card shadow-sm h-100">
                                                                <div class="card-body">
                                                                    <?php echo e($address->more_details); ?>,
                                                                    <?php echo e($address->theCity->name); ?>,
                                                                    <?php echo e($address->theState->name); ?>,
                                                                    <?php echo e($address->theCountry->name); ?>

                                                                    <?php if($address->is_primary): ?>
                                                                        <span
                                                                            class="badge bg-primary-subtle text-primary"><?php echo e(t('app.settings.address.primaryAddress')); ?></span>
                                                                    <?php endif; ?>
                                                                </div>

                                                                <div
                                                                    class="card-footer bg-white border-0 d-flex justify-content-between">
                                                                    <a class="btn btn-sm btn-outline-primary cursor-pointer"
                                                                        onclick="editAddressFormModal<?php echo e($address->id); ?>()"
                                                                        id="edit-<?php echo e($address->id); ?>">
                                                                        <?php echo e(t('app.buttons.edit')); ?>

                                                                    </a>

                                                                    <form
                                                                        action="<?php echo e(route('customerAddressDelete', $address->id)); ?>"
                                                                        method="POST" class="delete-address-form">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>

                                                                        <button type="submit"
                                                                            class="btn btn-sm btn-outline-danger">
                                                                            <?php echo e(t('app.buttons.delete')); ?>

                                                                        </button>
                                                                    </form>
                                                                </div>


                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <button type="button" onclick="addNewAddressFormModal('swal-size-md')"
                                                class="btn btn-primary d-inline-flex align-items-center gap-2 px-3 py-2 shadow-sm">
                                                <i class="fas fa-plus"></i>
                                                <?php echo e(t('app.settings.address.newAddress')); ?>

                                            </button>
                                        <?php endif; ?>
                                    </p>
                                </div>

                            </div>
                            <div class="d-flex justify-content-end mb-4">
                                <a href="<?php echo e(route('customerEditProfile')); ?>"
                                    class="btn btn-primary d-inline-flex align-items-center gap-2 px-3 py-2 shadow-sm text-white"><i
                                        class="fas fa-edit me-2"></i><?php echo e(t('app.user.updateProfile')); ?> </a>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </section>
    </div>


    
    <script>
        $(document).on('submit', '.delete-address-form', function(e) {
            e.preventDefault(); // stop normal form submission

            let form = this;

            Swal.fire({
                title: "<?php echo e(t('app.confirm')); ?>",
                text: "<?php echo e(t('app.confirm')); ?>",
                icon: "<?php echo e(t('app.deleteConfirmText')); ?>",
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // submit if confirmed
                }
            });
        });
    </script>

    
    <?php echo $__env->make('users.customer.profile.include.addNewAddress', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if(!$data['user']->addresses->isEmpty()): ?>
        <?php $__currentLoopData = $data['user']->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('users.customer.profile.include.editAddressModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    <?php if(session('editAddressId')): ?>
                        const el = document.querySelector('[data-id="<?php echo e(session('editAddressId')); ?>"]');
                        if (el) editAddressFormModal(el);
                    <?php endif; ?>
                });
            </script>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/customer/profile/viewProfile.blade.php ENDPATH**/ ?>