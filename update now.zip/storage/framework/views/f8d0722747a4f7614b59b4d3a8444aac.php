<?php $__env->startSection('title', t('app.buttons.edit') . '::' . $data['variant']->name); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><a href="#"><?php echo e($data['variant']->name); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.variations')); ?></a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e(t('app.buttons.edit')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <div class="bg-white py-3 border-bottom rounded-0 p-md-0 mb-0">
            <div class="d-md-none d-flex">
                <a href="javascript:void(0)" class="page-content-left-open-toggle">
                    <i class="feather-align-left fs-20"></i>
                </a>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">
                <div class="col-md-2">
                    <?php echo $__env->make('users.admin.products.products.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="col-md-10">
                    <div class="tab-content">
                        <div class="row col-md-12">
                            <div class="card stretch stretch-full">
                                <div class="card-body lead-status">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h5 class="fw-bold mb-0 me-4">
                                            <span class="d-block mb-2"><?php echo e(t('app.buttons.edit')); ?> ::
                                                <?php
                                                    $locale = currentLocale();
                                                    $field = 'name_' . $locale;
                                                    $value = !empty($data['variant']->$field)
                                                        ? $data['variant']->$field
                                                        : $data['variant']->name;
                                                ?>

                                                <?php echo e($value); ?>

                                            </span>
                                            
                                        </h5>
                                        
                                        <div class="d-flex flex-wrap justify-content-end gap-2">
                                            <?php $__currentLoopData = activeLanguages()->where('status', 'active'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e(route('editProductVariant', ['slug' => $data['variant']->slug])); ?>?language=<?php echo e($language->language_code); ?>"
                                                    class="btn btn-sm edit-by-lang <?php echo e($data['language'] == $language->language_code ? 'edit-by-lang-active' : ''); ?> d-flex align-items-center gap-1">
                                                    <img src="<?php echo e(asset('system/images/lang/' . $language->flag)); ?>"
                                                        alt="" width="22">
                                                    <?php echo e($language->language); ?>

                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                        
                                    </div>

                                </div>

                                <div class="card-body general-info">
                                    <div class="card-body">
                                        <form id="swalForm" method="POST"
                                            action="<?php echo e(route('updateSubProductSubmit', ['slug' => $data['variant']->slug])); ?>

                                         "
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>

                                            <input type="hidden" name="language" value="<?php echo e($data['language']); ?>">


                                            <div class="row col-md-12">
                                                <div class="mb-4 col-md-6">
                                                    <label class="form-label"><?php echo e(t('app.product.productName')); ?> <span
                                                            class="text-danger">*</span></label>
                                                    <?php
                                                        $lang = $data['language'];
                                                        $field = 'name_' . $lang;
                                                        $varName = !empty($data['variant']->$field)
                                                            ? $data['variant']->$field
                                                            : $data['variant']->name;
                                                    ?>
                                                    <input type="text" class="form-control" name="name"
                                                        value="<?php echo e($varName); ?>" required>
                                                    <p class="text-danger"><?php echo e($errors->first('name')); ?>

                                                    </p>
                                                </div>

                                                <div class="mb-4 col-md-6">
                                                    <label class="form-label"><?php echo e(t('app.product.sku')); ?></label>
                                                    <input type="text" class="form-control" name="sku"
                                                        value="<?php echo e($data['variant']->sku); ?>">
                                                    <p class="text-danger"><?php echo e($errors->first('sku')); ?>

                                                    </p>
                                                </div>

                                                <div class="mb-4 col-md-4">
                                                    <label class="form-label"><?php echo e(t('app.product.price')); ?> (₦)</label>
                                                    <input type="text" class="form-control" name="price"
                                                        value="<?php echo e($data['variant']->price); ?>">
                                                    <p class="text-danger"><?php echo e($errors->first('price')); ?>

                                                    </p>
                                                </div>
                                                <div class="mb-4 col-md-4">
                                                    <label class="form-label">
                                                        <?php echo e(t('app.published')); ?>

                                                        <span class="text-danger">*</span>
                                                    </label>
                                                    <select class="form-select text-center" name="is_active" required>

                                                        <option value="" disabled>
                                                            - <?php echo e(t('app.select')); ?> -
                                                        </option>

                                                        <option value="1"
                                                            <?php echo e($data['variant']->is_active ? 'selected' : ''); ?>>
                                                            <?php echo e(t('app.status.true')); ?>

                                                        </option>

                                                        <option value="0"
                                                            <?php echo e(!$data['variant']->is_active ? 'selected' : ''); ?>>
                                                            <?php echo e(t('app.status.false')); ?>

                                                        </option>

                                                    </select>

                                                    <p class="text-danger"><?php echo e($errors->first('is_active')); ?></p>
                                                </div>
                                                <div class="mb-4 col-md-4">
                                                    <label class="form-label">
                                                        <?php echo e(t('app.product.availability')); ?>

                                                        <span class="text-danger">*</span>
                                                    </label>
                                                    <select class="form-select text-center" name="is_available" required>

                                                        <option value="" disabled>
                                                            - <?php echo e(t('app.select')); ?> -
                                                        </option>

                                                        <option value="1"
                                                            <?php echo e($data['variant']->is_available ? 'selected' : ''); ?>>
                                                            <?php echo e(t('app.status.true')); ?>

                                                        </option>

                                                        <option value="0"
                                                            <?php echo e(!$data['variant']->is_available ? 'selected' : ''); ?>>
                                                            <?php echo e(t('app.status.false')); ?>

                                                        </option>

                                                    </select>

                                                    <p class="text-danger"><?php echo e($errors->first('is_available')); ?></p>
                                                </div>
                                            </div>

                                            <button type="submit"
                                                class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.update')); ?></button>


                                        </form>

                                    </div>
                                </div>
                            </div>
                            
                            <div class="row mb-4 justify-content-center">
                                <div class="col-auto">
                                    <a class="btn btn-primary"
                                        href="<?php echo e(route('productVariations', ['slug' => $data['product']->slug])); ?>">
                                        <i class="fas fa-chevron-left"></i> &nbsp;
                                        <?php echo e(t('app.buttons.back')); ?>

                                    </a>
                                </div>
                            </div>


                        </div>


                    </div>
                </div>
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/variants/editProductVariant.blade.php ENDPATH**/ ?>