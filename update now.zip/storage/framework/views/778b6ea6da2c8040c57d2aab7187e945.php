<?php $__env->startSection('title', t('app.buttons.view') . '::' . $data['product']->name); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><a href="#"><?php echo e($data['product']->name); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.product')); ?></a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e(t('app.buttons.view')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <a href="<?php echo e(route('addProductVariant', ['slug' => $data['product']->slug])); ?>"
                            class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span><?php echo e(t('app.product.addProductVariant')); ?></span>
                        </a>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <div class="bg-white py-3 border-bottom rounded-0 p-md-0 mb-0">
            <div class="d-md-none d-flex">
                <a href="javascript:void(0)" class="page-content-left-open-toggle">
                    <i class="feather-align-left fs-20"></i>
                </a>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="tab-content">
                <div class="row col-md-12">
                    
                    <div class="col-md-2">
                        <?php echo $__env->make('users.admin.products.products.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    
                    <div class="tab-pane fade show active col-md-10" id="profileTab" role="tabpanel">
                        <div class="card card-body lead-info">
                            <div class="mb-4 d-flex align-items-center justify-content-between ps-5">
                                <h5 class="fw-bold mb-0">
                                    <span class="d-block mb-2"><?php echo e(t('app.product.product')); ?> ::

                                        <?php
                                            $locale = currentLocale();
                                            $field = 'name_' . $locale;
                                            $value = !empty($data['product']->$field)
                                                ? $data['product']->$field
                                                : $data['product']->name;
                                        ?>

                                        <?php echo e($value); ?>

                                    </span>
                                    
                                </h5>
                            </div>
                            <div class="row col-md-12">
                                <?php echo $__env->make('users.admin.products.products.include.productMediaDisplay', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



                                <div class="col-md-8 ps-5">
                                    <p><span class="fw-bold"><?php echo e(t('app.product.productName')); ?>:
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'name_' . $locale;
                                            $value = !empty($data['product']->$field)
                                                ? $data['product']->$field
                                                : $data['product']->name;
                                        ?>

                                        <?php echo e($value); ?>

                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.product.category')); ?>/<?php echo e(t('app.product.subCategory')); ?>:
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'category_' . $locale;
                                            $cat = !empty($data['product']->category->$field)
                                                ? $data['product']->category->$field
                                                : $data['product']->category->category;
                                        ?>

                                        <?php echo e($cat); ?>/<?php
                                            $locale = currentLocale();
                                            $field = 'sub_category_' . $locale;
                                            $subCat = !empty($data['product']->subCategory->$field)
                                                ? $data['product']->subCategory->$field
                                                : $data['product']->subCategory->sub_category;
                                        ?>

                                        <?php echo e($subCat); ?>

                                    </p>
                                    <div class="row col-md-12">
                                        <div class="col-md-6">
                                            <p><span class="fw-bold"><?php echo e(t('app.product.brand')); ?>:
                                                </span>
                                                <?php if($data['product']->brand): ?>
                                                    <?php
                                                        $logoPath = public_path(
                                                            'assets/uploads/products/brands/logo/' .
                                                                $data['product']->brand->logo,
                                                        );
                                                    ?>
                                                    <?php if($data['product']->brand->logo && file_exists($logoPath)): ?>
                                                        <img src="<?php echo e(asset('assets/uploads/products/brands/logo/' . $data['product']->brand->logo)); ?>"
                                                            width="30px">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('system/images/logo_placeholder.jpg')); ?>"
                                                            width="30px">
                                                    <?php endif; ?>
                                                    <?php echo e($data['product']->brand->brand); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </p>
                                            <p><span class="fw-bold"><?php echo e(t('app.product.sku')); ?>:
                                                </span>
                                                <?php echo e($data['product']->sku); ?>

                                            </p>
                                            <p><span class="fw-bold"><?php echo e(t('app.product.price')); ?>:
                                                </span>
                                                <?php if(!is_null($data['product']->price) && $data['product']->price != 0): ?>
                                                    ₦<?php echo e(number_format($data['product']->price, 2)); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                        <div class="col-md-6">
                                            <p> <span class="fw-bold"><?php echo e(t('app.product.availability')); ?>:
                                                </span>
                                                <?php switch($data['product']->is_available):
                                                    case (true): ?>
                                                        <span
                                                            class="badge bg-soft-success text-success"><?php echo e(t('app.status.available')); ?></span>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                        <span
                                                            class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.notAvailable')); ?></span>
                                                <?php endswitch; ?>
                                            </p>
                                            <p><span class="fw-bold"><?php echo e(t('app.published')); ?>:
                                                </span>
                                                <?php switch($data['product']->is_active):
                                                    case (true): ?>
                                                        <span
                                                            class="badge bg-soft-success text-success"><?php echo e(t('app.status.true')); ?></span>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                        <span
                                                            class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.false')); ?></span>
                                                <?php endswitch; ?>
                                            </p>
                                            <p> <span class="fw-bold"><?php echo e(t('app.product.featured')); ?>:
                                                </span>
                                                <?php switch($data['product']->is_featured):
                                                    case (true): ?>
                                                        <span
                                                            class="badge bg-soft-success text-success"><?php echo e(t('app.status.true')); ?></span>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                        <span
                                                            class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.false')); ?></span>
                                                <?php endswitch; ?>
                                            </p>

                                        </div>
                                        <p><span class="fw-bold"><?php echo e(t('app.shortDescription')); ?>: <br>
                                            </span>
                                            <?php
                                                $locale = currentLocale();
                                                $field = 'short_description_' . $locale;
                                                $shortDesc = !empty($data['product']->$field)
                                                    ? $data['product']->$field
                                                    : $data['product']->short_description;
                                            ?>

                                            <?php echo e($shortDesc); ?>

                                        </p>
                                    </div>


                                    <div class="section-divider">
                                        <span><?php echo e(t('app.settings.seo.seo')); ?></span>
                                    </div>
                                    <p><span class="fw-bold"><?php echo e(t('app.settings.seo.metaTitle')); ?>: <br>
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'meta_title_' . $locale;
                                            $metaTitle = !empty($data['product']->$field)
                                                ? $data['product']->$field
                                                : $data['product']->meta_title;
                                        ?>

                                        <?php echo e($metaTitle); ?>

                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.settings.seo.metaKeywords')); ?>: <br>
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'meta_keywords_' . $locale;
                                            $metaKeywords = !empty($data['product']->$field)
                                                ? $data['product']->$field
                                                : $data['product']->meta_keywords;
                                        ?>

                                        <?php echo e($metaKeywords); ?>

                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.settings.seo.metaDescription')); ?>: <br>
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'meta_description_' . $locale;
                                            $metaKeywords = !empty($data['product']->$field)
                                                ? $data['product']->$field
                                                : $data['product']->meta_description;
                                        ?>

                                        <?php echo e($metaKeywords); ?>

                                    </p>
                                    <div class="">
                                        <div class="section-divider">
                                            <span><?php echo e(t('app.product.mediaFiles')); ?></span>
                                        </div>
                                        <section class="manage-media-files">
                                            <?php $__currentLoopData = $data['product']->mediaFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($media->file_type === 'video'): ?>
                                                    <?php $filePath = asset('assets/uploads/products/products/media/videos/' . $media->file_name); ?>
                                                    <div class="manage-media-item"
                                                        onclick="openUpdateMediaModal(<?php echo e($media->id); ?>, 'video', '<?php echo e($filePath); ?>', <?php echo e($media->sort_order); ?>, <?php echo e($media->is_primary ? 1 : 0); ?>)">
                                                        <div class="manage-media-video">
                                                            <div class="play-icon"><i class="feather-play"></i></div>
                                                        </div>
                                                        <div class="manage-media-overlay"><span><i
                                                                    class="feather-edit"></i></span></div>
                                                    </div>
                                                <?php else: ?>
                                                    <?php $filePath = asset('assets/uploads/products/products/media/images/' . $media->file_name); ?>
                                                    <div class="manage-media-item"
                                                        onclick="openUpdateMediaModal(<?php echo e($media->id); ?>, 'image', '<?php echo e($filePath); ?>', <?php echo e($media->sort_order); ?>, <?php echo e($media->is_primary ? 1 : 0); ?>)">
                                                        <img src="<?php echo e($filePath); ?>" class="manage-media-img">
                                                        <div class="manage-media-overlay"><span><i
                                                                    class="feather-edit"></i></span></div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </section>
                                        <?php echo $__env->make('users.admin.products.products.include.updateMediaFileModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <div
                                            class="d-flex justify-content-end align-items-center gap-2 page-header-right-items-wrapper">
                                            <button onclick="addMediaFileFormModal('swal-size-md')" class="btn btn-primary">
                                                <i class="feather-plus me-2"></i>
                                                <span><?php echo e(t('app.product.addMediaFile')); ?></span>
                                            </button>
                                        </div>
                                    </div>



                                    
                                    <div class="section-divider">
                                        <span><?php echo e(t('app.product.variations')); ?></span>
                                    </div>
                                    <section class="product-variation">
                                        <div class="container-fluid">

                                            <?php if($data['product']->variants->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $data['product']->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $locale = currentLocale();
                                                        $field = 'name_' . $locale;
                                                        $variantName = !empty($variant->$field)
                                                            ? $variant->$field
                                                            : $variant->name;
                                                    ?>

                                                    <a href="<?php echo e(route('viewProductVariant', ['slug' => $variant->slug])); ?>"
                                                        class="variant-card-link text-decoration-none text-dark">
                                                        <div class="card variant-card mb-4 border-0 shadow-sm">

                                                            <div class="card-body">
                                                                <div class="row align-items-center">

                                                                    
                                                                    <div class="col-md-4 text-center mb-3 mb-md-0">
                                                                        <img src="<?php echo e(optional($variant->mediaFile)->file_name
                                                                            ? asset('assets/uploads/products/products/media/images/' . $variant->mediaFile->file_name)
                                                                            : asset('system/images/icon_placeholder.png')); ?>"
                                                                            alt="<?php echo e($variantName); ?>"
                                                                            class="img-fluid rounded border variant-image">
                                                                    </div>

                                                                    
                                                                    <div class="col-md-8">

                                                                        <h5 class="fw-bold mb-3">
                                                                            <?php echo e($variantName); ?>

                                                                        </h5>

                                                                        <div class="row">

                                                                            
                                                                            <div class="col-md-6">

                                                                                <p class="mb-2">
                                                                                    <span
                                                                                        class="fw-semibold"><?php echo e(t('app.product.sku')); ?>:</span>
                                                                                    <span
                                                                                        class="text-uppercase"><?php echo e($variant->sku); ?></span>
                                                                                </p>

                                                                                <p class="mb-2">
                                                                                    <span
                                                                                        class="fw-semibold"><?php echo e(t('app.product.price')); ?>:</span>
                                                                                    <?php if(!is_null($variant->price)): ?>
                                                                                        <span class="text-success fw-bold">
                                                                                            ₦<?php echo e(number_format($variant->price, 2)); ?>

                                                                                        </span>
                                                                                    <?php endif; ?>
                                                                                </p>

                                                                                <p class="mb-2">
                                                                                    <span
                                                                                        class="fw-semibold"><?php echo e(t('app.published')); ?>:</span>
                                                                                    <span
                                                                                        class="badge <?php echo e($variant->is_active ? 'bg-success' : 'bg-danger'); ?>">
                                                                                        <?php echo e($variant->is_active ? t('app.status.true') : t('app.status.false')); ?>

                                                                                    </span>
                                                                                </p>

                                                                                <p class="mb-0">
                                                                                    <span
                                                                                        class="fw-semibold"><?php echo e(t('app.product.availability')); ?>:</span>
                                                                                    <span
                                                                                        class="badge <?php echo e($variant->is_available ? 'bg-success' : 'bg-danger'); ?>">
                                                                                        <?php echo e($variant->is_available ? t('app.status.available') : t('app.status.notAvailable')); ?>

                                                                                    </span>
                                                                                </p>

                                                                            </div>

                                                                            
                                                                            <div class="col-md-6">

                                                                                
                                                                                <p class="mb-3">
                                                                                    <span
                                                                                        class="fw-semibold"><?php echo e(t('app.product.colour')); ?>:</span>

                                                                                    <?php if($variant->colour): ?>
                                                                                        <?php
                                                                                            $hex = preg_match(
                                                                                                '/^#[0-9A-Fa-f]{6}$/',
                                                                                                $variant->colour
                                                                                                    ->hex_code,
                                                                                            )
                                                                                                ? $variant->colour
                                                                                                    ->hex_code
                                                                                                : '#000000';

                                                                                            $colourField =
                                                                                                'name_' . $locale;
                                                                                            $colourName = !empty(
                                                                                                $variant->colour
                                                                                                    ->$colourField
                                                                                            )
                                                                                                ? $variant->colour
                                                                                                    ->$colourField
                                                                                                : $variant->colour
                                                                                                    ->name;
                                                                                        ?>

                                                                                        <span
                                                                                            style="width:60px; height:25px; background-color: <?php echo e($hex); ?>; border:1px solid #ccc; display:inline-block;">
                                                                                        </span>
                                                                                        


                                                                                    <?php else: ?>
                                                                                        -
                                                                                    <?php endif; ?>
                                                                                </p>

                                                                                
                                                                                <div>
                                                                                    <span class="fw-semibold d-block mb-2">
                                                                                        <?php echo e(t('app.product.otherAttributes')); ?>:
                                                                                    </span>

                                                                                    <?php if($variant->attributes->isNotEmpty()): ?>
                                                                                        <div
                                                                                            class="d-flex flex-wrap gap-2">
                                                                                            <?php $__currentLoopData = $variant->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                <?php
                                                                                                    $nameField =
                                                                                                        'name_' .
                                                                                                        $locale;
                                                                                                    $valueField =
                                                                                                        'value_' .
                                                                                                        $locale;

                                                                                                    $attName = !empty(
                                                                                                        $attribute
                                                                                                            ->attribute
                                                                                                            ->$nameField
                                                                                                    )
                                                                                                        ? $attribute
                                                                                                            ->attribute
                                                                                                            ->$nameField
                                                                                                        : $attribute
                                                                                                            ->attribute
                                                                                                            ->name;

                                                                                                    $attValue = !empty(
                                                                                                        $attribute
                                                                                                            ->value
                                                                                                            ->$valueField
                                                                                                    )
                                                                                                        ? $attribute
                                                                                                            ->value
                                                                                                            ->$valueField
                                                                                                        : $attribute
                                                                                                            ->value
                                                                                                            ->value;
                                                                                                ?>

                                                                                                <span
                                                                                                    class="attribute-badge">
                                                                                                    <?php echo e($attName); ?>:
                                                                                                    <?php echo e($attValue); ?>

                                                                                                </span>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </div>
                                                                                    <?php else: ?>
                                                                                        <span>-</span>
                                                                                    <?php endif; ?>
                                                                                </div>

                                                                            </div>

                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                        </div>
                                    </section>



                                    
                                    <div class="flex-accordion">

                                        <!-- Headers -->
                                        <div class="flex-accordion-headers d-flex flex-wrap justify-content-center">
                                            <div class="flex-accordion-header active" data-target="content1">
                                                <?php echo e(t('app.fullDescription')); ?></div>
                                            <div class="flex-accordion-header" data-target="content2">
                                                <?php echo e(t('app.product.reviews')); ?></div>
                                        </div>

                                        <!-- Contents -->
                                        <div class="flex-accordion-contents">
                                            <div id="content1" class="flex-accordion-content show">
                                                <div class="my-1" style="display:flex; align-items:center; gap:8px;">

                                                    <span class="fw-bold"><?php echo e(t('app.product.colour')); ?>:</span>
                                                    <?php if($data['product']->colour): ?>
                                                        <?php
                                                            $hex = preg_match(
                                                                '/^#[0-9A-Fa-f]{6}$/',
                                                                $data['product']->colour->hex_code,
                                                            )
                                                                ? $data['product']->colour->hex_code
                                                                : '#000000';
                                                        ?>


                                                        <span
                                                            style="width:60px; height:25px; background-color: <?php echo e($hex); ?>; border:1px solid #ccc; display:inline-block;">
                                                        </span>
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $value = !empty($data['product']->colour->$field)
                                                                ? $data['product']->colour->$field
                                                                : $data['product']->colour->name;
                                                        ?>
                                                        <?php echo e($value); ?>

                                                        <span
                                                            class="badge bg-soft-primary text-primary cursor-pointer me-2"
                                                            onclick="addProductColourFormModal('swal-size-md')">
                                                            <i class="feather-edit"></i>
                                                        </span>
                                                        <span class="badge bg-soft-danger text-danger cursor-pointer"
                                                            onclick="removeProductColourFormModal('swal-size-md')">
                                                            <i class="feather-trash"></i>
                                                        </span>
                                                    <?php else: ?>
                                                        <span
                                                            class="badge bg-soft-primary text-primary cursor-pointer me-2"
                                                            onclick="addProductColourFormModal('swal-size-md')">
                                                            <i class="feather-plus"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <br>
                                                
                                                <div class="my-1 d-flex align-items-center flex-wrap" style="gap:8px;">
                                                    <span class="fw-bold"><?php echo e(t('app.product.otherAttributes')); ?>:</span>

                                                    <?php if($data['product']->attributes->isNotEmpty()): ?>
                                                        <div style="display: flex; gap: 4px; flex-wrap: wrap;">
                                                            <?php $__currentLoopData = $data['product']->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $locale = currentLocale();
                                                                    $nameField = 'name_' . $locale;
                                                                    $valueField = 'value_' . $locale;

                                                                    $attName = !empty($attribute->attribute->$nameField)
                                                                        ? $attribute->attribute->$nameField
                                                                        : $attribute->attribute->name;

                                                                    $attValue = !empty($attribute->value->$valueField)
                                                                        ? $attribute->value->$valueField
                                                                        : $attribute->value->value;

                                                                    // Add comma unless it's the last item
                                                    $separator =
                                                        $index ==
                                                        $data['product']->attributes->count() - 1
                                                            ? '.'
                                                            : ',';
                                                                ?>

                                                                <span class="attribute-badge">
                                                                    <strong><?php echo e($attName); ?></strong>:
                                                                    <?php echo e($attValue); ?><?php echo e($separator); ?>

                                                                </span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>

                                                        
                                                        <span class="badge bg-soft-danger text-danger cursor-pointer"
                                                            onclick="removeProductAttributeFormModal('swal-size-md')">
                                                            <i class="feather-trash"></i>
                                                        </span>
                                                    <?php else: ?>
                                                        <span>-</span>
                                                    <?php endif; ?>

                                                    <span class="badge bg-soft-primary text-primary cursor-pointer"
                                                        onclick="addProductAttributeFormModal('swal-size-md')">
                                                        <i class="feather-plus"></i>
                                                    </span>
                                                </div>

                                                <br>

                                                <br>

                                                <span class="fw-bold"><?php echo e(t('app.fullDescription')); ?>:</span> <br>
                                                <?php
                                                    $locale = currentLocale();
                                                    $field = 'description_' . $locale;
                                                    $fullDesc = !empty($data['product']->$field)
                                                        ? $data['product']->$field
                                                        : $data['product']->description;
                                                ?>

                                                <?php echo $fullDesc; ?>

                                            </div>
                                            <div id="content2" class="flex-accordion-content">
                                                <p>This is content for Header 2. Hidden initially.</p>
                                            </div>
                                        </div>

                                    </div>
                                    <script>
                                        document.addEventListener("DOMContentLoaded", function() {

                                            const headers = document.querySelectorAll(".flex-accordion-header");
                                            const contents = document.querySelectorAll(".flex-accordion-content");

                                            headers.forEach(header => {
                                                header.addEventListener("click", function() {

                                                    // Remove active class from all headers
                                                    headers.forEach(h => h.classList.remove("active"));
                                                    // Hide all contents
                                                    contents.forEach(c => c.classList.remove("show"));

                                                    // Activate clicked header
                                                    this.classList.add("active");
                                                    // Show its content
                                                    const targetId = this.getAttribute("data-target");
                                                    document.getElementById(targetId).classList.add("show");

                                                });
                                            });

                                        });
                                    </script>
                                    
                                </div>
                                <div class="d-flex justify-content-end mt-3">
                                    <a href="<?php echo e(route('editProduct', ['slug' => $data['product']->slug])); ?>?language=en"
                                        class="btn btn-primary">
                                        <i class="feather-edit me-2"></i> <?php echo e(t('app.buttons.edit')); ?>

                                    </a>
                                </div>


                            </div>

                        </div>
                        
                        <div class="row mb-4 justify-content-center">
                            <div class="col-auto">
                                <a class="btn btn-primary" href="<?php echo e(route('products')); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>


    
    <?php echo $__env->make('users.admin.products.products.include.addProductColourModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('users.admin.products.products.include.removeProductColourModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('users.admin.products.products.include.addProductAttributeModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('users.admin.products.products.include.removeProductAttributeModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('users.admin.products.products.include.addMediaFileModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/viewProduct.blade.php ENDPATH**/ ?>