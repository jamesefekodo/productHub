<?php $__env->startSection('title', t('auth.resetPassword')); ?>
<?php $__env->startSection('content'); ?>
    <div class="outer-container">
        <?php echo $__env->make('utilities.pages.auth.include.slider', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="login-form">
            <div class="form-container">
                <?php echo $__env->make('utilities.pages.auth.include.headerLogo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                <h2 class="m-2 text-center auth_header"><?php echo e(t('auth.resetPassword')); ?></h2>
                <p class="m-2 text-center"><?php echo e(t('auth.enterNewPassword')); ?></p>
                <form class="" action="<?php echo e(route('submitPasswordResetRequest', ['token' => $user->remember_token])); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="password-container">
                        <input type="password" id="password" placeholder="Password" name="password" autocomplete="off"
                            value="<?php echo e(old('password')); ?>" required />
                        <i class="fa fa-eye" id="togglePassword" style="cursor: pointer;"></i>
                    </div>
                    <p style="color: red"><?php echo e($errors->first('password')); ?></p>

                    <div class="password-container">
                        <input type="password" id="password2" placeholder="Confirm Password" name="confirm_password"
                            autocomplete="off" value="<?php echo e(old('confirm_password')); ?>" required />
                        <i class="fa fa-eye" id="togglePassword2" style="cursor: pointer;"></i>
                    </div>
                    
                    <div id="password-rules" class="mt-3">
                        <ul>
                            <div class="col-md-12">
                                <span
                                    class="text-bold text-danger text-sm"><?php echo e(t('auth.passwordRules.passwordRules')); ?>:</span>
                                <div class="row m-2">
                                    <div class="col-md-12">
                                        <li id="length-rule" class="rule"><?php echo e(t('auth.passwordRules.minChar')); ?></li>
                                        <li id="lowercase-rule" class="rule"><?php echo e(t('auth.passwordRules.lowerCase')); ?></li>
                                        <li id="uppercase-rule" class="rule"><?php echo e(t('auth.passwordRules.upperCase')); ?></li>
                                        <li id="special-char-rule" class="rule"><?php echo e(t('auth.passwordRules.symbolRule')); ?>

                                        </li>
                                        <li id="number-rule" class="rule"><?php echo e(t('auth.passwordRules.numberRule')); ?></li>
                                        <li id="match-rule" class="rule">
                                            <?php echo e(t('auth.passwordRules.samePass')); ?></li>
                                    </div>
                                </div>
                            </div>
                        </ul>
                    </div>

                    <button type="submit"><?php echo e(t('auth.resetPassword')); ?></button>
                </form>
                <div class="form-options my-4">
                    <p class=""><?php echo e(t('auth.haveAnAccount')); ?> <a
                            href="<?php echo e(route('loginPage')); ?>"><?php echo e(t('auth.login')); ?></a></p>
                    <p class=""><a
                            href="
                        <?php echo e(route('homepage')); ?>

                         "><?php echo e(t('app.homePage')); ?></a>
                    </p>

                    <div class="d-flex justify-content-end">
                        <div class="text-center">
                            <?php echo $__env->make('utilities.pages.others.changeLanguage', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const togglePassword = document.getElementById('togglePassword');
            const passwordField = document.getElementById('password');
            const togglePassword2 = document.getElementById('togglePassword2');
            const passwordField2 = document.getElementById('password2');

            togglePassword.addEventListener('click', function() {
                const type = passwordField.type === 'password' ? 'text' : 'password';
                passwordField.type = type;
                this.classList.toggle('fa-eye-slash');
                this.classList.toggle('fa-eye');
            });

            togglePassword2.addEventListener('click', function() {
                const type = passwordField2.type === 'password' ? 'text' : 'password';
                passwordField2.type = type;
                this.classList.toggle('fa-eye-slash');
                this.classList.toggle('fa-eye');
            });

            passwordField.addEventListener('input', function() {
                validatePassword();
                matchPasswords();
            });

            passwordField2.addEventListener('input', function() {
                matchPasswords();
            });

            function validatePassword() {
                const passwordValue = passwordField.value;

                const lengthRule = document.getElementById('length-rule');
                lengthRule.style.color = passwordValue.length >= 8 ? '#00BD73' : '#E02626';

                const lowercaseRule = document.getElementById('lowercase-rule');
                lowercaseRule.style.color = /[a-z]/.test(passwordValue) ? '#00BD73' : '#E02626';

                const uppercaseRule = document.getElementById('uppercase-rule');
                uppercaseRule.style.color = /[A-Z]/.test(passwordValue) ? '#00BD73' : '#E02626';

                const specialCharRule = document.getElementById('special-char-rule');
                specialCharRule.style.color = /[^A-Za-z0-9]/.test(passwordValue) ? '#00BD73' : '#E02626';

                const numberRule = document.getElementById('number-rule');
                numberRule.style.color = /\d/.test(passwordValue) ? '#00BD73' : '#E02626';
            }

            function matchPasswords() {
                const passwordValue = passwordField.value;
                const confirmPasswordValue = passwordField2.value;
                const matchRule = document.getElementById('match-rule');

                matchRule.style.color = passwordValue === confirmPasswordValue ? '#00BD73' : '#E02626';
            }
        });
    </script>



    <style>
        #password-rules {
            padding: 0;
            margin: 0;
            list-style-type: none;
        }

        #password-rules ul {
            padding: 0;
            margin: 0;
        }

        #password-rules li {
            font-size: 12px;
            margin-bottom: 2px;
        }

        .rule {
            font-size: 14px;
            color: #E02626;
        }

        .password-container {
            margin-bottom: 15px;
        }

        #password-error,
        #confirm-password-error {
            font-size: 12px;
            color: #E02626;
            margin-top: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/utilities/pages/auth/resetPassword.blade.php ENDPATH**/ ?>