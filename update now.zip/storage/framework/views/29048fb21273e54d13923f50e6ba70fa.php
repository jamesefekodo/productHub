<!-- Mobile toggle button -->
<button class="btn btn-outline-primary d-md-none w-100 mb-2" data-bs-toggle="collapse" data-bs-target="#innerNavMenu"
    aria-expanded="false" aria-controls="innerNavMenu">
    <i class="feather-menu me-1"></i> <?php echo e(t('app.menu')); ?>

</button>

<!-- Collapsible inner nav -->
<div id="innerNavMenu" class="collapse d-md-block">
    <div class="inner-nav">
        <h6 class="inner-nav-title text-center"><?php echo e(t('app.settings.address.address')); ?></h6>

        <div class="inner-nav-list">
            <a href="<?php echo e(route('countries')); ?>" class="inner-nav-item <?php echo e(Str::startsWith(request()->path(), 'admin/settings/address/countries') ? 'active' : ''); ?>">
                <i data-feather="globe"></i>
                <?php echo e(t('app.settings.address.countries')); ?>

            </a>

            <a href="<?php echo e(route('states')); ?>" class="inner-nav-item <?php echo e(Str::startsWith(request()->path(), 'admin/settings/address/states') ? 'active' : ''); ?>">
                <i data-feather="map"></i>
                <?php echo e(t('app.settings.address.states')); ?>

            </a>

            <a href="<?php echo e(route('lgas')); ?>" class="inner-nav-item <?php echo e(Str::startsWith(request()->path(), 'admin/settings/address/lga') ? 'active' : ''); ?>">
                <i data-feather="map-pin"></i>
                <?php echo e(t('app.settings.address.lga')); ?>

            </a>
        </div>
    </div>
</div>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/settings/address/country/include/inner_nav.blade.php ENDPATH**/ ?>