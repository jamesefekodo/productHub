<?php $__env->startSection('title', t('app.buttons.edit') . ' :: ' . t('app.user.myProfile')); ?>
<?php $__env->startSection('content'); ?>

    <div class="desktop-nav-bg"></div>
    <div class="main-content-wrapper">

        <section class="section row col-md-12">
            
            <div class="col-md-2 mt-md-2">
                <?php echo $__env->make('users.customer.profile.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            
            <div class="col-md-10">

                <div class="my-page-header"><?php echo e(t('app.buttons.edit')); ?> :: <?php echo e(t('app.user.myProfile')); ?></div>

                <div class="my-4">
                    <div class="card shadow-sm border-0">
                        <form method="POST" action="<?php echo e(route('userUpdateProfileSubmit')); ?>"
                            enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body p-0 row col-md-12">
                                <div class="col-md-4">
                                    <div class="col-md-12 justify-content-center text-center p-2" style="overflow: hidden;">
                                        <img id="passport-preview"
                                            src="<?php echo e($data['user'] && $data['user']->photo ? asset('assets/uploads/users/photos/' . $data['user']->photo) : asset('system/images/default_profile_pic.jpg')); ?>"
                                            alt="<?php echo e($data['user'] ? $data['user']->username : 'Default Picture'); ?>"
                                            style="max-width: 100%; height: auto; object-fit: contain;">
                                    </div>

                                    <div class="col-md-12">
                                        <input type="file" id="passport-upload" accept=".jpg, .jpeg, .png, .webp"
                                            name="image" onchange="previewUserPhotos(this)">
                                        <p class="text-red"><?php echo e($errors->first('image')); ?></p>
                                    </div>
                                </div>

                                <div class="col-md-8 align-content-start">
                                    <div class="row col-md-12">
                                        <div class="mb-3 col-md-4">
                                            <label class="form-label"><?php echo e(t('app.user.firstName')); ?>

                                                <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="first_name"
                                                value="<?php echo e($data['user']->first_name); ?>" required>
                                            <p class="text-red"><?php echo e($errors->first('first_name')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-4">
                                            <label class="form-label"><?php echo e(t('app.user.middleName')); ?>

                                                <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="middle_name"
                                                value="<?php echo e($data['user']->middle_name); ?>" required>
                                            <p class="text-red"><?php echo e($errors->first('middle_name')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-4">
                                            <label class="form-label"><?php echo e(t('app.user.lastName')); ?>

                                                <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="last_name"
                                                value="<?php echo e($data['user']->last_name); ?>" required>
                                            <p class="text-red"><?php echo e($errors->first('last_name')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label"><?php echo e(t('auth.email')); ?> 1
                                                <span class="text-danger">*</span></label>
                                            <input type="email" class="form-control" name="email1"
                                                value="<?php echo e($data['user']->email1); ?>" required>
                                            <p class="text-red"><?php echo e($errors->first('email1')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label"><?php echo e(t('auth.email')); ?> 2</label>
                                            <input type="email" class="form-control" name="email2"
                                                value="<?php echo e($data['user']->email2); ?>">
                                            <p class="text-red"><?php echo e($errors->first('email2')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label"><?php echo e(t('auth.phone')); ?> 1
                                                <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="phone1"
                                                value="<?php echo e($data['user']->phone1); ?>" required>
                                            <p class="text-red"><?php echo e($errors->first('phone1')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label"><?php echo e(t('auth.phone')); ?> 2</label>
                                            <input type="text" class="form-control" name="phone2"
                                                value="<?php echo e($data['user']->phone2); ?>">
                                            <p class="text-red"><?php echo e($errors->first('phone2')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label"><?php echo e(t('app.user.gender') ?? 'Gender'); ?></label>

                                            <select name="gender" class="form-select text-center">
                                                <option value="" disabled
                                                    <?php echo e(empty($data['user']->gender) ? 'selected' : ''); ?>>
                                                    - <?php echo e(t('app.select') ?? 'Select'); ?> -
                                                </option>

                                                <option value="male"
                                                    <?php echo e(isset($data['user']->gender) && strtolower($data['user']->gender) === 'male' ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.user.male') ?? 'Male'); ?>

                                                </option>

                                                <option value="female"
                                                    <?php echo e(isset($data['user']->gender) && strtolower($data['user']->gender) === 'female' ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.user.female') ?? 'Female'); ?>

                                                </option>
                                            </select>
                                            <p class="text-red"><?php echo e($errors->first('gender')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label"><?php echo e(t('app.user.dateOfBirth')); ?></label>
                                            <input type="date" class="form-control" name="date_of_birth"
                                                value="<?php echo e($data['user']->date_of_birth); ?>">
                                            <p class="text-red"><?php echo e($errors->first('date_of_birth')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-5">
                                            <label class="form-label"><?php echo e(t('app.user.nationality')); ?></label>
                                            <input type="text" class="form-control" name="nationality"
                                                value="<?php echo e($data['user']->nationality); ?>">
                                            <p class="text-red"><?php echo e($errors->first('nationality')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-5">
                                            <label class="form-label"><?php echo e(t('app.language.language')); ?></label>

                                            <select name="preferred_language" class="form-select text-center">
                                                <option value="" disabled
                                                    <?php echo e(empty($data['user']->preferred_language) ? 'selected' : ''); ?>>
                                                    - <?php echo e(t('app.select') ?? 'Select'); ?> -
                                                </option>

                                                <?php $__currentLoopData = activeLanguages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($language->language_code); ?>"
                                                        <?php echo e((string) old('preferred_language', $data['user']->preferred_language ?? '') === (string) $language->language_code ? 'selected' : ''); ?>>
                                                        <?php echo e($language->language); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <p class="text-red"><?php echo e($errors->first('preferred_language')); ?></p>
                                        </div>
                                        <div class="mb-3 col-md-2">
                                            <label class="form-label"><?php echo e(t('app.user.requireMfa')); ?></label>

                                            <select name="require_login_mfa" class="form-select text-center">
                                                <option value="" disabled
                                                    <?php echo e(is_null($data['user']->require_login_mfa) ? 'selected' : ''); ?>>
                                                    - <?php echo e(t('app.select') ?? 'Select'); ?> -
                                                </option>

                                                <option value="1"
                                                    <?php echo e($data['user']->require_login_mfa == 1 ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.status.active')); ?>

                                                </option>

                                                <option value="0"
                                                    <?php echo e($data['user']->require_login_mfa == 0 ? 'selected' : ''); ?>>
                                                    <?php echo e(t('app.status.inactive')); ?>

                                                </option>

                                            </select>
                                            <p class="text-red"><?php echo e($errors->first('require_login_mfa')); ?></p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="text-center p-3">
                                <button type="submit" class="btn btn-primary px-4 w-100">
                                    <?php echo e(t('app.buttons.update')); ?>

                                </button>
                            </div>
                        </form>



                    </div>
                </div>

            </div>
    </div>

    </section>
    </div>

    
    <script>
        function previewUserPhotos(input) {
            const preview = document.getElementById('passport-preview');

            if (input.files && input.files[0]) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    preview.src = e.target.result; // update image preview
                }

                reader.readAsDataURL(input.files[0]);
            } else {
                // fallback to default if input cleared
                preview.src = "<?php echo e(asset('system/images/default_profile_pic.jpg')); ?>";
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/customer/profile/editProfile.blade.php ENDPATH**/ ?>