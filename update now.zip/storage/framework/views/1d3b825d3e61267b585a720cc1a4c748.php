<?php $__env->startSection('title', t('app.product.draftedQuotes')); ?>
<?php $__env->startSection('content'); ?>

    <div class="desktop-nav-bg"></div>
    <div class="main-content-wrapper">

        <section class="section">
            


            <div class="my-page-header"><?php echo e(t('app.product.draftedQuotes')); ?></div>

            <div class="my-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-0">

                        <div class="table-responsive">
                            <table class="table table-hover table-striped align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col" class="text-muted small">#</th>
                                        <th scope="row"><?php echo e(t('app.thumbnail')); ?></th>
                                        <th scope="row"><?php echo e(t('app.product.product')); ?></th>
                                        <th scope="row"><?php echo e(t('app.product.sku')); ?></th>
                                        <th scope="row"><?php echo e(t('app.product.quantity')); ?></th>
                                        <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($data['draftedRequest']->items->isNotEmpty()): ?>
                                        <?php $__currentLoopData = $data['draftedRequest']->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                <?php if($item->variant): ?>
                                                    <td>
                                                        <img src="<?php echo e(optional($item->variant->mediaFile)->file_name
                                                            ? asset('assets/uploads/products/products/media/images/' . $item->variant->mediaFile->file_name)
                                                            : asset('system/images/icon_placeholder.png')); ?>"
                                                            alt="<?php echo e($item->variant->name); ?>" width="90">
                                                    </td>
                                                    <td>
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $variantName = !empty($item->variant->$field)
                                                                ? $item->variant->$field
                                                                : $item->variant->name;
                                                        ?>
                                                        <?php echo e($variantName); ?>

                                                        <a href="<?php echo e(route(routePrefix() . 'ViewProduct', ['slug' => $item->variant->product->slug])); ?>"
                                                            target="_blank" class="badge bg-primary text-white">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <?php echo e($item->variant->sku); ?>

                                                    </td>
                                                <?php else: ?>
                                                    <td>
                                                        <?php
                                                            $thumbnailImage = asset(
                                                                'system/images/icon_placeholder.png',
                                                            );

                                                            if (!$item->product->mediaFiles->isEmpty()) {
                                                                $primaryImage = $item->product->mediaFiles
                                                                    ->where('is_primary', true)
                                                                    ->first();

                                                                if ($primaryImage) {
                                                                    $thumbnailImage = asset(
                                                                        'assets/uploads/products/products/media/images/' .
                                                                            $primaryImage->file_name,
                                                                    );
                                                                }
                                                            }
                                                        ?>

                                                        <img src="<?php echo e($thumbnailImage); ?>" alt="<?php echo e($item->product->name); ?>"
                                                            width="90px">
                                                    </td>
                                                    <td>
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $productName = !empty($item->product->$field)
                                                                ? $item->product->$field
                                                                : $item->product->name;
                                                        ?>

                                                        <?php echo e($productName); ?>

                                                        <a href="<?php echo e(route(routePrefix() . 'ViewProduct', ['slug' => $item->product->slug])); ?>"
                                                            target="_blank" class="badge bg-primary text-white"> <i
                                                                class="fas fa-eye"></i>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <?php echo e($item->product->sku); ?>

                                                    </td>
                                                <?php endif; ?>
                                                <td><?php echo e($item->quantity); ?></td>
                                                <td class="text-primary">
                                                    <a href="javascript:void(0)"
                                                        class="badge bg-primary text-white m-1 p-2 edit-item"
                                                        data-id="<?php echo e($item->id); ?>"
                                                        data-quantity="<?php echo e($item->quantity); ?>">
                                                        <i class="fas fa-edit me-1"></i>
                                                        <?php echo e(t('app.buttons.update')); ?>

                                                    </a>

                                                    <a href="javascript:void(0)"
                                                        class="badge bg-danger text-white m-1 p-2 delete-item"
                                                        data-id="<?php echo e($item->id); ?>">
                                                        <i class="fas fa-times me-1"></i>
                                                        <?php echo e(t('app.buttons.remove')); ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6">
                                                <h3 class="text-danger text-center opacity-50">
                                                    <?php echo e(t('app.product.emptyQuoteList')); ?>!
                                                </h3>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            
                            <?php if($data['draftedRequest']->items->isNotEmpty()): ?>
                                <?php $__currentLoopData = $data['draftedRequest']->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <script>
                                        document.addEventListener('click', function(e) {

                                            // EDIT
                                            if (e.target.closest('.edit-item')) {
                                                let button = e.target.closest('.edit-item');
                                                let id = button.dataset.id;
                                                let quantity = button.dataset.quantity;

                                                Swal.fire({
                                                    title: '<?php echo e(t('app.product.updateQuantity')); ?>',
                                                    html: `
                <input type="number" id="swal_quantity"
                       class="swal2-input"
                       value="${quantity}"
                       min="1"
                       required>
            `,
                                                    showCancelButton: true,
                                                    confirmButtonText: 'Update',
                                                    preConfirm: () => {
                                                        return document.getElementById('swal_quantity').value;
                                                    }
                                                }).then((result) => {
                                                    if (result.isConfirmed) {

                                                        let form = document.createElement('form');
                                                        form.method = 'POST';
                                                        form.action = "<?php echo e(route(routePrefix() . 'UpdateQuoteItem')); ?>";

                                                        form.innerHTML = `
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="PUT">
                    <input type="hidden" name="item_id" value="${id}">
                    <input type="hidden" name="quantity" value="${result.value}">
                `;

                                                        document.body.appendChild(form);
                                                        form.submit();
                                                    }
                                                });
                                            }

                                            // DELETE
                                            if (e.target.closest('.delete-item')) {
                                                let button = e.target.closest('.delete-item');
                                                let id = button.dataset.id;

                                                Swal.fire({
                                                    title: "<?php echo e(t('app.confirm')); ?>",
                                                    text: "<?php echo e(t('app.deleteConfirmText')); ?>",
                                                    icon: 'warning',
                                                    showCancelButton: true,
                                                    confirmButtonText: "<?php echo e(t('app.buttons.delete')); ?>",
                                                    confirmButtonColor: '#dc3545'
                                                }).then((result) => {
                                                    if (result.isConfirmed) {

                                                        let form = document.createElement('form');
                                                        form.method = 'POST';
                                                        form.action = "<?php echo e(route(routePrefix() . 'DeleteQuoteItem')); ?>";

                                                        form.innerHTML = `
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="_method" value="DELETE">
                                                                <input type="hidden" name="item_id" value="${id}">
                                                            `;

                                                        document.body.appendChild(form);
                                                        form.submit();
                                                    }
                                                });
                                            }

                                        });
                                    </script>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            

                        </div>

                    </div>
                </div>
                
                <div class="m-3 mt-5">
                    <form action="<?php echo e(route(routePrefix() . 'SubmitQuoteDetails')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <h4 class="text-center fw-bold mb-4 ms-2">
                            <?php echo e(t('app.product.quoteRequesterDetailsDescription')); ?>

                        </h4>

                        <?php
                            $user = Auth::user();
                        ?>

                        <?php switch(getUserType()):
                            case ('customer'): ?>
                                <?php echo e($user->first_name); ?>

                                <!-- Pre-fill from user record -->
                                <div class="mb-3 text-center">
                                    <label for="name" class="form-label"><?php echo e(t('app.name')); ?> <span
                                            class="text-danger">*</span>:</label>
                                    <input type="text" class="form-control text-center" id="name" name="name"
                                        value="<?php echo e(trim(($user->first_name ?? '') . ' ' . ($user->middle_name ?? '') . ' ' . ($user->last_name ?? ''))); ?>"
                                        readonly>
                                </div>
                                <div class="row col-md-12">
                                    <div class="mb-3 col-md-6 text-center">
                                        <label for="email" class="form-label"><?php echo e(t('auth.email')); ?> <span
                                                class="text-danger">*</span>:</label>
                                        <input type="email" class="form-control text-center" id="email" name="email"
                                            value="<?php echo e($user->email1 ?? ''); ?>" readonly>
                                    </div>

                                    <div class="mb-3 col-md-6 text-center">
                                        <label for="phone" class="form-label"><?php echo e(t('auth.phone')); ?> <span
                                                class="text-danger">*</span>:</label>
                                        <input type="text" class="form-control text-center" id="phone" name="phone"
                                            value="<?php echo e($user->phone1 ?? ''); ?>" required>
                                    </div>
                                </div>
                            <?php break; ?>

                            <?php case ('guest'): ?>
                                <!-- Empty form for guest -->
                                <div class="mb-3 text-center">
                                    <label for="name" class="form-label"><?php echo e(t('app.name')); ?> <span
                                            class="text-danger">*</span>:</label>
                                    <input type="text" class="form-control text-center" id="name" name="name"
                                        placeholder="John Doe" required>
                                </div>
                                <div class="row col-md-12">
                                    <div class="mb-3 col-md-6 text-center">
                                        <label for="email" class="form-label"><?php echo e(t('auth.email')); ?> <span
                                                class="text-danger">*</span>:</label>
                                        <input type="email" class="form-control text-center" id="email" name="email"
                                            placeholder="you@mail.com" required>
                                    </div>

                                    <div class="mb-3 col-md-6 text-center">
                                        <label for="phone" class="form-label"><?php echo e(t('auth.phone')); ?> <span
                                                class="text-danger">*</span>:</label>
                                        <input type="text" class="form-control text-center" id="phone" name="phone"
                                            placeholder="+2349012345678" required>
                                    </div>

                                    <div class="mb-3 col-md-12 text-center">
                                        <label for="address" class="form-label"><?php echo e(t('app.address.address')); ?> <span
                                                class="text-danger">*</span>:</label>
                                        <textarea class="form-control text-center" id="address" name="address" required><?php echo e(old('address')); ?></textarea>

                                    </div>
                                </div>
                            <?php break; ?>

                            <?php default: ?>
                                <h3 class="text-danger text-center">
                                    <?php echo e(t('app.product.userCannotSubmitQuote')); ?>

                                </h3>
                        <?php endswitch; ?>

                        <?php if(in_array(getUserType(), ['customer', 'guest'])): ?>
                            <hr>
                            <button type="submit" class="btn btn-success w-100 mt-3">
                                <?php echo e(t('app.product.submitQuote')); ?>

                            </button>
                        <?php endif; ?>
                    </form>
                </div>



            </div>
        </section>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/customer/products/newQuoteRequest.blade.php ENDPATH**/ ?>