<script>
    function addMediaFileFormModal(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.buttons.update')); ?> :: <?php echo e(t('app.product.mediaFile')); ?>",
            showCloseButton: true,
            showConfirmButton: false,
            customClass: {
                popup: sizeClass
            },
            html: `
        <form id="swalForm"
              method="POST"
              enctype="multipart/form-data"
              action="<?php echo e(route('addProductMediaSubmit')); ?>">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="product"
                   value="<?php echo e($data['product']->slug); ?>">

            <div class="row col-md-12">
                <div class="mb-3 col-md-8">
                    <label class="form-label">
                        <?php echo e(t('app.product.fileType')); ?><span class="text-danger">*</span>

                    </label>

                    <select class="form-select text-center" name="file_type" required>

                        <option value="" disabled <?php echo e(old('file_type') ? '' : 'selected'); ?>>
                            - <?php echo e(t('app.select')); ?> -
                        </option>

                        <option value="image" <?php echo e(old('file_type') == 'image' ? 'selected' : ''); ?>>
                            <?php echo e(t('app.image')); ?>

                        </option>

                        <option value="video" <?php echo e(old('file_type') == 'video' ? 'selected' : ''); ?>>
                            <?php echo e(t('app.video')); ?>

                        </option>
                    </select>

                    <?php if($errors->has('file_type')): ?>
                        <small class="text-danger">
                            <?php echo e($errors->first('file_type')); ?>

                        </small>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-4">
                    <label class="form-label">
                        <?php echo e(t('app.product.sortOrder')); ?><span class="text-danger">*</span>

                    </label>
                    <input type="integer" name="sort_order" class="form-control" required>

                    <?php if($errors->has('sort_order')): ?>
                        <small class="text-danger">
                            <?php echo e($errors->first('sort_order')); ?>

                        </small>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-12">
                    <label class="form-label">
                        <?php echo e(t('app.product.mediaFile')); ?><span class="text-danger">*</span>

                    </label>

                    <input type="file" name="media_file" class="form-control" required>

                    <?php if($errors->has('media_file')): ?>
                        <small class="text-danger">
                            <?php echo e($errors->first('media_file')); ?>

                        </small>
                    <?php endif; ?>
                </div>
            </div>


            <button type="submit"
                    class="btn btn-primary w-100 mt-2">
                <?php echo e(t('app.buttons.submit')); ?>

            </button>
        </form>
        `
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        <?php if($errors->any()): ?>
            addMediaFileFormModal();
        <?php endif; ?>
    });
</script>


<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/include/addMediaFileModal.blade.php ENDPATH**/ ?>