<?php $__env->startSection('title', t('app.buttons.view') . '::' . $data['subCategory']->sub_category); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><a href="#"><?php echo e(t('app.product.subCategories')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.product.categories')); ?></a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e(t('app.buttons.view')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="<?php echo e(route('subCategories', ['slug' => $data['category']->slug])); ?>"
                            class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <button onclick="addSubCategoryFormModal('swal-size-md')" class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span><?php echo e(t('app.product.addSubCategory')); ?></span>
                        </button>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <div class="bg-white py-3 border-bottom rounded-0 p-md-0 mb-0">
            <div class="d-md-none d-flex">
                <a href="javascript:void(0)" class="page-content-left-open-toggle">
                    <i class="feather-align-left fs-20"></i>
                </a>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="tab-content">
                <div class="row col-md-12">
                    
                    <div class="col-md-2">
                        <?php echo $__env->make('users.admin.products.categories.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    
                    <div class="tab-pane fade show active col-md-10" id="profileTab" role="tabpanel">
                        <div class="card card-body lead-info">
                            <div class="mb-4 d-flex align-items-center justify-content-between ps-5">
                                <h5 class="fw-bold mb-0">
                                    <span class="d-block mb-2"><?php echo e(t('app.product.subCategory')); ?> ::

                                        <?php
                                            $locale = currentLocale();
                                            $field = 'sub_category_' . $locale;
                                            $value = !empty($data['subCategory']->$field)
                                                ? $data['subCategory']->$field
                                                : $data['subCategory']->sub_category;
                                        ?>

                                        <?php echo e($value); ?>

                                    </span>
                                    
                                </h5>
                            </div>
                            <div class="row col-md-12">
                                <div class="col-md-4 ps-5">
                                    <?php
                                        $image = asset('system/images/icon_placeholder.png');
                                        if (
                                            $data['subCategory']->image &&
                                            file_exists(
                                                public_path(
                                                    'assets/uploads/products/categories/subCategories/icons/' .
                                                        $data['subCategory']->image,
                                                ),
                                            )
                                        ) {
                                            $image = asset(
                                                'assets/uploads/products/categories/subCategories/icons/' .
                                                    $data['subCategory']->image,
                                            );
                                        }
                                    ?>

                                    <img src="<?php echo e($image); ?>" class="img-fluid">
                                </div>
                                <div class="col-md-8 ps-5">
                                    <p><span class="fw-bold"><?php echo e(t('app.product.subCategory')); ?>:
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'sub_category_' . $locale;
                                            $value = !empty($data['subCategory']->$field)
                                                ? $data['subCategory']->$field
                                                : $data['subCategory']->sub_category;
                                        ?>

                                        <?php echo e($value); ?>

                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.product.parentCategory')); ?>:
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'category_' . $locale;
                                            $value = !empty($data['category']->$field)
                                                ? $data['category']->$field
                                                : $data['category']->category;
                                        ?>

                                        <?php echo e($value); ?>

                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.status.status')); ?>: </span>
                                        <?php switch($data['subCategory']->is_active):
                                            case (true): ?>
                                                <span
                                                    class="badge bg-soft-success text-success"><?php echo e(t('app.status.active')); ?></span>
                                            <?php break; ?>

                                            <?php default: ?>
                                                <span
                                                    class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.inactive')); ?></span>
                                        <?php endswitch; ?>
                                    </p>
                                    <p><span class="fw-bold"><?php echo e(t('app.product.featured')); ?>: </span>
                                        <?php switch($data['subCategory']->is_featured):
                                            case (true): ?>
                                                <span class="badge bg-soft-success text-success"><?php echo e(t('app.status.true')); ?></span>
                                            <?php break; ?>

                                            <?php default: ?>
                                                <span class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.false')); ?></span>
                                        <?php endswitch; ?>
                                    </p>
                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-bold">
                                            <?php echo e(t('app.product.products')); ?>:
                                        </span>

                                        <span>
                                            <?php echo e($data['subCategory']->products->count()); ?>

                                        </span>

                                        
                                        <form method="GET" action="<?php echo e(route('productsSearch')); ?>" target="_blank"
                                            class="m-0">

                                            <input type="hidden" name="searchKey"
                                                value="<?php echo e($data['subCategory']->category); ?>">

                                            <button type="submit" class="badge bg-soft-primary text-primary border-0">
                                                <i class="feather-eye"></i>
                                            </button>

                                        </form>

                                    </div>
                                    <span class="text-decoration-underline fw-bold"><?php echo e(t('app.settings.seo.seo')); ?></span>
                                    <p>
                                        <span class="fw-bold"><?php echo e(t('app.settings.seo.metaTitle')); ?>:
                                        </span>

                                        <?php
                                            $locale = currentLocale();
                                            $field = 'meta_title_' . $locale;
                                            $value = !empty($data['subCategory']->$field)
                                                ? $data['subCategory']->$field
                                                : $data['subCategory']->meta_title;
                                        ?>

                                        <?php echo e($value); ?>

                                    </p>
                                    <p>
                                        <span class="fw-bold"><?php echo e(t('app.settings.seo.metaDescription')); ?>:
                                        </span>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'meta_description_' . $locale;
                                        ?>

                                        <?php
                                            $locale = currentLocale();
                                            $field = 'meta_description_' . $locale;
                                            $value = !empty($data['subCategory']->$field)
                                                ? $data['subCategory']->$field
                                                : $data['subCategory']->meta_description;
                                        ?>

                                        <?php echo e($value); ?>

                                    </p>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <a href="<?php echo e(route('editSubCategory', ['slug' => $data['subCategory']->slug])); ?>?language=en"
                                        class="btn btn-primary">
                                        <i class="feather-edit me-2"></i> <?php echo e(t('app.buttons.edit')); ?>

                                    </a>
                                </div>


                            </div>

                        </div>
                        
                        <div class="row mb-4 justify-content-center">
                            <div class="col-auto">
                                <a class="btn btn-primary"
                                    href="<?php echo e(route('subCategories', ['slug' => $data['category']->slug])); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>


    
    <?php echo $__env->make('users.admin.products.categories.include.addSubCategoryModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/categories/subCategories/viewSubCategory.blade.php ENDPATH**/ ?>