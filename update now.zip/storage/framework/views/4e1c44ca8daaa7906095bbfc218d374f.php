<?php $__env->startSection('title', $data['pageTitle']); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.product.featuredProducts')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a
                            href="#"><?php echo e(t('app.sales.sales')); ?>/<?php echo e(t('app.sales.marketing')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.product.featuredProducts')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <div class="dropdown">
                            <a class="btn btn-icon btn-light-brand" data-bs-toggle="dropdown" data-bs-offset="0, 10"
                                data-bs-auto-close="outside">
                                <i class="feather-filter"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="javascript:void(0);" class="dropdown-item filter-option active fw-bold"
                                    data-filter="all">
                                    <span class="wd-7 ht-7 bg-primary rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.all')); ?></span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="active">
                                    <span class="wd-7 ht-7 bg-success rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.active')); ?></span>
                                </a>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="inactive">
                                    <span class="wd-7 ht-7 bg-danger rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.inactive')); ?></span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="available">
                                    <span class="wd-7 ht-7 bg-success rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.available')); ?></span>
                                </a>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="unavailable">
                                    <span class="wd-7 ht-7 bg-danger rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.notAvailable')); ?></span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="featured">
                                    <span class="wd-7 ht-7 bg-warning rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.featured')); ?></span>
                                </a>
                                <a href="javascript:void(0);" class="dropdown-item filter-option"
                                    data-filter="not-featured">
                                    <span class="wd-7 ht-7 bg-secondary rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.notFeatured')); ?></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">

                <!-- [Latest Leads] start -->
                <div class="col-xxl-12">
                    <div class="card stretch stretch-full">
                        <div class="card-header">
                            <h5 class="card-title">
                                <?php echo e($data['pageTitle']); ?>

                                
                            </h5>

                            

                            <div class="table-search">
                                <!-- Search form -->
                                <form method="GET" class="search-form" action="<?php echo e(route('featuredProductsSearch')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="searchKey" class="form-control form-control-sm"
                                        placeholder="<?php echo e(t('app.search')); ?>..." value="<?php echo e($data['searchKey']); ?>">
                                </form>
                                <!-- Toggle button (visible only on mobile) -->
                                <button type="button" class="btn btn-sm btn-light search-toggle">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>


                            
                        </div>
                        <div class="card-body custom-card-action p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr class="border-b">
                                            <th scope="row">#</th>
                                            <th scope="row"><?php echo e(t('app.thumbnail')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.sku')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.product')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.brand')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.category')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.ratings')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.price')); ?></th>
                                            <th scope="row"><?php echo e(t('app.published')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.availability')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.featured')); ?></th>
                                            <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                        </tr>
                                    </thead>
                                    <?php if($data['products']->isEmpty()): ?>
                                        <tbody>
                                            <td colspan="11" class="text-center text-danger fw-bold fs-5">
                                                <?php echo e(t('app.noRecordsFound')); ?>

                                            </td>
                                        </tbody>
                                    <?php else: ?>
                                        <tbody>
                                            <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($loop->iteration); ?>

                                                    </td>
                                                    <td>
                                                        <?php
                                                            $thumbnailImage = asset(
                                                                'system/images/icon_placeholder.png',
                                                            );

                                                            if (!$product->mediaFiles->isEmpty()) {
                                                                $primaryImage = $product->mediaFiles
                                                                    ->where('is_primary', true)
                                                                    ->first();

                                                                if ($primaryImage) {
                                                                    $thumbnailImage = asset(
                                                                        'assets/uploads/products/products/media/images/' .
                                                                            $primaryImage->file_name,
                                                                    );
                                                                }
                                                            }
                                                        ?>

                                                        <img src="<?php echo e($thumbnailImage); ?>" alt="<?php echo e($product->name); ?>"
                                                            width="90px">
                                                    </td>
                                                    <td class="text-uppercase">
                                                        <?php echo e($product->sku); ?>

                                                    </td>
                                                    <td>
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $value = !empty($product->$field)
                                                                ? $product->$field
                                                                : $product->name;
                                                        ?>

                                                        <?php echo e($value); ?>

                                                    </td>
                                                    <td>

                                                        <?php if($product->brand): ?>
                                                            <?php
                                                                $logoPath = public_path(
                                                                    'assets/uploads/products/brands/logo/' .
                                                                        $product->brand->logo,
                                                                );
                                                            ?>
                                                            <?php if($product->brand->logo && file_exists($logoPath)): ?>
                                                                <img src="<?php echo e(asset('assets/uploads/products/brands/logo/' . $product->brand->logo)); ?>"
                                                                    width="100">
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('system/images/logo_placeholder.jpg')); ?>"
                                                                    width="100">
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            -
                                                        <?php endif; ?>

                                                    </td>
                                                    <td>
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'category_' . $locale;
                                                            $value = !empty($product->category->$field)
                                                                ? $product->category->$field
                                                                : $product->category->category;
                                                        ?>

                                                        <?php echo e($value); ?>

                                                    </td>
                                                    <td>
                                                        <?php
                                                            $rating = 3.75;
                                                        ?>

                                                        <div class="rating">
                                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                                <?php if($rating >= $i): ?>
                                                                    <i class="fas fa-star text-warning"></i>
                                                                <?php elseif($rating >= $i - 0.5): ?>
                                                                    <i class="fas fa-star-half-alt text-warning"></i>
                                                                <?php else: ?>
                                                                    <i class="far fa-star text-muted"></i>
                                                                <?php endif; ?>
                                                            <?php endfor; ?>
                                                            <span class="ms-2"><?php echo e(number_format($rating, 2)); ?></span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?php if(!is_null($product->price) && $product->price != 0): ?>
                                                            ₦<?php echo e(number_format($product->price, 2)); ?>

                                                        <?php else: ?>
                                                            -
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <span
                                                            class="badge <?php echo e($product->is_active ? 'bg-soft-success text-success' : 'bg-soft-danger text-danger'); ?>"
                                                            data-type="active"
                                                            data-value="<?php echo e($product->is_active ? 1 : 0); ?>">
                                                            <?php echo e($product->is_active ? t('app.status.true') : t('app.status.false')); ?>

                                                        </span>
                                                    </td>

                                                    <td>
                                                        <span
                                                            class="badge <?php echo e($product->is_available ? 'bg-soft-success text-success' : 'bg-soft-danger text-danger'); ?>"
                                                            data-type="available"
                                                            data-value="<?php echo e($product->is_available ? 1 : 0); ?>">
                                                            <?php echo e($product->is_available ? t('app.status.available') : t('app.status.notAvailable')); ?>

                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span
                                                            class="badge <?php echo e($product->is_featured ? 'bg-soft-success text-success' : 'bg-soft-danger text-danger'); ?>"
                                                            data-type="featured"
                                                            data-value="<?php echo e($product->is_featured ? 1 : 0); ?>">
                                                            <?php echo e($product->is_featured ? t('app.status.true') : t('app.status.false')); ?>

                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-primary text-white cursor-pointer"
                                                            onclick="editFeaturedProductFormModal('<?php echo e($product->slug); ?>', <?php echo e($product->is_featured ? 1 : 0); ?>)"
                                                            id="edit-<?php echo e($product->slug); ?>">
                                                            <i class="feather-edit"></i> <?php echo e(t('app.buttons.edit')); ?>

                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    <?php endif; ?>
                                </table>

                            </div>
                        </div>

                        
                        <?php
                            $paginatedArray = $data['products'];
                        ?>
                        <?php echo $__env->make('utilities.pages.others.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        
                        <?php if($data['products']->isNotEmpty()): ?>
                            <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <script>
                                    function editFeaturedProductFormModal(slug, currentValue, sizeClass = 'swal-size-md mx-5') {
                                        Swal.fire({
                                            title: "<?php echo e(t('app.buttons.edit')); ?> :: <?php echo e(t('app.product.featuredProduct')); ?>",
                                            showCloseButton: true,
                                            showConfirmButton: false,
                                            customClass: {
                                                popup: sizeClass
                                            },
                                            html: `
            <form id="swalForm" method="POST" action="/admin/sales_marketing/featured_products/toggle-featured/${slug}">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.product.featured')); ?></label>
                    <select class="form-select text-center" name="is_featured" required>
                        <option value="1" ${currentValue == 1 ? 'selected' : ''}><?php echo e(t('app.status.true')); ?></option>
                        <option value="0" ${currentValue == 0 ? 'selected' : ''}><?php echo e(t('app.status.false')); ?></option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
            </form>
        `
                                        });
                                    }
                                </script>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        

                    </div>

                </div>
                
                <div class="row mb-4 justify-content-center">
                    <div class="col-auto">
                        <?php switch($data['requestType']):
                            case ('search'): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('featuredProducts')); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            <?php break; ?>

                            <?php default: ?>
                        <?php endswitch; ?>
                    </div>
                </div>


                <!-- [Latest Leads] end -->

            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/featuredProducts/featuredProducts.blade.php ENDPATH**/ ?>