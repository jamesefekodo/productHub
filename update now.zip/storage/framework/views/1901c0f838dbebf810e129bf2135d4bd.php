<?php $__env->startSection('title', t('app.buttons.edit') . '::' . t('app.settings.homePageSlider')); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><a href="#"><?php echo e(t('app.settings.homePageSlider')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><a href="#"><?php echo e(t('app.settings.settings')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><a
                                href="#"><?php echo e(t('app.buttons.edit')); ?></a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e(t('app.buttons.edit')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <div class="bg-white py-3 border-bottom rounded-0 p-md-0 mb-0">
            <div class="d-md-none d-flex">
                <a href="javascript:void(0)" class="page-content-left-open-toggle">
                    <i class="feather-align-left fs-20"></i>
                </a>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="tab-content">
                <div class="row col-md-12">
                    
                    <div class="col-md-2">
                        <?php echo $__env->make('users.admin.config.homepage.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    
                    <div class="card stretch stretch-full col-md-10">
                        <div class="card-body lead-status">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="fw-bold mb-0 me-4">
                                    <span class="d-block mb-2"><?php echo e(t('app.buttons.edit')); ?> ::
                                        <?php echo e(t('app.settings.homePageConfig')); ?>

                                    </span>
                                    
                                </h5>
                                
                                <div class="d-flex flex-wrap justify-content-end gap-2">
                                    <?php $__currentLoopData = activeLanguages()->where('status', 'active'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('editSlider', ['id' => $data['slider']->id])); ?>?language=<?php echo e($language->language_code); ?>"
                                            class="btn btn-sm edit-by-lang <?php echo e($data['language'] == $language->language_code ? 'edit-by-lang-active' : ''); ?> d-flex align-items-center gap-1">
                                            <img src="<?php echo e(asset('system/images/lang/' . $language->flag)); ?>" alt=""
                                                width="22">
                                            <?php echo e($language->language); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                
                            </div>

                        </div>

                        <div class="card-body general-info">
                            <div class="card-body">
                                <form id="swalForm" method="POST"
                                    action="<?php echo e(route('updateSliderSubmit', ['id' => $data['slider']->id])); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <input type="hidden" name="language" value="<?php echo e($data['language']); ?>">

                                    <?php
                                        $image = asset('system/images/icon_placeholder.png');

                                        $filePath = public_path(
                                            'assets/uploads/homepageSlider/' . $data['slider']->background_image,
                                        );

                                        if (!empty($data['slider']->background_image) && file_exists($filePath)) {
                                            $image = asset(
                                                'assets/uploads/homepageSlider/' . $data['slider']->background_image,
                                            );
                                        }
                                    ?>

                                    <div class="mb-3 form-group upload-container">
                                        <div class="row d-flex justify-content-center">
                                            <div class="col-md-6"><label for="passport-upload" class="preview-frame">
                                                    <img id="passport-preview" src="<?php echo e($image); ?>" alt="">
                                                    <div class="overlay"><i class="fas fa-upload"></i></div>
                                                </label>
                                            </div>
                                            <div class="col-md-6"><input type="file" id="passport-upload"
                                                    accept=".jpg, .jpeg, .png, .webp" onchange="previewPassport()"
                                                    name="background_image">
                                            </div>
                                            <p class="text-red"><?php echo e($errors->first('background_image')); ?></p>
                                        </div>
                                    </div>

                                    <div class="row col-md-12">
                                        <div class="mb-4 col-md-12">
                                            <label class="form-label"><?php echo e(t('app.header')); ?> <span
                                                    class="text-danger">*</span></label>
                                            <?php
                                                $lang = $data['language'];
                                                $field = 'header_' . $lang;
                                                $header = !empty($data['slider']->$field)
                                                    ? $data['slider']->$field
                                                    : $data['slider']->header;
                                            ?>


                                            <input type="text" class="form-control" name="header"
                                                value="<?php echo e($header); ?>" required>
                                            <p class="text-danger"><?php echo e($errors->first('header')); ?>

                                            </p>
                                        </div>

                                        <div class="mb-4 col-md-12">
                                            <label class="form-label"><?php echo e(t('app.description')); ?> <span
                                                    class="text-danger">*</span></label>
                                            <?php
                                                $lang = $data['language'];
                                                $field = 'description_' . $lang;
                                                $desc = !empty($data['slider']->$field)
                                                    ? $data['slider']->$field
                                                    : $data['slider']->description;
                                            ?>

                                            <input type="text" class="form-control" name="description"
                                                value="<?php echo e($desc); ?>" required>
                                            <p class="text-danger"><?php echo e($errors->first('description')); ?>

                                            </p>
                                        </div>

                                        <div class="mb-4 col-md-12">
                                            <label class="form-label"><?php echo e(t('app.link')); ?></label>
                                            <input type="url" class="form-control" name="link"
                                                value="<?php echo e($data['slider']->link); ?>" placeholder="https://example.com">
                                            <p class="text-danger"><?php echo e($errors->first('link')); ?>

                                            </p>
                                        </div>

                                        <div class="mb-4 col-md-12">
                                            <label class="form-label"><?php echo e(t('app.order')); ?> <span
                                                    class="text-danger">*</span></label>
                                            <input type="number" class="form-control" name="order"
                                                value="<?php echo e($data['slider']->order); ?>" min="0" step="1"
                                                required>
                                            <p class="text-danger"><?php echo e($errors->first('order')); ?>

                                            </p>
                                        </div>
                                    </div>

                                    <button type="submit"
                                        class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
                                </form>

                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-4 justify-content-center">
                        <div class="col-auto">
                            <a class="btn btn-primary" href="<?php echo e(route('homePageSliderConfig')); ?>">
                                <i class="fas fa-chevron-left"></i> &nbsp;
                                <?php echo e(t('app.buttons.back')); ?>

                            </a>
                        </div>
                    </div>


                </div>


            </div>
        </div>
        <!-- [ Main Content ] end -->

        <script>
            function previewPassport() {
                const preview = document.getElementById('passport-preview');
                const fileInput = document.getElementById('passport-upload');
                const file = fileInput.files[0];
                const reader = new FileReader();

                reader.onload = function() {
                    preview.src = reader.result;
                }

                if (file) {
                    reader.readAsDataURL(file);
                } else {
                    preview.src = 'placeholder.jpg';
                }
            }
        </script>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/config/homepage/editSliderConfig.blade.php ENDPATH**/ ?>