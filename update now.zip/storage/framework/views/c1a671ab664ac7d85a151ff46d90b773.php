<script>
    // Configure toastr
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
</script>





<?php if(session('success')): ?>
    <script>
        toastr.success(
            <?php echo json_encode(session('success'), 15, 512) ?>,
            <?php echo json_encode(t('notifications.success'), 15, 512) ?>
        );
    </script>
<?php elseif(session('error')): ?>
    <script>
        toastr.error(
            <?php echo json_encode(session('error'), 15, 512) ?>,
            <?php echo json_encode(t('notifications.error'), 15, 512) ?>
        );
    </script>
<?php elseif(session('info')): ?>
    <script>
        toastr.info(
            <?php echo json_encode(session('info'), 15, 512) ?>,
            <?php echo json_encode(t('notifications.info'), 15, 512) ?>
        );
    </script>
<?php elseif(session('warning')): ?>
    <script>
        toastr.warning(
            <?php echo json_encode(session('warning'), 15, 512) ?>,
            <?php echo json_encode(t('notifications.warning'), 15, 512) ?>
        );
    </script>
<?php endif; ?>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/layouts/include/toastrNotificationFunction.blade.php ENDPATH**/ ?>