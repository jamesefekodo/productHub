<?php $__env->startSection('title', $data['pageTitle']); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.settings.address.countries')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.settings.settings')); ?></a></li>
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.settings.address.address')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.settings.address.states')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <div class="dropdown">
                            <a class="btn btn-icon btn-light-brand" data-bs-toggle="dropdown" data-bs-offset="0, 10"
                                data-bs-auto-close="outside">
                                <i class="feather-filter"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="javascript:void(0);" class="dropdown-item filter-option active fw-bold"
                                    data-filter="all">
                                    <span class="wd-7 ht-7 bg-primary rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.all')); ?></span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="active">
                                    <span class="wd-7 ht-7 bg-success rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.active')); ?></span>
                                </a>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="inactive">
                                    <span class="wd-7 ht-7 bg-danger rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.inactive')); ?></span>
                                </a>
                            </div>
                        </div>
                        <button onclick="addStateFormModal('swal-size-md')" class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span><?php echo e(t('app.addNew')); ?></span>
                        </button>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">
                
                <div class="col-md-2">
                    <?php echo $__env->make('users.admin.settings.address.country.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                
                <!-- [Latest Leads] start -->
                <div class="col-md-10">
                    <div class="col-xxl-12">
                        <div class="card stretch stretch-full">
                            <div class="card-header">
                                <h5 class="card-title">
                                    <?php echo e($data['pageTitle']); ?>

                                    
                                </h5>

                                

                                <div class="table-search">
                                    <!-- Search form -->
                                    <form method="GET" class="search-form" action="<?php echo e(route('statesSearch')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="text" name="searchKey" class="form-control form-control-sm"
                                            placeholder="<?php echo e(t('app.search')); ?>..." value="<?php echo e($data['searchKey']); ?>">
                                    </form>
                                    <!-- Toggle button (visible only on mobile) -->
                                    <button type="button" class="btn btn-sm btn-light search-toggle">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                
                            </div>
                            <div class="card-body custom-card-action p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead>
                                            <tr class="border-b">
                                                <th scope="row">#</th>
                                                <th scope="row">
                                                    <?php echo e(t('app.settings.address.state')); ?>/<?php echo e(t('app.settings.address.province')); ?>

                                                </th>
                                                <th scope="row"><?php echo e(t('app.settings.address.country')); ?></th>
                                                <th scope="row">
                                                    <?php echo e(t('app.settings.address.lga')); ?>/<?php echo e(t('app.settings.address.cities')); ?>

                                                </th>
                                                <th scope="row"><?php echo e(t('app.status.status')); ?></th>
                                                <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                            </tr>
                                        </thead>
                                        <?php if($data['states']->isEmpty()): ?>
                                            <tbody>
                                                <td colspan="6" class="text-center text-danger fw-bold fs-5">
                                                    <?php echo e(t('app.noRecordsFound')); ?>

                                                </td>
                                            </tbody>
                                        <?php else: ?>
                                            <tbody>
                                                <?php $__currentLoopData = $data['states']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo e($loop->iteration); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($state->name); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($state->country->name); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($state->country->cities->count()); ?>

                                                        </td>
                                                        <td>
                                                            <?php switch($state->status):
                                                                case ('active'): ?>
                                                                    <span
                                                                        class="badge bg-soft-success text-success"><?php echo e(t('app.status.active')); ?></span>
                                                                <?php break; ?>

                                                                <?php case ('inactive'): ?>
                                                                    <span
                                                                        class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.inactive')); ?></span>
                                                                <?php break; ?>

                                                                <?php default: ?>
                                                            <?php endswitch; ?>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-primary text-white cursor-pointer"
                                                                onclick="editStateFormModal<?php echo e($state->id); ?>()"
                                                                id="edit-<?php echo e($state->id); ?>">
                                                                <i class="feather-edit"></i> <?php echo e(t('app.buttons.edit')); ?>

                                                            </span>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>

                            
                            <?php
                                $paginatedArray = $data['states'];
                            ?>
                            <?php echo $__env->make('utilities.pages.others.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                        </div>

                    </div>
                </div>
                
                <div class="row mb-4 justify-content-center">
                    <div class="col-auto">
                        <?php switch($data['requestType']):
                            case ('search'): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('states')); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            <?php break; ?>

                            <?php default: ?>
                        <?php endswitch; ?>
                    </div>
                </div>


                <!-- [Latest Leads] end -->

                
                <?php echo $__env->make('users.admin.settings.address.states.include.addStateModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php if(!$data['states']->isEmpty()): ?>
                    <?php $__currentLoopData = $data['states']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('users.admin.settings.address.states.include.editStateModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                <?php if(session('editStateId')): ?>
                                    const el = document.querySelector('[data-id="<?php echo e(session('editStateId')); ?>"]');
                                    if (el) editStateFormModal(el);
                                <?php endif; ?>
                            });
                        </script>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>


    
    <?php echo $__env->make('users.admin.settings.address.states.include.addressFilter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/settings/address/states/states.blade.php ENDPATH**/ ?>