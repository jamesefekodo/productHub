<?php $__env->startSection('title', t('app.product.category') . ' :: ' . $data['subCategory']->sub_category); ?>
<?php $__env->startSection('content'); ?>

    <div class="desktop-nav-bg"></div>
    <div class="main-content-wrapper">

        <section class="section">
            
            <?php
                $locale = currentLocale();
                $field = 'category_' . $locale;

                $catName =
                    isset($data['subCategory']->theCategory->$field) && $data['subCategory']->theCategory->$field
                        ? $data['subCategory']->theCategory->$field
                        : $data['subCategory']->theCategory->category;
            ?>

            

            <?php
                $locale = currentLocale();
                $field = 'sub_category_' . $locale;

                $subCatName =
                    isset($data['subCategory']->$field) && $data['subCategory']->$field
                        ? $data['subCategory']->$field
                        : $data['subCategory']->sub_category;
            ?>


            
            <div aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a
                            href="<?php echo e(route(routePrefix() . 'ViewCategory', ['slug' => $data['subCategory']->theCategory->slug])); ?>"><?php echo e($catName); ?></a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <?php echo e($subCatName); ?>

                    </li>
                </ol>
            </div>

            


            <div class="my-page-header"><?php echo e($subCatName); ?></div>

            
            <?php
                $featuredProduct = featuredProducts()->where('sub_category_id', $data['subCategory']->id);
            ?>
            <?php if($featuredProduct->isNotEmpty()): ?>

                <h2 class="section-title text-center mt-5 mb-3"><?php echo e(t('app.product.featuredProducts')); ?></h2>

                <div class="cat-carousel owl-carousel owl-theme">
                    <?php $__currentLoopData = $featuredProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route(routePrefix() . 'ViewProduct', ['slug' => $product->slug])); ?>">
                            <div class="cat-card">
                                <?php
                                    $thumbnailImage = asset('system/images/icon_placeholder.png');

                                    if (!$product->mediaFiles->isEmpty()) {
                                        $primaryImage = $product->mediaFiles->where('is_primary', true)->first();

                                        if ($primaryImage) {
                                            $thumbnailImage = asset(
                                                'assets/uploads/products/products/media/images/' .
                                                    $primaryImage->file_name,
                                            );
                                        }
                                    }
                                ?>
                                <img src="<?php echo e($thumbnailImage); ?>" alt="<?php echo e($product->name); ?>">
                                <div class="cat-overlay">
                                    <?php
                                        $locale = currentLocale();
                                        $field = 'name_' . $locale;
                                        $prodName = !empty($product->$field) ? $product->$field : $product->name;
                                    ?>


                                    <h3><?php echo e($prodName); ?></h3>
                                    <?php if(displayPrice() == true): ?>
                                        <?php if(!is_null($product->price) && $product->price != 0): ?>
                                            <span class="price">₦<?php echo e(number_format($product->price, 2)); ?></span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>


            
            <div class="my-4">
                <h2 class="section-title text-center mt-5 mb-3"><?php echo e(t('app.product.allProducts')); ?></h2>
                <?php if($data['subCategory']->activeProducts->isNotEmpty()): ?>
                    <div class="prod-grid">
                        <?php $__currentLoopData = $data['subCategory']->activeProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route(routePrefix() . 'ViewProduct', ['slug' => $product->slug])); ?>">
                                <div class="prod-card">
                                    <?php if($product->is_featured == true): ?>
                                        <span class="prod-tag"><?php echo e(t('app.product.featured')); ?></span>
                                    <?php endif; ?>
                                    <div class="prod-img">
                                        <?php
                                            $thumbnailImage = asset('system/images/icon_placeholder.png');

                                            if (!$product->mediaFiles->isEmpty()) {
                                                $primaryImage = $product->mediaFiles
                                                    ->where('is_primary', true)
                                                    ->first();

                                                if ($primaryImage) {
                                                    $thumbnailImage = asset(
                                                        'assets/uploads/products/products/media/images/' .
                                                            $primaryImage->file_name,
                                                    );
                                                }
                                            }
                                        ?>

                                        <img src="<?php echo e($thumbnailImage); ?>" alt="<?php echo e($product->name); ?>">
                                    </div>
                                    <div class="prod-info">
                                        <h4>
                                            <?php
                                                $locale = currentLocale();
                                                $field = 'name_' . $locale;
                                                $value = !empty($product->$field) ? $product->$field : $product->name;
                                            ?>

                                            <?php echo e($value); ?>

                                        </h4>

                                        <?php if(displayPrice() == true): ?>
                                            <?php if(!is_null($product->price) && $product->price != 0): ?>
                                                <span class="price">₦<?php echo e(number_format($product->price, 2)); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <h3 class="text-danger">
                            <?php echo e(t('notifications.noRecordsFound')); ?>

                        </h3>
                    </div>

                <?php endif; ?>
            </div>

        </section>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/customer/products/viewSubCategory.blade.php ENDPATH**/ ?>