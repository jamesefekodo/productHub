<script>
    function addTaxFormModal(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.addNew')); ?> :: <?php echo e(t('app.payment.tax')); ?>",
            showCloseButton: true,
            showConfirmButton: false, // no SweetAlert confirm button
            customClass: {
                popup: sizeClass
            },
            html: `
            <form id="swalForm" method="POST" action="<?php echo e(route('createTaxAccount')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.payment.taxName')); ?><span class="text-danger">*</span></label>
                    <input type="text" name="tax_name" class="form-control text-center" value="<?php echo e(old('tax_name')); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('tax_name')); ?></p>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.payment.taxMethod')); ?><span class="text-danger">*</span></label>
                   <select class="form-select text-center" name="tax_method" required>
                    <option disabled selected>
                        - <?php echo e(t('app.select')); ?> -
                    </option>
                    <option value="fixed_amount"><?php echo e(t('app.payment.fixedAmount')); ?></option>
                    <option value="percentage"><?php echo e(t('app.payment.percentage')); ?></option>
                </select>

                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('tax_method')); ?></p>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.payment.taxRate')); ?><span class="text-danger">*</span></label>
                    <input type="text" name="tax_rate" class="form-control text-center" value="<?php echo e(old('tax_rate')); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('tax_rate')); ?></p>
                </div>

                <div class="mb-3">
                        <label class="form-label">
                            <?php echo e(t('app.default')); ?>

                            <span class="text-danger">*</span>
                        </label>

                        <select name="is_default" class="form-select text-center" required>
                            <option value="1" <?php echo e(old('is_default', $item->is_default ?? 0) == 1 ? 'selected' : ''); ?>>
                                <?php echo e(t('app.status.true')); ?>

                            </option>
                            <option value="0" <?php echo e(old('is_default', $item->is_default ?? 0) == 0 ? 'selected' : ''); ?>>
                                <?php echo e(t('app.status.false')); ?>

                            </option>
                        </select>

                        <p style="color: red; font-size: 12px; margin-top: 5px;">
                            <?php echo e($errors->first('is_default')); ?>

                        </p>
                    </div>

                <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
            </form>
        `
        });
    }

    // Auto-open modal if there are validation errors
    document.addEventListener('DOMContentLoaded', function() {
        <?php if($errors->any()): ?>
            addTaxFormModal();
        <?php endif; ?>
    });
</script>

<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/payments/settings/taxes/include/addTaxModal.blade.php ENDPATH**/ ?>