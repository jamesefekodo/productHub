<script>
function addProductVariantColourFormModal(sizeClass = 'swal-size-md mx-5') {
    Swal.fire({
        title: "<?php echo e(t('app.buttons.update')); ?> :: <?php echo e(t('app.product.colour')); ?>",
        showCloseButton: true,
        showConfirmButton: false, // no SweetAlert confirm button
        customClass: {
            popup: sizeClass
        },
        html: `
            <form id="swalForm" method="POST" action="<?php echo e(route('addProductVariantColourSubmit')); ?>">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="variant" value="<?php echo e($data['variant']->slug); ?>">

                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.product.colour')); ?></label>

                    <select class="form-select text-center <?php $__errorArgs = ['colour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="colour" required>

                        <option value="" disabled <?php echo e(old('colour') ? '' : 'selected'); ?>>
                            - <?php echo e(t('app.select')); ?> -
                        </option>

                        <?php $__empty_1 = true; $__currentLoopData = $data['allColours']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($colour->id); ?>" <?php echo e($data['variant']->colour_id == $colour->id ? 'selected' : ''); ?>>
                                <?php echo e($colour->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option disabled>No colour available</option>
                        <?php endif; ?>

                    </select>

                    <?php $__errorArgs = ['colour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
            </form>
        `
    });
}

// Auto-open modal if there are validation errors
document.addEventListener('DOMContentLoaded', function() {
    <?php if($errors->any()): ?>
        addProductColourFormModal();
    <?php endif; ?>
});
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/variants/include/addProductVariantColourModal.blade.php ENDPATH**/ ?>