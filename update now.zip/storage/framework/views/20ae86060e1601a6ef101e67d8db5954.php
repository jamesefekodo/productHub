<?php $__env->startSection('title', t('app.settings.homePageConfig')); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.settings.homePageConfig')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.settings.settings')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.settings.homePageConfig')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">
                <!-- [Latest Leads] start -->
                <div class="col-md-12 row">
                    
                    <div class="col-md-2">
                        <?php echo $__env->make('users.admin.config.homepage.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    
                    <div class="card stretch stretch-full col-md-10">
                        <div class="card-header">
                            <h5 class="card-title">
                                <?php echo e(t('app.settings.homePageConfig')); ?>

                            </h5>
                        </div>
                        <div class="card-body custom-card-action p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr class="border-b">
                                            <th scope="row">#</th>
                                            <th scope="row"><?php echo e(t('app.settings.config')); ?></th>
                                            <th scope="row"><?php echo e(t('app.description')); ?></th>
                                            <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                1
                                            </td>
                                            <td>
                                                <?php echo e(t('app.settings.homePageSlider')); ?>

                                            </td>
                                            <td>
                                                <?php echo e(t('app.settings.homePageSliderDesc')); ?>

                                            </td>
                                            <td>
                                                <a href="
                                            
                                             "
                                                    class="btn btn-primary d-inline-flex align-items-center gap-1">
                                                    <i class="feather-eye"></i>
                                                    <?php echo e(t('app.buttons.view')); ?>

                                                </a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>

                </div>


                <!-- [Latest Leads] end -->

            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/config/homepage/homePageConfig.blade.php ENDPATH**/ ?>