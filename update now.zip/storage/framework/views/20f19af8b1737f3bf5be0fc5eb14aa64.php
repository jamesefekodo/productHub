<script>
function addProductVariantAttributeFormModal(sizeClass = 'swal-size-md mx-5') {
    Swal.fire({
        title: "<?php echo e(t('app.buttons.update')); ?> :: <?php echo e(t('app.product.attribute')); ?>",
        showCloseButton: true,
        showConfirmButton: false,
        customClass: { popup: sizeClass },
        html: `
        <form id="swalForm" method="POST" action="<?php echo e(route('addProductVariantAttributeSubmit')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="variant" value="<?php echo e($data['variant']->slug); ?>">

            <div class="mb-3">
                <label class="form-label"><?php echo e(t('app.product.attribute')); ?> <span class="text-danger">*</span></label>
                <select class="form-select text-center" name="attribute_id" id="attribute-select" required>
                    <option value="">- <?php echo e(t('app.select')); ?> -</option>
                    <?php $__currentLoopData = $data['activeAttributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $locale = currentLocale();
                            $field = 'name_' . $locale;
                            $value = !empty($attribute->$field) ? $attribute->$field : $attribute->name;
                        ?>
                        <option value="<?php echo e($attribute->id); ?>"><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label"><?php echo e(t('app.product.value')); ?> <span class="text-danger">*</span></label>
                <select class="form-select text-center" id="value-select" name="value_id" disabled required>
                    <option value="">- <?php echo e(t('app.select')); ?> -</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
        </form>
        `,
        // Use 'onOpen' for compatibility with older versions
        onOpen: function() {
            const container = Swal.getHtmlContainer();
            if (!container) return;

            const attributeSelect = container.querySelector('#attribute-select');
            const valueSelect = container.querySelector('#value-select');

            if (!attributeSelect || !valueSelect) return;

            attributeSelect.addEventListener('change', function() {
                const attributeId = this.value;

                valueSelect.disabled = true;
                valueSelect.innerHTML = '<option>Loading...</option>';

                $.ajax({
                    url: "<?php echo e(route('fetchAttributeValue')); ?>",
                    method: "GET",
                    data: { attribute_id: attributeId },
                    success: function(res) {
                        valueSelect.innerHTML = '<option value="">- <?php echo e(t("app.select")); ?> -</option>';

                        if (!res.values || res.values.length === 0) {
                            valueSelect.innerHTML += '<option disabled>No values found</option>';
                            return;
                        }

                        res.values.forEach(function(value) {
                            valueSelect.innerHTML += `<option value="${value.id}">${value.localized_name}</option>`;
                        });

                        valueSelect.disabled = false;
                    },
                    error: function() {
                        valueSelect.innerHTML = '<option disabled>Error loading values</option>';
                    }
                });
            });
        }
    });
}

// Auto-open modal if validation errors exist
document.addEventListener('DOMContentLoaded', function() {
    <?php if($errors->any()): ?>
        addProductVariantAttributeFormModal();
    <?php endif; ?>
});
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/variants/include/addProductVariantAttributeModal.blade.php ENDPATH**/ ?>