<?php $__env->startSection('title', t('app.settings.address.contactDetails')); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.settings.address.contactDetails')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.settings.settings')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.settings.address.contactDetails')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span><?php echo e(t('app.buttons.back')); ?></span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">
                <!-- [Latest Leads] start -->
                <div class="col-md-12 row">
                    
                    <div class="col-md-2">
                        <?php echo $__env->make('users.admin.config.homepage.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    
                    <div class="card stretch stretch-full col-md-10">
                        <div class="card-header">
                            <h5 class="card-title">
                                <?php echo e(t('app.settings.address.contacts')); ?>

                            </h5>
                        </div>
                        <div class="card-body custom-card-action p-1 pb-3 row col-md-12">
                            <div class="col-md-6">
                                <p><span class="fw-bold"><?php echo e(t('auth.phone')); ?>:
                                    </span>
                                    <?php echo e($data['systemSettings']->phone ?? '-'); ?>

                                </p>
                                <p><span class="fw-bold"><?php echo e(t('auth.email')); ?>:
                                    </span>
                                    <?php echo e($data['systemSettings']->email ?? '-'); ?>

                                </p>
                                <p><span class="fw-bold"><?php echo e(t('app.settings.address.address')); ?>:
                                    </span>
                                    <?php echo e($data['systemSettings']->address ?? '-'); ?>

                                </p>
                                <div class="d-flex">
                                    <span onclick="editContactFormModal('swal-size-md')"
                                        class="btn btn-primary text-white ps-1">
                                        <i class="feather-edit ms-1"></i>
                                        <span><?php echo e(t('app.buttons.edit')); ?></span>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h5 class="text-decoration-underline"><?php echo e(t('app.settings.address.whatsappSupport')); ?></h5>
                                <?php if($data['whatsAppSupportLines']->count() > 0): ?>
                                    <?php $__currentLoopData = $data['whatsAppSupportLines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($line->name); ?> ==> <?php echo e($line->number); ?> ==> <?php switch($line->status):
                                                case ('active'): ?>
                                                    <span
                                                        class="badge bg-soft-success text-success"><?php echo e(t('app.status.active')); ?></span>
                                                <?php break; ?>

                                                <?php case ('inactive'): ?>
                                                    <span
                                                        class="badge bg-soft-danger text-danger"><?php echo e(t('app.status.inactive')); ?></span>
                                                <?php break; ?>

                                                <?php default: ?>
                                            <?php endswitch; ?>
                                            <a href="https://wa.me/<?php echo e(preg_replace('/[^0-9]/', '', $line->number)); ?>"
                                                class="ms-3" target="_blank" rel="noopener noreferrer"
                                                title="<?php echo e(t('app.settings.address.chatOnWhatsApp')); ?>">
                                                <i class="fab fa-whatsapp"
                                                    style="color: #25D366; font-size: 18px; margin-left: 8px;"></i>
                                            </a>

                                            <span onclick="editWhatsAppSupportFormModal<?php echo e($line->id); ?>()"
                                                class="badge bg-soft-primary text-primary ps-1" style="cursor: pointer;"
                                                id="edit-<?php echo e($line->id); ?>">
                                                <i class="feather-plus ms-1"></i>
                                                <span><?php echo e(t('app.buttons.edit')); ?></span>
                                            </span>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <h5 class="text-danger text-center"><?php echo e(t('notifications.noRecordsFound')); ?></h5>
                                <?php endif; ?>
                                <div class="d-flex m-3">
                                    <span onclick="addWhatsAppSupportFormModal('swal-size-md')"
                                        class="btn btn-primary text-white ps-1">
                                        <i class="feather-plus ms-1"></i>
                                        <span><?php echo e(t('app.addNew')); ?></span>
                                    </span>
                                </div>

                            </div>

                        </div>


                    </div>

                </div>
                <!-- [Latest Leads] end -->

                
                <?php echo $__env->make('users.admin.config.homepage.include.editContactModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('users.admin.config.homepage.include.addWhatsAppSupportModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



                <?php if($data['whatsAppSupportLines']->count() > 0): ?>
                    <?php $__currentLoopData = $data['whatsAppSupportLines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('users.admin.config.homepage.include.editWhatsAppSupportModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            <?php if(session('editLineId')): ?>
                                editWhatsAppSupportFormModal(<?php echo e(session('editLineId')); ?>);
                            <?php endif; ?>
                        });
                    </script>
                <?php endif; ?>



                

            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/config/homepage/contacts.blade.php ENDPATH**/ ?>