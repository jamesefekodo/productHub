<?php if($data['requestType'] == 'search'): ?>
    <?php $__env->startSection('title', t('app.searchResultFor') . ' :: ' . $data['searchKey']); ?>
<?php else: ?>
    <?php $__env->startSection('title', t('app.homePage')); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>

    <section class="hero">
        <?php if(!homepageSliders()->isEmpty()): ?>
            <?php $__currentLoopData = homepageSliders(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $image = $slider->background_image
                        ? asset('assets/uploads/homepageSlider/' . $slider->background_image)
                        : 'system/images/icon_placeholder.png';
                ?>

                <div class="slide active" style="background-image: url('<?php echo e($image); ?>');">
                    <div class="hero-box">
                        <?php
                            $locale = currentLocale();
                            $field = 'header_' . $locale;
                            $header = !empty($slider->$field) ? $slider->$field : $slider->header;
                        ?>
                        <h1><?php echo e($header); ?></h1>
                        <p><?php
                            $locale = currentLocale();
                            $field = 'description_' . $locale;
                            $desc = !empty($slider->$field) ? $slider->$field : $slider->description;
                        ?>
                            <?php echo e($desc); ?>

                        </p>

                        <?php if($slider->link): ?>
                            <div class="btn-group d-flex w-100 justify-content-end">
                                <?php
                                    $url = $slider->link;
                                    if (!preg_match('/^https?:\/\//', $url)) {
                                        $url = 'https://' . $url;
                                    }
                                ?>

                                <div class="">
                                    <a href="<?php echo e($url); ?>" class="btn btn-primary" rel="noopener noreferrer">
                                        <i class="fas fa-eye"></i> <?php echo e(t('app.buttons.view')); ?>

                                    </a>
                                </div>

                                
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="indicators">
                <?php $__currentLoopData = homepageSliders(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="dot <?php echo e($index === 0 ? 'active' : ''); ?>" onclick="setSlide(<?php echo e($index); ?>)"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php endif; ?>
    </section>

    <section class="section">
        <?php if($data['requestType'] !== 'search'): ?>
            <?php if(featuredCategories()->isNotEmpty()): ?>

                <h2 class="section-title"><?php echo e(t('app.product.featuredCategories')); ?></h2>

                <div class="cat-carousel owl-carousel owl-theme">
                    <?php $__currentLoopData = featuredCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route(routePrefix() . 'ViewCategory', ['slug' => $category->slug])); ?>">
                            <div class="cat-card">
                                <?php
                                    $imagePath = public_path(
                                        'assets/uploads/products/categories/icons/' . $category->image,
                                    );
                                    $imageUrl = file_exists($imagePath)
                                        ? asset('assets/uploads/products/categories/icons/' . $category->image)
                                        : asset('system/images/icon_placeholder.png');

                                    $locale = currentLocale();
                                    $field = 'category_' . $locale;
                                    $name = !empty($category->$field) ? $category->$field : $category->category;
                                ?>
                                <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($name); ?>">
                                <div class="cat-overlay">
                                    <h3><?php echo e($name); ?></h3>
                                    <p><?php echo e($category->products->count()); ?> <?php echo e(t('app.product.product')); ?></p>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

        <?php endif; ?>


        
        

        <?php echo $__env->make('frontend.include.searchBar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
        <?php if($data['requestType'] !== 'search'): ?>
            <?php if(featuredProducts()->isNotEmpty()): ?>
                <h2 class="section-title mt-5"><?php echo e(t('app.product.featuredProducts')); ?></h2>
                <div class="prod-grid">
                    <?php $__currentLoopData = featuredProducts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route(routePrefix() . 'ViewProduct', ['slug' => $product->slug])); ?>">
                            <div class="prod-card">
                                <?php if($product->is_featured == true): ?>
                                    <span class="prod-tag"><?php echo e(t('app.product.featured')); ?></span>
                                <?php endif; ?>
                                <div class="prod-img">
                                    <?php
                                        $thumbnailImage = asset('system/images/icon_placeholder.png');

                                        if (!$product->mediaFiles->isEmpty()) {
                                            $primaryImage = $product->mediaFiles->where('is_primary', true)->first();

                                            if ($primaryImage) {
                                                $thumbnailImage = asset(
                                                    'assets/uploads/products/products/media/images/' .
                                                        $primaryImage->file_name,
                                                );
                                            }
                                        }
                                    ?>

                                    <img src="<?php echo e($thumbnailImage); ?>" alt="<?php echo e($product->name); ?>">
                                </div>
                                <div class="prod-info">
                                    <h4>
                                        <?php
                                            $locale = currentLocale();
                                            $field = 'name_' . $locale;
                                            $value = !empty($product->$field) ? $product->$field : $product->name;
                                        ?>

                                        <?php echo e($value); ?>

                                    </h4>

                                    <?php if(displayPrice() == true): ?>
                                        <?php if(!is_null($product->price) && $product->price != 0): ?>
                                            <span class="price">₦<?php echo e(number_format($product->price, 2)); ?></span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            <?php endif; ?>
        <?php endif; ?>



    </section>
    
    <section class="main-rev-section">
        <div class="main-rev-container">

            <div class="main-rev-slider-wrap">
                <!-- No owl-carousel class here — initialized exclusively by ID in JS below -->
                <div id="mainRevOwlSlider">

                    <div class="main-rev-item">
                        <div class="main-rev-score">★★★★★</div>
                        <p class="main-rev-comment">"Excellent durability and precision. This exceeded all my expectations
                            for industrial use."</p>
                        <div class="main-rev-meta">
                            <div class="main-rev-avatar">JD</div>
                            <div>
                                <h4 class="main-rev-name">James Dalton</h4>
                                <span class="main-rev-status">Verified Purchase</span>
                            </div>
                        </div>
                    </div>

                    <div class="main-rev-item">
                        <div class="main-rev-score">★★★★☆</div>
                        <p class="main-rev-comment">"The integration was seamless. Docking one star only because shipping
                            took an extra day."</p>
                        <div class="main-rev-meta">
                            <div class="main-rev-avatar" style="background: #10b981;">MK</div>
                            <div>
                                <h4 class="main-rev-name">Maria Khan</h4>
                                <span class="main-rev-status">Verified Purchase</span>
                            </div>
                        </div>
                    </div>

                    <div class="main-rev-item">
                        <div class="main-rev-score">★★★★★</div>
                        <p class="main-rev-comment">"Top tier support team. They helped me configure the automation settings
                            in minutes."</p>
                        <div class="main-rev-meta">
                            <div class="main-rev-avatar" style="background: #f59e0b;">AL</div>
                            <div>
                                <h4 class="main-rev-name">Alex Lee</h4>
                                <span class="main-rev-status">Expert Reviewer</span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>


    <section class="newsletter">
        <div>
            <h2>Stay Informed</h2>
            <p>Get the latest enterprise updates and pricing.</p>


        </div>
        <div class="news-input">
            <input type="email" placeholder="Enter your email">
            
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/frontend/homepage.blade.php ENDPATH**/ ?>