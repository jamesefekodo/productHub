<?php $__env->startSection('title', t('auth.login')); ?>
<?php $__env->startSection('content'); ?>
    <div class="outer-container">
        <?php echo $__env->make('utilities.pages.auth.include.slider', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="login-form">
            <div class="form-container">
                <?php echo $__env->make('utilities.pages.auth.include.headerLogo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                <h2 class="m-2 text-center auth_header"><?php echo e(t('auth.welcomeBack')); ?></h2>
                <p class="m-2 text-center"><?php echo e(t('auth.signInMessage')); ?></p>
                <form class="" action="<?php echo e(route('submitLoginRequest')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" placeholder="<?php echo e(t('auth.usernameEmail')); ?>" name="login_id" required />
                    <p style="color: red"><?php echo e($errors->first('login_id')); ?></p>

                    <div class="password-container">
                        <input type="password" id="password" placeholder="********" name="password" autocomplete="off"
                            value="<?php echo e(old('password')); ?>" required />
                        <i class="fa fa-eye" id="togglePassword" style="cursor: pointer;"></i>
                    </div>
                    <p style="color: red"><?php echo e($errors->first('password')); ?></p>

                    <button type="submit"><?php echo e(t('auth.login')); ?></button>
                </form>
                <?php echo $__env->make('utilities.pages.auth.include.socialiteAuth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="form-options my-4">
                    <p class=""><?php echo e(t('auth.haveNoAccount')); ?> <a
                            href="<?php echo e(route('registrationPage')); ?>"><?php echo e(t('auth.register')); ?></a></p>
                    <p class=""><a
                            href="<?php echo e(route('forgotPassword')); ?>"><?php echo e(t('auth.forgotPassword')); ?></a>
                    </p>
                    <p class=""><a
                            href="
                        <?php echo e(route('homepage')); ?>

                         "><?php echo e(t('app.homePage')); ?></a>
                    </p>

                    <div class="d-flex justify-content-end">
                        <div class="text-center">
                            <?php echo $__env->make('utilities.pages.others.changeLanguage', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script>
        // Get the elements
        const togglePassword = document.getElementById('togglePassword');
        const passwordField = document.getElementById('password');

        // Toggle password visibility
        togglePassword.addEventListener('click', function() {
            // Toggle the type between "password" and "text"
            const type = passwordField.type === 'password' ? 'text' : 'password';
            passwordField.type = type;

            // Toggle the eye icon (between eye and eye-slash)
            if (passwordField.type === 'password') {
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            } else {
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            }
        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/utilities/pages/auth/login.blade.php ENDPATH**/ ?>