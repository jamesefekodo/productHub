<script>
    function addWhatsAppSupportFormModal(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.addNew')); ?> :: <?php echo e(t('app.settings.address.whatsappNumber')); ?>",
            showCloseButton: true,
            showConfirmButton: false, // no SweetAlert confirm button
            customClass: {
                popup: sizeClass
            },
            html: `
            <form id="swalForm" method="POST" action="<?php echo e(route('addWhatsappNumberSubmit')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(t('app.name')); ?></label>
                    <input type="text" name="name" class="form-control text-center" value="<?php echo e(old('name')); ?>" required>
                    <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('name')); ?></p>
                </div>
                <div class="mb-3">
                    <label class="form-label">
                        <?php echo e(t('app.settings.address.whatsappNumber')); ?>

                    </label>

                    <input type="tel"
                        name="number"
                        class="form-control text-center"
                        value="<?php echo e(old('number')); ?>"
                        placeholder="e.g. +2348012345678"
                        pattern="^\+?[0-9]{7,15}$"
                        required>

                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger small mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
            </form>
        `
        });
    }

    // Auto-open modal if there are validation errors
    document.addEventListener('DOMContentLoaded', function() {
        <?php if($errors->any()): ?>
            addWhatsAppSupportFormModal();
        <?php endif; ?>
    });
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/config/homepage/include/addWhatsAppSupportModal.blade.php ENDPATH**/ ?>