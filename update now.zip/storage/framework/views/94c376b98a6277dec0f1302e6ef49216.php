<?php $__env->startSection('title', $data['pageTitle']); ?>
<?php $__env->startSection('content'); ?>


    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo e(t('app.product.variations')); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e(t('app.product.products')); ?></a></li>
                    <li class="breadcrumb-item"><?php echo e(t('app.product.variations')); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <div class="dropdown">
                            <a class="btn btn-icon btn-light-brand" data-bs-toggle="dropdown" data-bs-offset="0, 10"
                                data-bs-auto-close="outside">
                                <i class="feather-filter"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="javascript:void(0);" class="dropdown-item filter-option active fw-bold"
                                    data-filter="all">
                                    <span class="wd-7 ht-7 bg-primary rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.all')); ?></span>
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="active">
                                    <span class="wd-7 ht-7 bg-success rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.active')); ?></span>
                                </a>
                                <a href="javascript:void(0);" class="dropdown-item filter-option" data-filter="inactive">
                                    <span class="wd-7 ht-7 bg-danger rounded-circle d-inline-block me-3"></span>
                                    <span><?php echo e(t('app.status.inactive')); ?></span>
                                </a>
                            </div>
                        </div>
                        <a href="<?php echo e(route('addProductVariant', ['slug' => $data['product']->slug])); ?>"
                            class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span><?php echo e(t('app.product.addProductVariant')); ?></span>
                        </a>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row col-md-12">
                
                <div class="col-md-2">
                    <?php echo $__env->make('users.admin.products.products.include.inner_nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                <!-- [Latest Leads] start -->
                <div class="col-md-10">
                    <div class="card stretch stretch-full">
                        <div class="card-header">
                            <h5 class="card-title">
                                <?php echo e($data['pageTitle']); ?>

                                
                                 -> <small class="text-soft-primary fw-normal fs-6">
                                    <?php echo e(t('app.product.parentProduct')); ?> ::
                                </small> <small class="badge badge-sm bg-soft-primary text-primary">

                                    <?php
                                        $locale = currentLocale();
                                        $field = 'name_' . $locale;
                                        $value = !empty($data['product']->$field)
                                            ? $data['product']->$field
                                            : $data['product']->name;
                                    ?>

                                    <?php echo e($value); ?>

                                    <?php if(!empty($data['product']->sku)): ?>
                                        (<?php echo e($data['product']->sku); ?>)
                                    <?php endif; ?>


                                </small>
                            </h5>

                            

                            <div class="table-search">
                                <!-- Search form -->
                                <form method="GET" class="search-form"
                                    action="<?php echo e(route('productVariationsSearch', ['slug' => $data['product']->slug])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="searchKey" class="form-control form-control-sm"
                                        placeholder="<?php echo e(t('app.search')); ?>..." value="<?php echo e($data['searchKey']); ?>">
                                </form>
                                <!-- Toggle button (visible only on mobile) -->
                                <button type="button" class="btn btn-sm btn-light search-toggle">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>


                            
                        </div>
                        <div class="card-body custom-card-action p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr class="border-b">
                                            <th scope="row">#</th>
                                            <th scope="row"><?php echo e(t('app.thumbnail')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.sku')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.variant')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.price')); ?></th>
                                            <th scope="row"><?php echo e(t('app.published')); ?></th>
                                            <th scope="row"><?php echo e(t('app.product.availability')); ?></th>
                                            <th scope="row" class=""><?php echo e(t('app.actions')); ?></th>
                                        </tr>
                                    </thead>
                                    <?php if($data['productVariations']->isEmpty()): ?>
                                        <tbody>
                                            <td colspan="8" class="text-center text-danger fw-bold fs-5">
                                                <?php echo e(t('app.noRecordsFound')); ?>

                                            </td>
                                        </tbody>
                                    <?php else: ?>
                                        <tbody>
                                            <?php $__currentLoopData = $data['productVariations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($loop->iteration); ?>

                                                    </td>
                                                    <td>
                                                        <img src="<?php echo e(optional($variation->mediaFile)->file_name
                                                            ? asset('assets/uploads/products/products/media/images/' . $variation->mediaFile->file_name)
                                                            : asset('system/images/icon_placeholder.png')); ?>"
                                                            alt="<?php echo e($variation->name); ?>" width="90">
                                                    </td>
                                                    <td>
                                                        <?php echo e($variation->sku); ?>

                                                    </td>
                                                    <td>
                                                        <?php
                                                            $locale = currentLocale();
                                                            $field = 'name_' . $locale;
                                                            $value = !empty($variation->$field)
                                                                ? $variation->$field
                                                                : $variation->name;
                                                        ?>

                                                        <?php echo e($value); ?>

                                                    </td>
                                                    <td>
                                                        <?php if(!is_null($variation->price)): ?>
                                                            ₦<?php echo e(number_format($variation->price, 2)); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <span
                                                            class="badge <?php echo e($variation->is_active ? 'bg-soft-success text-success' : 'bg-soft-danger text-danger'); ?>"
                                                            data-type="active"
                                                            data-value="<?php echo e($variation->is_active ? 1 : 0); ?>">
                                                            <?php echo e($variation->is_active ? t('app.status.true') : t('app.status.false')); ?>

                                                        </span>
                                                    </td>

                                                    <td>
                                                        <span
                                                            class="badge <?php echo e($variation->is_available ? 'bg-soft-success text-success' : 'bg-soft-danger text-danger'); ?>"
                                                            data-type="available"
                                                            data-value="<?php echo e($variation->is_available ? 1 : 0); ?>">
                                                            <?php echo e($variation->is_available ? t('app.status.available') : t('app.status.notAvailable')); ?>

                                                        </span>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('viewProductVariant', ['slug' => $variation->slug])); ?>"
                                                            class="btn btn-primary d-inline-flex align-items-center gap-1">
                                                            <i class="feather-eye"></i>
                                                            <?php echo e(t('app.buttons.view')); ?>

                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>

                        
                        <?php
                            $paginatedArray = $data['productVariations'];
                        ?>
                        <?php echo $__env->make('utilities.pages.others.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                    </div>

                </div>
                
                <div class="row mb-4 justify-content-center">
                    <div class="col-auto">
                        <?php switch($data['requestType']):
                            case ('search'): ?>
                                <a class="btn btn-primary"
                                    href="<?php echo e(route('productVariations', ['slug' => $data['product']->slug])); ?>">
                                    <i class="fas fa-chevron-left"></i> &nbsp;
                                    <?php echo e(t('app.buttons.back')); ?>

                                </a>
                            <?php break; ?>

                            <?php default: ?>
                        <?php endswitch; ?>
                    </div>
                </div>


                <!-- [Latest Leads] end -->
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Filter script loaded');

            // Get all filter buttons
            const filterButtons = document.querySelectorAll('.filter-option');
            const tableRows = document.querySelectorAll('table tbody tr');

            console.log('Found filter buttons:', filterButtons.length);
            console.log('Found table rows:', tableRows.length);

            // Filter function
            function filterTable(status) {
                console.log('Filtering by:', status);

                let visibleCount = 0;

                tableRows.forEach(row => {
                    // Skip "no records" row
                    if (row.querySelector('td[colspan]')) {
                        return;
                    }

                    // Get status badge
                    const statusBadge = row.querySelector('.badge');

                    if (!statusBadge) {
                        row.style.display = '';
                        return;
                    }

                    // Determine row status
                    let rowStatus = 'inactive';
                    if (statusBadge.classList.contains('bg-soft-success') ||
                        statusBadge.classList.contains('text-success')) {
                        rowStatus = 'active';
                    }

                    // Show/hide row
                    if (status === 'all' || rowStatus === status) {
                        row.style.display = '';
                        visibleCount++;
                    } else {
                        row.style.display = 'none';
                    }
                });

                console.log('Visible rows:', visibleCount);

                // Update button states
                filterButtons.forEach(btn => {
                    if (btn.getAttribute('data-filter') === status) {
                        btn.classList.add('active', 'fw-bold');
                        btn.style.backgroundColor = '#f0f4ff';
                    } else {
                        btn.classList.remove('active', 'fw-bold');
                        btn.style.backgroundColor = '';
                    }
                });
            }

            // Add click event to each filter button
            filterButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    console.log('Filter clicked');

                    const filterValue = this.getAttribute('data-filter');
                    console.log('Filter value:', filterValue);

                    filterTable(filterValue);
                });
            });

            // Set "All" as default
            console.log('Setting default filter to: all');
            filterTable('all');
        });
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/products/products/variants/productVariants.blade.php ENDPATH**/ ?>