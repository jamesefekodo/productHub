<script>
    function editStateFormModal<?php echo e($state->id); ?>(sizeClass = 'swal-size-md mx-5') {
        Swal.fire({
            title: "<?php echo e(t('app.buttons.edit')); ?> :: <?php echo e(t('app.settings.address.state')); ?>",
            showCloseButton: true,
            showConfirmButton: false,
            customClass: {
                popup: sizeClass
            },
            html: `
                <form id="swalForm" method="POST" action="<?php echo e(route('updateStateSubmit', ['id' => $state->id])); ?>"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.settings.address.state')); ?></label>
                        <input type="text" name="state" class="form-control text-center" value="<?php echo e($state->name); ?>" required>
                        <p style="color: red; font-size: 12px; margin-top: 5px;"><?php echo e($errors->first('state')); ?></p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.settings.address.country')); ?></label>

                        <select class="form-select text-center <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="country" required>

                            <option value="" disabled <?php echo e(old('country') ? '' : 'selected'); ?>>
                                - <?php echo e(t('app.select')); ?> -
                            </option>

                            <?php $__empty_1 = true; $__currentLoopData = $data['allCountries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($country->id); ?>" <?php echo e($state->country_id == $country->id ? 'selected' : ''); ?>>
                                    <?php echo e($country->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option disabled>No countries available</option>
                            <?php endif; ?>

                        </select>

                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label"><?php echo e(t('app.status.status')); ?></label>
                        <select class="form-select text-center" name="status" required>
                            <option selected disabled>
                                -Select-</option>
                            <option value="active" <?php echo e($state->status == 'active' ? 'selected' : ''); ?>>
                                <?php echo e(t('app.status.active')); ?></option>
                            <option value="inactive" <?php echo e($state->status == 'inactive' ? 'selected' : ''); ?>>
                                <?php echo e(t('app.status.inactive')); ?></option>
                        </select>
                        <p id="phone-error" style="color: red; font-size: 12px; margin-top: 5px;"></p>
                    </div>



                    <button type="submit" class="btn btn-primary w-100 mt-2"><?php echo e(t('app.buttons.submit')); ?></button>
                </form>
            `
        });
    }
</script>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/settings/address/states/include/editStateModal.blade.php ENDPATH**/ ?>