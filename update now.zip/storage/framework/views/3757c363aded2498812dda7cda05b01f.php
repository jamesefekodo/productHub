<!-- Mobile toggle button -->
<button class="btn btn-outline-primary d-md-none w-100 mb-2" data-bs-toggle="collapse" data-bs-target="#innerNavMenu"
    aria-expanded="false" aria-controls="innerNavMenu">
    <i class="feather-menu me-1"></i> <?php echo e(t('app.payment.paymentSettings')); ?>

</button>

<!-- Collapsible inner nav -->
<div id="innerNavMenu" class="collapse d-md-block">
    <div class="inner-nav">
        <h6 class="inner-nav-title text-center"><?php echo e(t('app.payment.paymentSettings')); ?></h6>

        <div class="inner-nav-list">
            <a href="<?php echo e(route('paymentMethods')); ?>"
                class="inner-nav-item <?php echo e(Str::startsWith(request()->path(), 'admin/payment/setting/payment_methods') ? 'active' : ''); ?>">
                <i data-feather="credit-card"></i>
                <?php echo e(t('app.payment.paymentMethods')); ?>

            </a>

            <a href="<?php echo e(route('bankAccounts')); ?>"
                class="inner-nav-item <?php echo e(Str::startsWith(request()->path(), 'admin/payment/setting/bank_accounts') ? 'active' : ''); ?>">
                <i data-feather="credit-card"></i>
                <?php echo e(t('app.payment.bankAccounts')); ?>

            </a>

            <a href="<?php echo e(route('taxes')); ?>"
                class="inner-nav-item <?php echo e(Str::startsWith(request()->path(), 'admin/payment/setting/taxes') ? 'active' : ''); ?>">
                <i data-feather="percent"></i>
                <?php echo e(t('app.payment.taxes')); ?>

            </a>

            <a href="<?php echo e(route('discounts')); ?>"
                class="inner-nav-item <?php echo e(Str::startsWith(request()->path(), 'admin/payment/setting/discounts') ? 'active' : ''); ?>">
                <i data-feather="tag"></i>
                <?php echo e(t('app.payment.discounts')); ?>

            </a>
        </div>
    </div>
</div>
<?php /**PATH /home/transcend/laravelApps/producthub/resources/views/users/admin/payments/settings/paymentMethods/include/inner_nav.blade.php ENDPATH**/ ?>