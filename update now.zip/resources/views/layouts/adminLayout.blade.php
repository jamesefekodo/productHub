<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="keyword" content="" />
    <meta name="author" content="flexilecode" />
    <!--! The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags !-->

    <!--! BEGIN: Favicon-->
    <link rel="icon" type="image/x-icon" href="{{ systemLogo() }}">
    <!--! END: Favicon-->
    <!--! BEGIN: Bootstrap CSS-->
    <link rel="stylesheet" type="text/css" href="{{ asset('templates/duraluxAdmin/css/bootstrap.min.css') }}" />
    <!--! END: Bootstrap CSS-->
    <!--! BEGIN: Vendors CSS-->
    <link rel="stylesheet" type="text/css" href="{{ asset('templates/duraluxAdmin/vendors/css/vendors.min.css') }}" />
    <link rel="stylesheet" type="text/css"
        href="{{ asset('templates/duraluxAdmin/vendors/css/daterangepicker.min.css') }}" />
    <!--! END: Vendors CSS-->
    {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" /> --}}
    <!-- Add this in your <head> -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <!--! BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="{{ asset('templates/duraluxAdmin/css/theme.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('templates/duraluxAdmin/css/myCustom.css') }}" />

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>






    <!--! END: Custom CSS-->
    <!--! HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries !-->
    <!--! WARNING: Respond.js doesn"t work if you view the page via file: !-->
    <!--[if lt IE 9]>
   <script src="https:oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
   <script src="https:oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

    {{-- Summer Note JS --}}
    {{-- <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet"> --}}
    {{-- <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script> --}}

    <!-- Toastr CSS and JS -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/tinymce@6/tinymce.min.js"></script>



    <title>
        @yield('title') | {{ config('app.name') }}
    </title>

    @yield('style')

</head>

<body>
    <!--! ================================================================ !-->
    <!--! [Start] Navigation Manu !-->
    <!--! ================================================================ !-->
    @include('layouts/include/adminMenu')

    <!--! ================================================================ !-->
    <!--! [End]  Navigation Manu !-->
    <!--! ================================================================ !-->
    <!--! ================================================================ !-->
    <!--! [Start] Header !-->
    <!--! ================================================================ !-->
    <header class="nxl-header">
        <div class="header-wrapper">
            <!--! [Start] Header Left !-->
            <div class="header-left d-flex align-items-center gap-4">
                <!--! [Start] nxl-head-mobile-toggler !-->
                <a href="javascript:void(0);" class="nxl-head-mobile-toggler" id="mobile-collapse">
                    <div class="hamburger hamburger--arrowturn">
                        <div class="hamburger-box">
                            <div class="hamburger-inner"></div>
                        </div>
                    </div>
                </a>
                <!--! [Start] nxl-head-mobile-toggler !-->
                <!--! [Start] nxl-navigation-toggle !-->
                <div class="nxl-navigation-toggle">
                    <a href="javascript:void(0);" id="menu-mini-button">
                        <i class="feather-align-left"></i>
                    </a>
                    <a href="javascript:void(0);" id="menu-expend-button" style="display: none">
                        <i class="feather-arrow-right"></i>
                    </a>
                </div>
                <!--! [End] nxl-navigation-toggle !-->
                <!--! [Start] nxl-lavel-mega-menu-toggle !-->
                <div class="nxl-lavel-mega-menu-toggle d-flex d-lg-none">
                    <a href="javascript:void(0);" id="nxl-lavel-mega-menu-open">
                        <i class="feather-align-left"></i>
                    </a>
                </div>
                <!--! [End] nxl-lavel-mega-menu-toggle !-->
                <!--! [Start] nxl-lavel-mega-menu !-->
                <div class="nxl-drp-link nxl-lavel-mega-menu">
                    <div class="nxl-lavel-mega-menu-toggle d-flex d-lg-none">
                        <a href="javascript:void(0)" id="nxl-lavel-mega-menu-hide">
                            <i class="feather-arrow-left me-2"></i>
                            <span>Back</span>
                        </a>
                    </div>
                    <!--! [Start] nxl-lavel-mega-menu-wrapper !-->
                    <div class="nxl-lavel-mega-menu-wrapper d-flex gap-3">
                        <!--! [Start] nxl-lavel-menu !-->
                        <div class="dropdown nxl-h-item nxl-lavel-menu">
                            <a href="javascript:void(0);" class="avatar-text avatar-md bg-primary text-white"
                                data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <i class="feather-plus"></i>
                            </a>
                            <div class="dropdown-menu nxl-h-dropdown">
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="feather-send"></i>
                                            <span>Applications</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        <a href="apps-chat.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Chat</span>
                                        </a>
                                        <a href="apps-email.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Email</span>
                                        </a>
                                        <a href="apps-tasks.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Tasks</span>
                                        </a>
                                        <a href="apps-notes.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Notes</span>
                                        </a>
                                        <a href="apps-storage.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Storage</span>
                                        </a>
                                        <a href="apps-calendar.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Calendar</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown-divider"></div>
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="feather-cast"></i>
                                            <span>Reports</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        <a href="reports-sales.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Sales Report</span>
                                        </a>
                                        <a href="reports-leads.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Leads Report</span>
                                        </a>
                                        <a href="reports-project.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Project Report</span>
                                        </a>
                                        <a href="reports-timesheets.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Timesheets Report</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="feather-at-sign"></i>
                                            <span>Proposal</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        <a href="proposal.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Proposal</span>
                                        </a>
                                        <a href="proposal-view.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Proposal View</span>
                                        </a>
                                        <a href="proposal-edit.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Proposal Edit</span>
                                        </a>
                                        <a href="proposal-create.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Proposal Create</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="feather-dollar-sign"></i>
                                            <span>Payment</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        <a href="payment.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Payment</span>
                                        </a>
                                        <a href="invoice-view.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Invoice View</span>
                                        </a>
                                        <a href="invoice-create.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Invoice Create</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="feather-users"></i>
                                            <span>Customers</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        <a href="customers.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Customers</span>
                                        </a>
                                        <a href="customers-view.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Customers View</span>
                                        </a>
                                        <a href="customers-create.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Customers Create</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="feather-alert-circle"></i>
                                            <span>Leads</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        <a href="leads.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Leads</span>
                                        </a>
                                        <a href="leads-view.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Leads View</span>
                                        </a>
                                        <a href="leads-create.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Leads Create</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="feather-briefcase"></i>
                                            <span>Projects</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        <a href="projects.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Projects</span>
                                        </a>
                                        <a href="projects-view.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Projects View</span>
                                        </a>
                                        <a href="projects-create.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Projects Create</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="feather-layout"></i>
                                            <span>Widgets</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        <a href="widgets-lists.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Lists</span>
                                        </a>
                                        <a href="widgets-tables.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Tables</span>
                                        </a>
                                        <a href="widgets-charts.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Charts</span>
                                        </a>
                                        <a href="widgets-statistics.html" class="dropdown-item">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Statistics</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="feather-power"></i>
                                            <span>Authentication</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        <div class="dropdown nxl-level-menu">
                                            <a href="javascript:void(0);" class="dropdown-item">
                                                <span class="hstack">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Login</span>
                                                </span>
                                                <i class="feather-chevron-right ms-auto me-0"></i>
                                            </a>
                                            <div class="dropdown-menu nxl-h-dropdown">
                                                <a href="./auth-login-cover.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Cover</span>
                                                </a>
                                                <a href="./auth-login-minimal.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Minimal</span>
                                                </a>
                                                <a href="./auth-login-creative.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Creative</span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="dropdown nxl-level-menu">
                                            <a href="javascript:void(0);" class="dropdown-item">
                                                <span class="hstack">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Register</span>
                                                </span>
                                                <i class="feather-chevron-right ms-auto me-0"></i>
                                            </a>
                                            <div class="dropdown-menu nxl-h-dropdown">
                                                <a href="./auth-register-cover.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Cover</span>
                                                </a>
                                                <a href="./auth-register-minimal.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Minimal</span>
                                                </a>
                                                <a href="./auth-register-creative.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Creative</span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="dropdown nxl-level-menu">
                                            <a href="javascript:void(0);" class="dropdown-item">
                                                <span class="hstack">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Error-404</span>
                                                </span>
                                                <i class="feather-chevron-right ms-auto me-0"></i>
                                            </a>
                                            <div class="dropdown-menu nxl-h-dropdown">
                                                <a href="./auth-404-cover.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Cover</span>
                                                </a>
                                                <a href="./auth-404-minimal.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Minimal</span>
                                                </a>
                                                <a href="./auth-404-creative.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Creative</span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="dropdown nxl-level-menu">
                                            <a href="javascript:void(0);" class="dropdown-item">
                                                <span class="hstack">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Reset Pass</span>
                                                </span>
                                                <i class="feather-chevron-right ms-auto me-0"></i>
                                            </a>
                                            <div class="dropdown-menu nxl-h-dropdown">
                                                <a href="./auth-reset-cover.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Cover</span>
                                                </a>
                                                <a href="./auth-reset-minimal.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Minimal</span>
                                                </a>
                                                <a href="./auth-reset-creative.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Creative</span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="dropdown nxl-level-menu">
                                            <a href="javascript:void(0);" class="dropdown-item">
                                                <span class="hstack">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Verify OTP</span>
                                                </span>
                                                <i class="feather-chevron-right ms-auto me-0"></i>
                                            </a>
                                            <div class="dropdown-menu nxl-h-dropdown">
                                                <a href="./auth-verify-cover.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Cover</span>
                                                </a>
                                                <a href="./auth-verify-minimal.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Minimal</span>
                                                </a>
                                                <a href="./auth-verify-creative.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Creative</span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="dropdown nxl-level-menu">
                                            <a href="javascript:void(0);" class="dropdown-item">
                                                <span class="hstack">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Maintenance</span>
                                                </span>
                                                <i class="feather-chevron-right ms-auto me-0"></i>
                                            </a>
                                            <div class="dropdown-menu nxl-h-dropdown">
                                                <a href="./auth-maintenance-cover.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Cover</span>
                                                </a>
                                                <a href="./auth-maintenance-minimal.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Minimal</span>
                                                </a>
                                                <a href="./auth-maintenance-creative.html" class="dropdown-item">
                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                    <span>Creative</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0);" class="dropdown-item">
                                    <i class="feather-plus"></i>
                                    <span>Add New Items</span>
                                </a>
                            </div>
                        </div>
                        <!--! [End] nxl-lavel-menu !-->
                        <!--! [Start] nxl-h-item nxl-mega-menu !-->
                        <div class="dropdown nxl-h-item nxl-mega-menu">
                            <a href="javascript:void(0);" class="btn btn-light-brand" data-bs-toggle="dropdown"
                                data-bs-auto-close="outside"> Mega Menu </a>
                            <div class="dropdown-menu nxl-h-dropdown" id="mega-menu-dropdown">
                                <div class="d-lg-flex align-items-start">
                                    <!--! [Start] nxl-mega-menu-tabs !-->
                                    <div class="nav flex-column nxl-mega-menu-tabs" role="tablist"
                                        aria-orientation="vertical">
                                        <button class="nav-link active nxl-mega-menu-sm" data-bs-toggle="pill"
                                            data-bs-target="#v-pills-general" type="button" role="tab">
                                            <span class="menu-icon">
                                                <i class="feather-airplay"></i>
                                            </span>
                                            <span class="menu-title">General</span>
                                            <span class="menu-arrow">
                                                <i class="feather-chevron-right"></i>
                                            </span>
                                        </button>
                                        <button class="nav-link nxl-mega-menu-md" data-bs-toggle="pill"
                                            data-bs-target="#v-pills-applications" type="button" role="tab">
                                            <span class="menu-icon">
                                                <i class="feather-send"></i>
                                            </span>
                                            <span class="menu-title">Applications</span>
                                            <span class="menu-arrow">
                                                <i class="feather-chevron-right"></i>
                                            </span>
                                        </button>
                                        <button class="nav-link nxl-mega-menu-lg" data-bs-toggle="pill"
                                            data-bs-target="#v-pills-integrations" type="button" role="tab">
                                            <span class="menu-icon">
                                                <i class="feather-link-2"></i>
                                            </span>
                                            <span class="menu-title">Integrations</span>
                                            <span class="menu-arrow">
                                                <i class="feather-chevron-right"></i>
                                            </span>
                                        </button>
                                        <button class="nav-link nxl-mega-menu-xl" data-bs-toggle="pill"
                                            data-bs-target="#v-pills-components" type="button" role="tab">
                                            <span class="menu-icon">
                                                <i class="feather-layers"></i>
                                            </span>
                                            <span class="menu-title">Components</span>
                                            <span class="menu-arrow">
                                                <i class="feather-chevron-right"></i>
                                            </span>
                                        </button>
                                        <button class="nav-link nxl-mega-menu-xxl" data-bs-toggle="pill"
                                            data-bs-target="#v-pills-authentication" type="button" role="tab">
                                            <span class="menu-icon">
                                                <i class="feather-cpu"></i>
                                            </span>
                                            <span class="menu-title">Authentication</span>
                                            <span class="menu-arrow">
                                                <i class="feather-chevron-right"></i>
                                            </span>
                                        </button>
                                        <button class="nav-link nxl-mega-menu-full" data-bs-toggle="pill"
                                            data-bs-target="#v-pills-miscellaneous" type="button" role="tab">
                                            <span class="menu-icon">
                                                <i class="feather-bluetooth"></i>
                                            </span>
                                            <span class="menu-title">Miscellaneous</span>
                                            <span class="menu-arrow">
                                                <i class="feather-chevron-right"></i>
                                            </span>
                                        </button>
                                    </div>
                                    <!--! [End] nxl-mega-menu-tabs !-->
                                    <!--! [Start] nxl-mega-menu-tabs-content !-->
                                    <div class="tab-content nxl-mega-menu-tabs-content">
                                        <!--! [Start] v-pills-general !-->
                                        <div class="tab-pane fade show active" id="v-pills-general" role="tabpanel">
                                            <div class="mb-4 rounded-3 border">
                                                <img src="{{ asset('templates/duraluxAdmin/images/banner/mockup.png') }}"
                                                    alt="" class="img-fluid rounded-3" />
                                            </div>
                                            <h6 class="fw-bolder">Duralux - Admin Dashboard UiKit</h6>
                                            <p class="fs-12 fw-normal text-muted text-truncate-3-line">Get started
                                                Duralux with Duralux up and running. Duralux bootstrap template docs
                                                helps you to get started with simple html codes.</p>
                                            <a href="javascript:void(0);" class="fs-13 fw-bold text-primary">Get
                                                Started &rarr;</a>
                                        </div>
                                        <!--! [End] v-pills-general !-->
                                        <!--! [Start] v-pills-applications !-->
                                        <div class="tab-pane fade" id="v-pills-applications" role="tabpanel">
                                            <div class="row g-4">
                                                <div class="col-lg-6">
                                                    <h6 class="dropdown-item-title">Applications</h6>
                                                    <a href="apps-chat.html" class="dropdown-item">
                                                        <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                        <span>Chat</span>
                                                    </a>
                                                    <a href="apps-email.html" class="dropdown-item">
                                                        <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                        <span>Email</span>
                                                    </a>
                                                    <a href="apps-tasks.html" class="dropdown-item">
                                                        <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                        <span>Tasks</span>
                                                    </a>
                                                    <a href="apps-notes.html" class="dropdown-item">
                                                        <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                        <span>Notes</span>
                                                    </a>
                                                    <a href="apps-storage.html" class="dropdown-item">
                                                        <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                        <span>Storage</span>
                                                    </a>
                                                    <a href="apps-calendar.html" class="dropdown-item">
                                                        <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                        <span>Calendar</span>
                                                    </a>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="nxl-mega-menu-image">
                                                        <img src="{{ asset('templates/duraluxAdmin/images/general/full-avatar.png') }}"
                                                            alt="" class="img-fluid full-user-avtar" />
                                                    </div>
                                                </div>
                                            </div>
                                            <hr class="border-top-dashed" />
                                            <div class="d-lg-flex align-items-center justify-content-between">
                                                <div>
                                                    <h6 class="menu-item-heading text-truncate-1-line">Need more
                                                        application?</h6>
                                                    <p class="fs-12 text-muted mb-0 text-truncate-3-line">We are ready
                                                        to build custom applications.</p>
                                                </div>
                                                <div class="mt-2 mt-lg-0">
                                                    <a href="mailto:flexilecode@gmail.com"
                                                        class="fs-13 fw-bold text-primary">Contact Us &rarr;</a>
                                                </div>
                                            </div>
                                        </div>
                                        <!--! [End] v-pills-applications !-->
                                        <!--! [Start] v-pills-integrations !-->
                                        <div class="tab-pane fade" id="v-pills-integrations" role="tabpanel">
                                            <div class="row g-lg-4 nxl-mega-menu-integrations">
                                                <div
                                                    class="col-lg-12 d-lg-flex align-items-center justify-content-between mb-4 mb-lg-0">
                                                    <div>
                                                        <h6 class="fw-bolder text-dark">Integrations</h6>
                                                        <p class="fs-12 text-muted mb-0">Connect amazing apps on your
                                                            bucket.</p>
                                                    </div>
                                                    <div class="mt-2 mt-lg-0">
                                                        <a href="javascript:void(0);" class="fs-13 text-primary">Add
                                                            New &rarr;</a>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/app-store.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">App Store</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/spotify.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Spotify</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/figma.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Figma</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/shopify.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Shopify</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/paypal.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Paypal</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                </div>
                                                <div class="col-lg-4">
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/gmail.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Gmail</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/dropbox.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Dropbox</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/google-drive.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Google Drive</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/github.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Github</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/gitlab.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Gitlab</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                </div>
                                                <div class="col-lg-4">
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/facebook.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Facebook</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/pinterest.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Pinterest</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/instagram.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Instagram</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/twitter.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Twitter</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <div class="menu-item-icon">
                                                            <img src="{{ asset('templates/duraluxAdmin/images/brand/youtube.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </div>
                                                        <div class="menu-item-title">Youtube</div>
                                                        <div class="menu-item-arrow">
                                                            <i class="feather-arrow-right"></i>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                            <hr class="border-top-dashed" />
                                            <p class="fs-13 text-muted mb-0">Need help? Contact our <a
                                                    href="javascript:void(0);" class="fst-italic">support center</a>
                                            </p>
                                        </div>
                                        <!--! [End] v-pills-integrations !-->
                                        <!--! [Start] v-pills-components !-->
                                        <div class="tab-pane fade" id="v-pills-components" role="tabpanel">
                                            <div class="row g-4 align-items-center">
                                                <div class="col-xl-8">
                                                    <div class="row g-4">
                                                        <div class="col-lg-4">
                                                            <h6 class="dropdown-item-title">Navigation</h6>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">CRM</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Analytics</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Sales</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Leads</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Projects</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Timesheets</a>
                                                        </div>
                                                        <div class="col-lg-4">
                                                            <h6 class="dropdown-item-title">Pages</h6>
                                                            <a href="javascript:void(0);" class="dropdown-item">Leads
                                                            </a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Payments</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Projects</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Proposals</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Customers</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Documentations</a>
                                                        </div>
                                                        <div class="col-lg-4">
                                                            <h6 class="dropdown-item-title">Authentication</h6>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Login</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Regiser</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Error-404</a>
                                                            <a href="javascript:void(0);" class="dropdown-item">Reset
                                                                Pass</a>
                                                            <a href="javascript:void(0);" class="dropdown-item">Verify
                                                                OTP</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Maintenance</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-4">
                                                    <div class="nxl-mega-menu-image">
                                                        <img src="{{ asset('templates/duraluxAdmin/images/banner/1.jpg') }}"
                                                            alt="" class="img-fluid" />
                                                    </div>
                                                    <div class="mt-4">
                                                        <a href="mailto:flexilecode@gmail.com"
                                                            class="fs-13 fw-bold">View all resources on Duralux
                                                            &rarr;</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--! [End] v-pills-components !-->
                                        <!--! [Start] v-pills-authentication !-->
                                        <div class="tab-pane fade" id="v-pills-authentication" role="tabpanel">
                                            <div class="row g-4 align-items-center nxl-mega-menu-authentication">
                                                <div class="col-xl-8">
                                                    <div class="row g-4">
                                                        <div class="col-lg-4">
                                                            <h6 class="dropdown-item-title">Cover</h6>
                                                            <a href="./auth-login-cover.html" class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Login</span>
                                                            </a>
                                                            <a href="./auth-register-cover.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Register</span>
                                                            </a>
                                                            <a href="./auth-404-cover.html" class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Error-404</span>
                                                            </a>
                                                            <a href="./auth-reset-cover.html" class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Reset Pass</span>
                                                            </a>
                                                            <a href="./auth-verify-cover.html" class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Verify OTP</span>
                                                            </a>
                                                            <a href="./auth-maintenance-cover.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Maintenance</span>
                                                            </a>
                                                        </div>
                                                        <div class="col-lg-4">
                                                            <h6 class="dropdown-item-title">Minimal</h6>
                                                            <a href="./auth-login-minimal.html" class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Login</span>
                                                            </a>
                                                            <a href="./auth-register-minimal.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Register</span>
                                                            </a>
                                                            <a href="./auth-404-minimal.html" class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Error-404</span>
                                                            </a>
                                                            <a href="./auth-reset-minimal.html" class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Reset Pass</span>
                                                            </a>
                                                            <a href="./auth-verify-minimal.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Verify OTP</span>
                                                            </a>
                                                            <a href="./auth-maintenance-minimal.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Maintenance</span>
                                                            </a>
                                                        </div>
                                                        <div class="col-lg-4">
                                                            <h6 class="dropdown-item-title">Creative</h6>
                                                            <a href="./auth-login-creative.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Login</span>
                                                            </a>
                                                            <a href="./auth-register-creative.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Register</span>
                                                            </a>
                                                            <a href="./auth-404-creative.html" class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Error-404</span>
                                                            </a>
                                                            <a href="./auth-reset-creative.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Reset Pass</span>
                                                            </a>
                                                            <a href="./auth-verify-creative.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Verify OTP</span>
                                                            </a>
                                                            <a href="./auth-maintenance-creative.html"
                                                                class="dropdown-item">
                                                                <i
                                                                    class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                <span>Maintenance</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xl-4">
                                                    <div id="carouselResourcesCaptions" class="carousel slide"
                                                        data-bs-ride="carousel">
                                                        <div class="carousel-indicators">
                                                            <button type="button"
                                                                data-bs-target="#carouselResourcesCaptions"
                                                                data-bs-slide-to="0" class="active"
                                                                aria-current="true"></button>
                                                            <button type="button"
                                                                data-bs-target="#carouselResourcesCaptions"
                                                                data-bs-slide-to="1"></button>
                                                            <button type="button"
                                                                data-bs-target="#carouselResourcesCaptions"
                                                                data-bs-slide-to="2"></button>
                                                            <button type="button"
                                                                data-bs-target="#carouselResourcesCaptions"
                                                                data-bs-slide-to="3"></button>
                                                            <button type="button"
                                                                data-bs-target="#carouselResourcesCaptions"
                                                                data-bs-slide-to="4"></button>
                                                            <button type="button"
                                                                data-bs-target="#carouselResourcesCaptions"
                                                                data-bs-slide-to="5"></button>
                                                        </div>
                                                        <div class="carousel-inner rounded-3">
                                                            <div class="carousel-item active">
                                                                <div class="nxl-mega-menu-image">
                                                                    <img src="{{ asset('templates/duraluxAdmin/images/banner/6.jpg') }}"
                                                                        alt=""
                                                                        class="img-fluid d-block w-100" />
                                                                </div>
                                                                <div class="carousel-caption">
                                                                    <h5
                                                                        class="carousel-caption-title text-truncate-1-line">
                                                                        Shopify eCommerce Store</h5>
                                                                    <p class="carousel-caption-desc">Some
                                                                        representative placeholder content for the first
                                                                        slide.</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <div class="nxl-mega-menu-image">
                                                                    <img src="{{ asset('templates/duraluxAdmin/images/banner/5.jpg') }}"
                                                                        alt=""
                                                                        class="img-fluid d-block w-100" />
                                                                </div>
                                                                <div class="carousel-caption">
                                                                    <h5
                                                                        class="carousel-caption-title text-truncate-1-line">
                                                                        iOS Apps Development</h5>
                                                                    <p class="carousel-caption-desc">Some
                                                                        representative placeholder content for the
                                                                        second slide.</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <div class="nxl-mega-menu-image">
                                                                    <img src="{{ asset('templates/duraluxAdmin/images/banner/4.jpg') }}"
                                                                        alt=""
                                                                        class="img-fluid d-block w-100" />
                                                                </div>
                                                                <div class="carousel-caption">
                                                                    <h5
                                                                        class="carousel-caption-title text-truncate-1-line">
                                                                        Figma Dashboard Design</h5>
                                                                    <p class="carousel-caption-desc">Some
                                                                        representative placeholder content for the third
                                                                        slide.</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <div class="nxl-mega-menu-image">
                                                                    <img src="{{ asset('templates/duraluxAdmin/images/banner/3.jpg') }}"
                                                                        alt=""
                                                                        class="img-fluid d-block w-100" />
                                                                </div>
                                                                <div class="carousel-caption">
                                                                    <h5
                                                                        class="carousel-caption-title text-truncate-1-line">
                                                                        React Dashboard Design</h5>
                                                                    <p class="carousel-caption-desc">Some
                                                                        representative placeholder content for the third
                                                                        slide.</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <div class="nxl-mega-menu-image">
                                                                    <img src="{{ asset('templates/duraluxAdmin/images/banner/2.jpg') }}"
                                                                        alt=""
                                                                        class="img-fluid d-block w-100" />
                                                                </div>
                                                                <div class="carousel-caption">
                                                                    <h5
                                                                        class="carousel-caption-title text-truncate-1-line">
                                                                        Standup Team Meeting</h5>
                                                                    <p class="carousel-caption-desc">Some
                                                                        representative placeholder content for the third
                                                                        slide.</p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <div class="nxl-mega-menu-image">
                                                                    <img src="{{ asset('templates/duraluxAdmin/images/banner/1.jpg') }}"
                                                                        alt=""
                                                                        class="img-fluid d-block w-100" />
                                                                </div>
                                                                <div class="carousel-caption">
                                                                    <h5
                                                                        class="carousel-caption-title text-truncate-1-line">
                                                                        Zoom Team Meeting</h5>
                                                                    <p class="carousel-caption-desc">Some
                                                                        representative placeholder content for the third
                                                                        slide.</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <button class="carousel-control-prev" type="button"
                                                            data-bs-target="#carouselResourcesCaptions"
                                                            data-bs-slide="prev">
                                                            <span class="carousel-control-prev-icon"
                                                                aria-hidden="true"></span>
                                                            <span class="visually-hidden">Previous</span>
                                                        </button>
                                                        <button class="carousel-control-next" type="button"
                                                            data-bs-target="#carouselResourcesCaptions"
                                                            data-bs-slide="next">
                                                            <span class="carousel-control-next-icon"
                                                                aria-hidden="true"></span>
                                                            <span class="visually-hidden">Next</span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--! [End] v-pills-authentication !-->
                                        <!--! [Start] v-pills-miscellaneous !-->
                                        <div class="tab-pane fade nxl-mega-menu-miscellaneous"
                                            id="v-pills-miscellaneous" role="tabpanel">
                                            <!-- Nav tabs -->
                                            <ul class="nav nav-tabs flex-column flex-lg-row nxl-mega-menu-miscellaneous-tabs"
                                                role="tablist">
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link active" data-bs-toggle="tab"
                                                        data-bs-target="#v-pills-projects" type="button"
                                                        role="tab">
                                                        <span class="menu-icon">
                                                            <i class="feather-cast"></i>
                                                        </span>
                                                        <span class="menu-title">Projects</span>
                                                    </button>
                                                </li>
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link" data-bs-toggle="tab"
                                                        data-bs-target="#v-pills-services" type="button"
                                                        role="tab">
                                                        <span class="menu-icon">
                                                            <i class="feather-check-square"></i>
                                                        </span>
                                                        <span class="menu-title">Services</span>
                                                    </button>
                                                </li>
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link" data-bs-toggle="tab"
                                                        data-bs-target="#v-pills-features" type="button"
                                                        role="tab">
                                                        <span class="menu-icon">
                                                            <i class="feather-airplay"></i>
                                                        </span>
                                                        <span class="menu-title">Features</span>
                                                    </button>
                                                </li>
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link" data-bs-toggle="tab"
                                                        data-bs-target="#v-pills-blogs" type="button"
                                                        role="tab">
                                                        <span class="menu-icon">
                                                            <i class="feather-bold"></i>
                                                        </span>
                                                        <span class="menu-title">Blogs</span>
                                                    </button>
                                                </li>
                                            </ul>
                                            <!-- Tab panes -->
                                            <div class="tab-content nxl-mega-menu-miscellaneous-content">
                                                <div class="tab-pane fade active show" id="v-pills-projects"
                                                    role="tabpanel">
                                                    <div class="row g-4">
                                                        <div class="col-xxl-2 d-lg-none d-xxl-block">
                                                            <h6 class="dropdown-item-title">Categories</h6>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Support</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Services</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Applicatios</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">eCommerce</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Development</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Miscellaneous</a>
                                                        </div>
                                                        <div class="col-xxl-10">
                                                            <div class="row g-4">
                                                                <div class="col-xl-6">
                                                                    <div class="d-lg-flex align-items-center gap-3">
                                                                        <div class="wd-150 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/1.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3" />
                                                                        </div>
                                                                        <div class="mt-3 mt-lg-0 ms-lg-3 item-text">
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Shopify eCommerce Store</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet, consectetur
                                                                                adipisicing elit. Sint nam ullam iure
                                                                                eum sed rerum libero quis doloremque
                                                                                maiores veritatis?</p>
                                                                            <div class="hstack gap-2 mt-3">
                                                                                <div class="avatar-image avatar-sm">
                                                                                    <img src="{{ asset('templates/duraluxAdmin/images/avatar/1.png') }}"
                                                                                        alt=""
                                                                                        class="img-fluid" />
                                                                                </div>
                                                                                <a href="javascript:void(0);"
                                                                                    class="fs-12">Alexandra Della</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xl-6">
                                                                    <div class="d-lg-flex align-items-center gap-3">
                                                                        <div class="wd-150 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/2.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3" />
                                                                        </div>
                                                                        <div class="mt-3 mt-lg-0 ms-lg-3 item-text">
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    iOS Apps Development</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet, consectetur
                                                                                adipisicing elit. Sint nam ullam iure
                                                                                eum sed rerum libero quis doloremque
                                                                                maiores veritatis?</p>
                                                                            <div class="hstack gap-2 mt-3">
                                                                                <div class="avatar-image avatar-sm">
                                                                                    <img src="{{ asset('templates/duraluxAdmin/images/avatar/2.png') }}"
                                                                                        alt=""
                                                                                        class="img-fluid" />
                                                                                </div>
                                                                                <a href="javascript:void(0);"
                                                                                    class="fs-12">Green Cute</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xl-6">
                                                                    <div class="d-lg-flex align-items-center gap-3">
                                                                        <div class="wd-150 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/3.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3" />
                                                                        </div>
                                                                        <div class="mt-3 mt-lg-0 ms-lg-3 item-text">
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Figma Dashboard Design</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet, consectetur
                                                                                adipisicing elit. Sint nam ullam iure
                                                                                eum sed rerum libero quis doloremque
                                                                                maiores veritatis?</p>
                                                                            <div class="hstack gap-2 mt-3">
                                                                                <div class="avatar-image avatar-sm">
                                                                                    <img src="{{ asset('templates/duraluxAdmin/images/avatar/3.png') }}"
                                                                                        alt=""
                                                                                        class="img-fluid" />
                                                                                </div>
                                                                                <a href="javascript:void(0);"
                                                                                    class="fs-12">Malanie Hanvey</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xl-6">
                                                                    <div class="d-lg-flex align-items-center gap-3">
                                                                        <div class="wd-150 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/4.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3" />
                                                                        </div>
                                                                        <div class="mt-3 mt-lg-0 ms-lg-3 item-text">
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    React Dashboard Design</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet, consectetur
                                                                                adipisicing elit. Sint nam ullam iure
                                                                                eum sed rerum libero quis doloremque
                                                                                maiores veritatis?</p>
                                                                            <div class="hstack gap-2 mt-3">
                                                                                <div class="avatar-image avatar-sm">
                                                                                    <img src="{{ asset('templates/duraluxAdmin/images/avatar/4.png') }}"
                                                                                        alt=""
                                                                                        class="img-fluid" />
                                                                                </div>
                                                                                <a href="javascript:void(0);"
                                                                                    class="fs-12">Kenneth Hune</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-services" role="tabpanel">
                                                    <div class="row g-4 nxl-mega-menu-miscellaneous-services">
                                                        <div class="col-xl-8">
                                                            <div class="row g-4">
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg rounded bg-primary text-white">
                                                                            <i class="feather-bar-chart-2 mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Analytics Services</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg rounded bg-danger text-white">
                                                                            <i class="feather-feather mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Content Writing</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg rounded bg-warning text-white">
                                                                            <i class="feather-bell mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    SEO (Search Engine Optimization)
                                                                                </h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg rounded bg-success text-white">
                                                                            <i class="feather-shield mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Security Services</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg rounded bg-teal text-white">
                                                                            <i
                                                                                class="feather-shopping-cart mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    eCommerce Services</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg rounded bg-dark text-white">
                                                                            <i class="feather-life-buoy mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Support Services</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-12">
                                                                    <div
                                                                        class="p-3 bg-soft-dark text-dark rounded d-lg-flex align-items-center justify-content-between">
                                                                        <div class="fs-13">
                                                                            <i class="feather-star me-2"></i>
                                                                            <span>View all services on Duralux.</span>
                                                                        </div>
                                                                        <div class="mt-2 mt-lg-0">
                                                                            <a href="javascript:void(0);"
                                                                                class="fs-13 text-primary">Learn More
                                                                                &rarr;</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-xl-4">
                                                            <div id="carouselServicesCaptions" class="carousel slide"
                                                                data-bs-ride="carousel">
                                                                <div class="carousel-indicators">
                                                                    <button type="button"
                                                                        data-bs-target="#carouselServicesCaptions"
                                                                        data-bs-slide-to="0" class="active"
                                                                        aria-current="true"></button>
                                                                    <button type="button"
                                                                        data-bs-target="#carouselServicesCaptions"
                                                                        data-bs-slide-to="1"></button>
                                                                    <button type="button"
                                                                        data-bs-target="#carouselServicesCaptions"
                                                                        data-bs-slide-to="2"></button>
                                                                    <button type="button"
                                                                        data-bs-target="#carouselServicesCaptions"
                                                                        data-bs-slide-to="3"></button>
                                                                    <button type="button"
                                                                        data-bs-target="#carouselServicesCaptions"
                                                                        data-bs-slide-to="4"></button>
                                                                    <button type="button"
                                                                        data-bs-target="#carouselServicesCaptions"
                                                                        data-bs-slide-to="5"></button>
                                                                </div>
                                                                <div class="carousel-inner rounded-3">
                                                                    <div class="carousel-item active">
                                                                        <div class="nxl-mega-menu-image">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/6.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid d-block w-100" />
                                                                        </div>
                                                                        <div class="carousel-caption">
                                                                            <h5
                                                                                class="carousel-caption-title text-truncate-1-line">
                                                                                Shopify eCommerce Store</h5>
                                                                            <p class="carousel-caption-desc">Some
                                                                                representative placeholder content for
                                                                                the first slide.</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <div class="nxl-mega-menu-image">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/5.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid d-block w-100" />
                                                                        </div>
                                                                        <div class="carousel-caption">
                                                                            <h5
                                                                                class="carousel-caption-title text-truncate-1-line">
                                                                                iOS Apps Development</h5>
                                                                            <p class="carousel-caption-desc">Some
                                                                                representative placeholder content for
                                                                                the second slide.</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <div class="nxl-mega-menu-image">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/4.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid d-block w-100" />
                                                                        </div>
                                                                        <div class="carousel-caption">
                                                                            <h5
                                                                                class="carousel-caption-title text-truncate-1-line">
                                                                                Figma Dashboard Design</h5>
                                                                            <p class="carousel-caption-desc">Some
                                                                                representative placeholder content for
                                                                                the third slide.</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <div class="nxl-mega-menu-image">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/3.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid d-block w-100" />
                                                                        </div>
                                                                        <div class="carousel-caption">
                                                                            <h5
                                                                                class="carousel-caption-title text-truncate-1-line">
                                                                                React Dashboard Design</h5>
                                                                            <p class="carousel-caption-desc">Some
                                                                                representative placeholder content for
                                                                                the third slide.</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <div class="nxl-mega-menu-image">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/2.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid d-block w-100" />
                                                                        </div>
                                                                        <div class="carousel-caption">
                                                                            <h5
                                                                                class="carousel-caption-title text-truncate-1-line">
                                                                                Standup Team Meeting</h5>
                                                                            <p class="carousel-caption-desc">Some
                                                                                representative placeholder content for
                                                                                the third slide.</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <div class="nxl-mega-menu-image">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/1.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid d-block w-100" />
                                                                        </div>
                                                                        <div class="carousel-caption">
                                                                            <h5
                                                                                class="carousel-caption-title text-truncate-1-line">
                                                                                Zoom Team Meeting</h5>
                                                                            <p class="carousel-caption-desc">Some
                                                                                representative placeholder content for
                                                                                the third slide.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <button class="carousel-control-prev" type="button"
                                                                    data-bs-target="#carouselServicesCaptions"
                                                                    data-bs-slide="prev">
                                                                    <span class="carousel-control-prev-icon"
                                                                        aria-hidden="true"></span>
                                                                    <span class="visually-hidden">Previous</span>
                                                                </button>
                                                                <button class="carousel-control-next" type="button"
                                                                    data-bs-target="#carouselServicesCaptions"
                                                                    data-bs-slide="next">
                                                                    <span class="carousel-control-next-icon"
                                                                        aria-hidden="true"></span>
                                                                    <span class="visually-hidden">Next</span>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-features" role="tabpanel">
                                                    <div class="row g-4 nxl-mega-menu-miscellaneous-features">
                                                        <div class="col-xl-8">
                                                            <div class="row g-4">
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg bg-soft-primary text-primary border-soft-primary rounded">
                                                                            <i class="feather-bell mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Notifications</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg bg-soft-danger text-danger border-soft-danger rounded">
                                                                            <i
                                                                                class="feather-bar-chart-2 mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Analytics</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg bg-soft-success text-success border-soft-success rounded">
                                                                            <i class="feather-link-2 mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Ingetrations</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg bg-soft-indigo text-indigo border-soft-indigo rounded">
                                                                            <i class="feather-book mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Documentations</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg bg-soft-warning text-warning border-soft-warning rounded">
                                                                            <i class="feather-shield mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Security</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <div class="d-flex align-items-start gap-3">
                                                                        <div
                                                                            class="avatar-text avatar-lg bg-soft-teal text-teal border-soft-teal rounded">
                                                                            <i class="feather-life-buoy mx-auto"></i>
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Support</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum dolor sit amet consectetur
                                                                                adipisicing elit Unde numquam rem
                                                                                dignissimos. elit Unde numquam rem
                                                                                dignissimos.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-xxl-3 offset-xxl-1 col-xl-4">
                                                            <div class="nxl-mega-menu-image">
                                                                <img src="{{ asset('templates/duraluxAdmin/images/banner/1.jpg') }}"
                                                                    alt="" class="img-fluid" />
                                                            </div>
                                                            <div class="mt-4">
                                                                <a href="mailto:flexilecode@gmail.com"
                                                                    class="fs-13 fw-bold">View all features on Duralux
                                                                    &rarr;</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-blogs" role="tabpanel">
                                                    <div class="row g-4">
                                                        <div class="col-xxl-2 d-lg-none d-xxl-block">
                                                            <h6 class="dropdown-item-title">Categories</h6>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Support</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Services</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Applicatios</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">eCommerce</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Development</a>
                                                            <a href="javascript:void(0);"
                                                                class="dropdown-item">Miscellaneous</a>
                                                        </div>
                                                        <div class="col-xxl-10">
                                                            <div class="row g-4">
                                                                <div class="col-xxl-4 col-lg-6">
                                                                    <div class="d-flex align-items-center gap-3">
                                                                        <div class="wd-100 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/1.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3 border border-3" />
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Lorem ipsum dolor sit</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum, dolor sit amet consectetur
                                                                                adipisicing elit. Eius dolor quo commodi
                                                                                nisi animi error minus quia aliquam.</p>
                                                                            <span class="fs-11 text-gray-500">26
                                                                                March, 2023</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-4 col-lg-6">
                                                                    <div class="d-flex align-items-center gap-3">
                                                                        <div class="wd-100 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/2.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3 border border-3" />
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Lorem ipsum dolor sit</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum, dolor sit amet consectetur
                                                                                adipisicing elit. Eius dolor quo commodi
                                                                                nisi animi error minus quia aliquam.</p>
                                                                            <span class="fs-11 text-gray-500">26
                                                                                March, 2023</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-4 col-lg-6">
                                                                    <div class="d-flex align-items-center gap-3">
                                                                        <div class="wd-100 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/3.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3 border border-3" />
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Lorem ipsum dolor sit</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum, dolor sit amet consectetur
                                                                                adipisicing elit. Eius dolor quo commodi
                                                                                nisi animi error minus quia aliquam.</p>
                                                                            <span class="fs-11 text-gray-500">26
                                                                                March, 2023</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-4 col-lg-6">
                                                                    <div class="d-flex align-items-center gap-3">
                                                                        <div class="wd-100 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/4.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3 border border-3" />
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Lorem ipsum dolor sit</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum, dolor sit amet consectetur
                                                                                adipisicing elit. Eius dolor quo commodi
                                                                                nisi animi error minus quia aliquam.</p>
                                                                            <span class="fs-11 text-gray-500">26
                                                                                March, 2023</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-4 col-lg-6">
                                                                    <div class="d-flex align-items-center gap-3">
                                                                        <div class="wd-100 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/5.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3 border border-3" />
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Lorem ipsum dolor sit</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum, dolor sit amet consectetur
                                                                                adipisicing elit. Eius dolor quo commodi
                                                                                nisi animi error minus quia aliquam.</p>
                                                                            <span class="fs-11 text-gray-500">26
                                                                                March, 2023</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-4 col-lg-6">
                                                                    <div class="d-flex align-items-center gap-3">
                                                                        <div class="wd-100 rounded-3">
                                                                            <img src="{{ asset('templates/duraluxAdmin/images/banner/6.jpg') }}"
                                                                                alt=""
                                                                                class="img-fluid rounded-3 border border-3" />
                                                                        </div>
                                                                        <div>
                                                                            <a href="javascript:void(0);">
                                                                                <h6
                                                                                    class="menu-item-heading text-truncate-1-line">
                                                                                    Lorem ipsum dolor sit</h6>
                                                                            </a>
                                                                            <p
                                                                                class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">
                                                                                Lorem ipsum, dolor sit amet consectetur
                                                                                adipisicing elit. Eius dolor quo commodi
                                                                                nisi animi error minus quia aliquam.</p>
                                                                            <span class="fs-11 text-gray-500">26
                                                                                March, 2023</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-12">
                                                                    <div
                                                                        class="p-3 bg-soft-dark text-dark rounded d-flex align-items-center justify-content-between gap-4">
                                                                        <div class="fs-13 text-truncate-1-line">
                                                                            <i class="feather-star me-2"></i>
                                                                            <strong>Version 2.3.2 is out!</strong>
                                                                            <span>Learn more about our news and schedule
                                                                                reporting.</span>
                                                                        </div>
                                                                        <div class="wd-100 text-end">
                                                                            <a href="javascript:void(0);"
                                                                                class="fs-13 text-primary">Learn More
                                                                                &rarr;</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--! [End] v-pills-miscellaneous !-->
                                    </div>
                                    <!--! [End] nxl-mega-menu-tabs-content !-->
                                </div>
                            </div>
                        </div>
                        <!--! [End] nxl-h-item nxl-mega-menu !-->
                    </div>
                    <!--! [End] nxl-lavel-mega-menu-wrapper !-->
                </div>
                <!--! [End] nxl-lavel-mega-menu !-->
            </div>
            <!--! [End] Header Left !-->
            <!--! [Start] Header Right !-->
            <div class="header-right ms-auto">
                <div class="d-flex align-items-center">
                    <div class="dropdown nxl-h-item nxl-header-search">
                        <a href="javascript:void(0);" class="nxl-head-link me-0" data-bs-toggle="dropdown"
                            data-bs-auto-close="outside">
                            <i class="feather-search"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-search-dropdown">
                            <div class="input-group search-form">
                                <span class="input-group-text">
                                    <i class="feather-search fs-6 text-muted"></i>
                                </span>
                                <input type="text" class="form-control search-input-field"
                                    placeholder="Search...." />
                                <span class="input-group-text">
                                    <button type="button" class="btn-close"></button>
                                </span>
                            </div>
                            <div class="dropdown-divider mt-0"></div>
                            <div class="search-items-wrapper">
                                <div class="searching-for px-4 py-2">
                                    <p class="fs-11 fw-medium text-muted">I'm searching for...</p>
                                    <div class="d-flex flex-wrap gap-1">
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Projects</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Leads</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Contacts</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Inbox</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Invoices</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Tasks</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Customers</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Notes</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Affiliate</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Storage</a>
                                        <a href="javascript:void(0);"
                                            class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">Calendar</a>
                                    </div>
                                </div>
                                <div class="dropdown-divider"></div>
                                <div class="recent-result px-4 py-2">
                                    <h4 class="fs-13 fw-normal text-gray-600 mb-3">Recnet <span
                                            class="badge small bg-gray-200 rounded ms-1 text-dark">3</span></h4>
                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-text rounded">
                                                <i class="feather-airplay"></i>
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">CRM dashboard redesign</a>
                                                <p class="fs-11 text-muted mb-0">Home / project / crm</p>
                                            </div>
                                        </div>
                                        <div>
                                            <a href="javascript:void(0);" class="badge border rounded text-dark">/<i
                                                    class="feather-command ms-1 fs-10"></i></a>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-text rounded">
                                                <i class="feather-file-plus"></i>
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Create new document</a>
                                                <p class="fs-11 text-muted mb-0">Home / tasks / docs</p>
                                            </div>
                                        </div>
                                        <div>
                                            <a href="javascript:void(0);" class="badge border rounded text-dark">N
                                                /<i class="feather-command ms-1 fs-10"></i></a>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-text rounded">
                                                <i class="feather-user-plus"></i>
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Invite project
                                                    colleagues</a>
                                                <p class="fs-11 text-muted mb-0">Home / project / invite</p>
                                            </div>
                                        </div>
                                        <div>
                                            <a href="javascript:void(0);" class="badge border rounded text-dark">P
                                                /<i class="feather-command ms-1 fs-10"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="dropdown-divider my-3"></div>
                                <div class="users-result px-4 py-2">
                                    <h4 class="fs-13 fw-normal text-gray-600 mb-3">Users <span
                                            class="badge small bg-gray-200 rounded ms-1 text-dark">5</span></h4>
                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-image rounded">
                                                <img src="{{ asset('templates/duraluxAdmin/images/avatar/1.png') }}"
                                                    alt="" class="img-fluid" />
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Alexandra Della</a>
                                                <p class="fs-11 text-muted mb-0">alex@example.com</p>
                                            </div>
                                        </div>
                                        <a href="javascript:void(0);" class="avatar-text avatar-md">
                                            <i class="feather-chevron-right"></i>
                                        </a>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-image rounded">
                                                <img src="{{ asset('templates/duraluxAdmin/images/avatar/2.png') }}"
                                                    alt="" class="img-fluid" />
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Green Cute</a>
                                                <p class="fs-11 text-muted mb-0">green.cute@outlook.com</p>
                                            </div>
                                        </div>
                                        <a href="javascript:void(0);" class="avatar-text avatar-md">
                                            <i class="feather-chevron-right"></i>
                                        </a>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-image rounded">
                                                <img src="{{ asset('templates/duraluxAdmin/images/avatar/3.png') }}"
                                                    alt="" class="img-fluid" />
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Malanie Hanvey</a>
                                                <p class="fs-11 text-muted mb-0">malanie.anvey@outlook.com</p>
                                            </div>
                                        </div>
                                        <a href="javascript:void(0);" class="avatar-text avatar-md">
                                            <i class="feather-chevron-right"></i>
                                        </a>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-image rounded">
                                                <img src="{{ asset('templates/duraluxAdmin/images/avatar/4.png') }}"
                                                    alt="" class="img-fluid" />
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Kenneth Hune</a>
                                                <p class="fs-11 text-muted mb-0">kenth.hune@outlook.com</p>
                                            </div>
                                        </div>
                                        <a href="javascript:void(0);" class="avatar-text avatar-md">
                                            <i class="feather-chevron-right"></i>
                                        </a>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between mb-0">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-image rounded">
                                                <img src="{{ asset('templates/duraluxAdmin/images/avatar/5.png') }}"
                                                    alt="" class="img-fluid" />
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Archie Cantones</a>
                                                <p class="fs-11 text-muted mb-0">archie.cones@outlook.com</p>
                                            </div>
                                        </div>
                                        <a href="javascript:void(0);" class="avatar-text avatar-md">
                                            <i class="feather-chevron-right"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown-divider my-3"></div>
                                <div class="file-result px-4 py-2">
                                    <h4 class="fs-13 fw-normal text-gray-600 mb-3">Files <span
                                            class="badge small bg-gray-200 rounded ms-1 text-dark">3</span></h4>
                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-image bg-gray-200 rounded">
                                                <img src="{{ asset('templates/duraluxAdmin/images/file-icons/css.png') }}"
                                                    alt="" class="img-fluid" />
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Project Style CSS</a>
                                                <p class="fs-11 text-muted mb-0">05.74 MB</p>
                                            </div>
                                        </div>
                                        <a href="javascript:void(0);" class="avatar-text avatar-md">
                                            <i class="feather-download"></i>
                                        </a>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-image bg-gray-200 rounded">
                                                <img src="{{ asset('templates/duraluxAdmin/images/file-icons/zip.png') }}"
                                                    alt="" class="img-fluid" />
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Dashboard Project Zip</a>
                                                <p class="fs-11 text-muted mb-0">46.83 MB</p>
                                            </div>
                                        </div>
                                        <a href="javascript:void(0);" class="avatar-text avatar-md">
                                            <i class="feather-download"></i>
                                        </a>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between mb-0">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-image bg-gray-200 rounded">
                                                <img src="{{ asset('templates/duraluxAdmin/images/file-icons/pdf.png') }}"
                                                    alt="" class="img-fluid" />
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);"
                                                    class="font-body fw-bold d-block mb-1">Project Document PDF</a>
                                                <p class="fs-11 text-muted mb-0">12.85 MB</p>
                                            </div>
                                        </div>
                                        <a href="javascript:void(0);" class="avatar-text avatar-md">
                                            <i class="feather-download"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="dropdown-divider mt-3 mb-0"></div>
                                <a href="javascript:void(0);"
                                    class="p-3 fs-10 fw-bold text-uppercase text-center d-block">Loar More</a>
                            </div>
                        </div>
                    </div>

                    <div
                        class="dropdown nxl-h-item nxl-header-language
                    {{-- d-none  --}}
                    d-sm-flex">
                        @php
                            $currentLocale = app()->getLocale();
                            $currentLanguage = collect(activeLanguages())->firstWhere('language_code', $currentLocale);
                        @endphp

                        <a href="javascript:void(0);" class="nxl-head-link me-0 nxl-language-link"
                            data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <img src="{{ asset('system/images/lang/' . $currentLanguage->flag) }}" alt=""
                                class="img-fluid wd-20" />
                        </a>
                        <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-language-dropdown">
                            <div class="dropdown-divider mt-0"></div>
                            <div class="language-items-wrapper">
                                <div class="select-language px-4 py-2 hstack justify-content-between gap-4">
                                    <div class="lh-lg">
                                        <h6 class="mb-0">{{ t('app.language.selectLanguage') }}</h6>
                                        {{-- <p class="fs-11 text-muted mb-0">12 languages avaiable!</p> --}}
                                    </div>
                                </div>
                                <div class="dropdown-divider"></div>
                                <div class="row px-4 pt-3">
                                    @foreach (activeLanguages() as $language)
                                        <div class="col-sm-4 col-6 language_select">
                                            <a href="?lang={{ $language->language_code }}"
                                                class="d-flex align-items-center gap-2 {{ $currentLocale === $language->language_code ? 'active' : '' }}">
                                                <div class="avatar-image avatar-sm"><img
                                                        src="{{ asset('system/images/lang/' . $language->flag) }}"
                                                        alt="" class="img-fluid" /></div>
                                                <span>{{ $language->language }}</span>
                                            </a>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="nxl-h-item d-none d-sm-flex">
                        <div class="full-screen-switcher">
                            <a href="javascript:void(0);" class="nxl-head-link me-0"
                                onclick="$('body').fullScreenHelper('toggle');">
                                <i class="feather-maximize maximize"></i>
                                <i class="feather-minimize minimize"></i>
                            </a>
                        </div>
                    </div>
                    <div class="nxl-h-item dark-light-theme">
                        <a href="javascript:void(0);" class="nxl-head-link me-0 dark-button">
                            <i class="feather-moon"></i>
                        </a>
                        <a href="javascript:void(0);" class="nxl-head-link me-0 light-button"
                            style="display: none">
                            <i class="feather-sun"></i>
                        </a>
                    </div>
                    <div class="dropdown nxl-h-item">
                        <a href="javascript:void(0);" class="nxl-head-link me-0" data-bs-toggle="dropdown"
                            role="button" data-bs-auto-close="outside">
                            <i class="feather-clock"></i>
                            <span class="badge bg-success nxl-h-badge">2</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-timesheets-menu">
                            <div class="d-flex justify-content-between align-items-center timesheets-head">
                                <h6 class="fw-bold text-dark mb-0">Timesheets</h6>
                                <a href="javascript:void(0);" class="fs-11 text-success text-end ms-auto"
                                    data-bs-toggle="tooltip" title="Upcomming Timers">
                                    <i class="feather-clock"></i>
                                    <span>3 Upcomming</span>
                                </a>
                            </div>
                            <div
                                class="d-flex justify-content-between align-items-center flex-column timesheets-body">
                                <i class="feather-clock fs-1 mb-4"></i>
                                <p class="text-muted">No started timers found yes!</p>
                                <a href="javascript:void(0);" class="btn btn-sm btn-primary">Started Timer</a>
                            </div>
                            <div class="text-center timesheets-footer">
                                <a href="javascript:void(0);" class="fs-13 fw-semibold text-dark">Alls
                                    Timesheets</a>
                            </div>
                        </div>
                    </div>
                    <div class="dropdown nxl-h-item">
                        <a class="nxl-head-link me-3" data-bs-toggle="dropdown" href="#" role="button"
                            data-bs-auto-close="outside">
                            <i class="feather-bell"></i>
                            @php
                                $totalNotification = submittedQuoteRequests()->count();
                            @endphp
                            @if ($totalNotification > 0)
                                <span class="badge bg-danger nxl-h-badge">{{ $totalNotification }}</span>
                            @endif
                        </a>
                        <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-notifications-menu">
                            <div class="d-flex justify-content-between align-items-center notifications-head">
                                <h6 class="fw-bold text-dark mb-0">{{ t('app.sales.notifications') }}</h6>
                                <a href="javascript:void(0);" class="fs-11 text-success text-end ms-auto"
                                    data-bs-toggle="tooltip" title="Make as Read">
                                    <i class="feather-check"></i>
                                    {{-- <span>Make as Read</span> --}}
                                </a>
                            </div>
                            @if (submittedQuoteRequests()->count() > 0)
                                <div class="notifications-item">
                                    <img src="{{ asset('system/images/quote_icon.webp') }}" alt=""
                                        class="rounded me-3 border" />
                                    <div class="notifications-desc">
                                        <a href="javascript:void(0);" class="font-body text-truncate-2-line"> <span
                                                class="fw-semibold text-dark">New</span> Quote Requests
                                            <span
                                                class="badge bg-sucess text-white">{{ submittedQuoteRequests()->count() }}</span>
                                        </a>
                                        {{-- <div class="d-flex justify-content-between align-items-center">
                                            <div
                                                class="notifications-date text-muted border-bottom border-bottom-dashed">
                                                2 minutes ago</div>
                                            <div class="d-flex align-items-center float-end gap-2">
                                                <a href="javascript:void(0);"
                                                    class="d-block wd-8 ht-8 rounded-circle bg-gray-300"
                                                    data-bs-toggle="tooltip" title="Make as Read"></a>
                                                <a href="javascript:void(0);" class="text-danger"
                                                    data-bs-toggle="tooltip" title="Remove">
                                                    <i class="feather-x fs-12"></i>
                                                </a>
                                            </div>
                                        </div> --}}
                                    </div>
                                </div>
                            @endif

                            {{-- <div class="text-center notifications-footer">
                                <a href="javascript:void(0);" class="fs-13 fw-semibold text-dark">Alls
                                    Notifications</a>
                            </div> --}}
                        </div>
                    </div>
                    <div class="dropdown nxl-h-item">
                        <a href="javascript:void(0);" data-bs-toggle="dropdown" role="button"
                            data-bs-auto-close="outside">
                            <img src="{{ asset('templates/duraluxAdmin/images/avatar/1.png') }}" alt="user-image"
                                class="img-fluid user-avtar me-0" />
                        </a>
                        <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-user-dropdown">
                            <div class="dropdown-header">
                                <div class="d-flex align-items-center">
                                    <img src="{{ asset('templates/duraluxAdmin/images/avatar/1.png') }}"
                                        alt="user-image" class="img-fluid user-avtar" />
                                    <div>
                                        <h6 class="text-dark mb-0">Alexandra Della <span
                                                class="badge bg-soft-success text-success ms-1">PRO</span></h6>
                                        <span class="fs-12 fw-medium text-muted">alex@example.com</span>
                                    </div>
                                </div>
                            </div>
                            <div class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-item" data-bs-toggle="dropdown">
                                    <span class="hstack">
                                        <i
                                            class="wd-10 ht-10 border border-2 border-gray-1 bg-success rounded-circle me-2"></i>
                                        <span>Active</span>
                                    </span>
                                    <i class="feather-chevron-right ms-auto me-0"></i>
                                </a>
                                <div class="dropdown-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i
                                                class="wd-10 ht-10 border border-2 border-gray-1 bg-warning rounded-circle me-2"></i>
                                            <span>Always</span>
                                        </span>
                                    </a>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i
                                                class="wd-10 ht-10 border border-2 border-gray-1 bg-success rounded-circle me-2"></i>
                                            <span>Active</span>
                                        </span>
                                    </a>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i
                                                class="wd-10 ht-10 border border-2 border-gray-1 bg-danger rounded-circle me-2"></i>
                                            <span>Bussy</span>
                                        </span>
                                    </a>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i
                                                class="wd-10 ht-10 border border-2 border-gray-1 bg-info rounded-circle me-2"></i>
                                            <span>Inactive</span>
                                        </span>
                                    </a>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i
                                                class="wd-10 ht-10 border border-2 border-gray-1 bg-dark rounded-circle me-2"></i>
                                            <span>Disabled</span>
                                        </span>
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i
                                                class="wd-10 ht-10 border border-2 border-gray-1 bg-primary rounded-circle me-2"></i>
                                            <span>Cutomization</span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <div class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-item" data-bs-toggle="dropdown">
                                    <span class="hstack">
                                        <i class="feather-dollar-sign me-2"></i>
                                        <span>Subscriptions</span>
                                    </span>
                                    <i class="feather-chevron-right ms-auto me-0"></i>
                                </a>
                                <div class="dropdown-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Plan</span>
                                        </span>
                                    </a>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Billings</span>
                                        </span>
                                    </a>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Referrals</span>
                                        </span>
                                    </a>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Payments</span>
                                        </span>
                                    </a>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Statements</span>
                                        </span>
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                            <span>Subscriptions</span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <a href="javascript:void(0);" class="dropdown-item">
                                <i class="feather-user"></i>
                                <span>Profile Details</span>
                            </a>
                            <a href="javascript:void(0);" class="dropdown-item">
                                <i class="feather-activity"></i>
                                <span>Activity Feed</span>
                            </a>
                            <a href="javascript:void(0);" class="dropdown-item">
                                <i class="feather-dollar-sign"></i>
                                <span>Billing Details</span>
                            </a>
                            <a href="javascript:void(0);" class="dropdown-item">
                                <i class="feather-bell"></i>
                                <span>Notifications</span>
                            </a>
                            <a href="javascript:void(0);" class="dropdown-item">
                                <i class="feather-settings"></i>
                                <span>Account Settings</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="./auth-login-minimal.html" class="dropdown-item">
                                <i class="feather-log-out"></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!--! [End] Header Right !-->
        </div>
    </header>
    <!--! ================================================================ !-->
    <!--! [End] Header !-->
    <!--! ================================================================ !-->
    <!--! ================================================================ !-->
    <!--! [Start] Main Content !-->
    <!--! ================================================================ !-->
    <main class="nxl-container">
        <div style="padding-bottom: 100px">
            @yield('content')
        </div>

        <!-- [ Footer ] start -->
        <footer class="footer">
            <p class="fs-11 text-muted fw-medium text-uppercase mb-0 copyright">
                <span>Copyright ©</span>
                <script>
                    document.write(new Date().getFullYear());
                </script>
            </p>
            <p><span>By: <a target="_blank" href="https://wrapbootstrap.com/user/theme_ocean"
                        target="_blank">theme_ocean</a></span> • <span>Distributed by: <a target="_blank"
                        href="https://themewagon.com" target="_blank">ThemeWagon</a></span></p>
            <div class="d-flex align-items-center gap-4">
                <a href="javascript:void(0);" class="fs-11 fw-semibold text-uppercase">Help</a>
                <a href="javascript:void(0);" class="fs-11 fw-semibold text-uppercase">Terms</a>
                <a href="javascript:void(0);" class="fs-11 fw-semibold text-uppercase">Privacy</a>
            </div>
        </footer>
        <!-- [ Footer ] end -->
    </main>
    <!--! ================================================================ !-->
    <!--! [End] Main Content !-->
    <!--! ================================================================ !-->
    <!--! ================================================================ !-->
    <!--! ================================================================ !-->
    <!--! ================================================================ !-->
    <!--! Footer Script !-->
    <!--! ================================================================ !-->
    <!--! BEGIN: Vendors JS !-->
    <script src="{{ asset('templates/duraluxAdmin/vendors/js/vendors.min.js') }}"></script>
    <!-- vendors.min.js {always must need to be top} -->
    <script src="{{ asset('templates/duraluxAdmin/vendors/js/daterangepicker.min.js') }}"></script>
    <script src="{{ asset('templates/duraluxAdmin/vendors/js/apexcharts.min.js') }}"></script>
    <script src="{{ asset('templates/duraluxAdmin/vendors/js/circle-progress.min.js') }}"></script>
    <!--! END: Vendors JS !-->
    <!--! BEGIN: Apps Init  !-->
    <script src="{{ asset('templates/duraluxAdmin/js/common-init.min.js') }}"></script>
    <script src="{{ asset('templates/duraluxAdmin/js/dashboard-init.min.js') }}"></script>
    <!--! END: Apps Init !-->
    <!--! BEGIN: Theme Customizer  !-->
    <script src="{{ asset('templates/duraluxAdmin/js/theme-customizer-init.min.js') }}"></script>
    <!--! END: Theme Customizer !-->

    @include('layouts.include.toastrNotificationFunction')

    {{-- search bar script start --}}
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchToggle = document.querySelector('.table-search .search-toggle');
            const searchForm = document.querySelector('.table-search .search-form');

            if (searchToggle && searchForm) {
                // Toggle on click
                searchToggle.addEventListener('click', function(e) {
                    e.stopPropagation();
                    searchForm.classList.toggle('active');
                    searchToggle.classList.toggle('active');

                    // Focus input when opened
                    if (searchForm.classList.contains('active')) {
                        const input = searchForm.querySelector('input');
                        setTimeout(() => input.focus(), 100);
                    }
                });

                // Close when clicking outside
                document.addEventListener('click', function(e) {
                    if (!searchForm.contains(e.target) && !searchToggle.contains(e.target)) {
                        searchForm.classList.remove('active');
                        searchToggle.classList.remove('active');
                    }
                });

                // Prevent closing when clicking inside the form
                searchForm.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            }
        });
    </script>
    {{-- search bar script end --}}

</body>

</html>
